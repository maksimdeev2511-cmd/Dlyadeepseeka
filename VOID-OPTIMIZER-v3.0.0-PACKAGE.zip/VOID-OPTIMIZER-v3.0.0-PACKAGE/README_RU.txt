VOID OPTIMIZER 3.0.0 — WINDOWS 10/11 x64
=========================================

VOID RADAR · RUST+ TEAM CHAT
----------------------------
• Без серверного uMod/Oxide/Carbon-плагина и без администраторского доступа.
• При смерти участника команды отправляет в игровой Team Chat ник и grid:
  [VOID] Nick погиб! Квадрат: G14
• Также может сообщать об online-статусе тиммейтов и доступных Rust+ маркерах
  Cargo Ship, CH-47, Crate и Patrol Helicopter.
• Встроенный LIVE FEED и Windows-уведомления.

Требуются Rust+ pairing и членство в игровой команде. Текущий сетевой режим
использует прямой WebSocket к Rust+ app.port. Некоторые серверы/сети могут
требовать новый Facepunch Companion Socket, который пока не поддержан.
Rust+ не отдаёт все серверные события: Oil Rig и отдельные local hooks без
серверного источника недоступны.

Подробная инструкция — RUSTPLUS-SETUP-RU.txt. Пароль Steam и Steam Guard-коды
в VOID не вводи; PlayerToken не передавай другим людям.

Сохранены оптимизация Windows/ПК, Rust CFG и бинды, управление разрешением,
раздел RUST+ и Steam Player Tracker.

Сборка: исходники Go в source/. Для пересборки на Windows запусти build.bat.
GUI и живой сервер в этой среде не запускались; см. BUILD-INFO.txt.
