#!/usr/bin/env python3
"""Add the app's multi-size .ico as native Windows EXE icon resources.

Usage: python add_icon_resource.py VOID-OPTIMIZER.exe assets/void-icon.ico
This script patches a freshly built PE32+ Windows executable in place.
"""
from __future__ import annotations
import math
import os
import struct
import sys
from pathlib import Path


def align(value: int, alignment: int) -> int:
    return (value + alignment - 1) // alignment * alignment


def directory_header(id_count: int) -> bytes:
    return struct.pack("<IIHHHH", 0, 0, 0, 0, 0, id_count)


def resource_entry(resource_id: int, offset: int, is_directory: bool) -> bytes:
    target = offset | (0x80000000 if is_directory else 0)
    return struct.pack("<II", resource_id, target)


def make_resource_blob(ico: bytes, section_rva: int) -> bytes:
    if len(ico) < 6:
        raise ValueError("ICO file is truncated")
    reserved, kind, count = struct.unpack_from("<HHH", ico, 0)
    if reserved != 0 or kind != 1 or count < 1:
        raise ValueError("Invalid ICO header")
    images = []
    entries = []
    for index in range(count):
        off = 6 + index * 16
        if off + 16 > len(ico):
            raise ValueError("ICO directory is truncated")
        width, height, colors, reserved_byte, planes, bit_count, size, image_off = struct.unpack_from("<BBBBHHII", ico, off)
        if image_off + size > len(ico):
            raise ValueError("ICO image data is outside the file")
        images.append(ico[image_off:image_off + size])
        entries.append((width, height, colors, reserved_byte, planes, bit_count, size, index + 1))

    root_off = 0
    icon_type_off = 32
    group_type_off = icon_type_off + 16 + count * 8
    icon_lang_start = group_type_off + 16 + 8
    group_lang_off = icon_lang_start + count * 24
    data_entries_off = group_lang_off + 24
    payload_off = align(data_entries_off + (count + 1) * 16, 4)

    image_offsets = []
    cursor = payload_off
    for image in images:
        cursor = align(cursor, 4)
        image_offsets.append(cursor)
        cursor += len(image)
    group_icon = bytearray(struct.pack("<HHH", 0, 1, count))
    for width, height, colors, reserved_byte, planes, bit_count, size, resource_id in entries:
        group_icon += struct.pack("<BBBBHHIH", width, height, colors, reserved_byte, planes, bit_count, size, resource_id)
    group_data_off = align(cursor, 4)
    total_size = group_data_off + len(group_icon)
    blob = bytearray(total_size)

    # Root: RT_ICON (3) and RT_GROUP_ICON (14).
    blob[root_off:root_off + 16] = directory_header(2)
    blob[root_off + 16:root_off + 24] = resource_entry(3, icon_type_off, True)
    blob[root_off + 24:root_off + 32] = resource_entry(14, group_type_off, True)

    # RT_ICON -> icon ID -> language 0x409 -> data entry.
    blob[icon_type_off:icon_type_off + 16] = directory_header(count)
    for i in range(count):
        lang_off = icon_lang_start + i * 24
        blob[icon_type_off + 16 + i * 8:icon_type_off + 24 + i * 8] = resource_entry(i + 1, lang_off, True)
        blob[lang_off:lang_off + 16] = directory_header(1)
        blob[lang_off + 16:lang_off + 24] = resource_entry(0x409, data_entries_off + i * 16, False)
        data_off = image_offsets[i]
        blob[data_entries_off + i * 16:data_entries_off + (i + 1) * 16] = struct.pack("<IIII", section_rva + data_off, len(images[i]), 0, 0)
        blob[data_off:data_off + len(images[i])] = images[i]

    # RT_GROUP_ICON -> group ID 1 -> language 0x409 -> group data entry.
    blob[group_type_off:group_type_off + 16] = directory_header(1)
    blob[group_type_off + 16:group_type_off + 24] = resource_entry(1, group_lang_off, True)
    blob[group_lang_off:group_lang_off + 16] = directory_header(1)
    blob[group_lang_off + 16:group_lang_off + 24] = resource_entry(0x409, data_entries_off + count * 16, False)
    blob[data_entries_off + count * 16:data_entries_off + (count + 1) * 16] = struct.pack("<IIII", section_rva + group_data_off, len(group_icon), 0, 0)
    blob[group_data_off:group_data_off + len(group_icon)] = group_icon
    return bytes(blob)


def patch_exe(exe_path: Path, ico_path: Path) -> None:
    data = bytearray(exe_path.read_bytes())
    ico = ico_path.read_bytes()
    if data[:2] != b"MZ":
        raise ValueError("Not an MZ executable")
    pe_off = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_off:pe_off + 4] != b"PE\0\0":
        raise ValueError("Invalid PE signature")
    coff = pe_off + 4
    machine, number_sections = struct.unpack_from("<HH", data, coff)
    if machine != 0x8664:
        raise ValueError("Expected an x64 executable")
    optional_size = struct.unpack_from("<H", data, coff + 16)[0]
    optional = coff + 20
    magic = struct.unpack_from("<H", data, optional)[0]
    if magic != 0x20B:
        raise ValueError("Expected a PE32+ optional header")
    section_alignment = struct.unpack_from("<I", data, optional + 32)[0]
    file_alignment = struct.unpack_from("<I", data, optional + 36)[0]
    size_of_headers = struct.unpack_from("<I", data, optional + 60)[0]
    num_dirs = struct.unpack_from("<I", data, optional + 108)[0]
    if num_dirs < 3:
        raise ValueError("PE has no resource data-directory slot")
    resource_dir_entry = optional + 112 + 2 * 8
    old_rva, old_size = struct.unpack_from("<II", data, resource_dir_entry)

    section_table = optional + optional_size
    sections = []
    max_va_end = 0
    for i in range(number_sections):
        off = section_table + i * 40
        name = bytes(data[off:off + 8]).rstrip(b"\0").decode("ascii", "replace")
        virtual_size, virtual_address, raw_size, raw_ptr = struct.unpack_from("<IIII", data, off + 8)
        sections.append((name, virtual_size, virtual_address, raw_size, raw_ptr))
        max_va_end = max(max_va_end, virtual_address + max(virtual_size, raw_size))

    # Recent Go toolchains may already emit a .rsrc section containing a
    # generic icon group. Replace that icon-only tree in place when possible.
    if old_rva or old_size:
        if not old_rva or not old_size:
            raise ValueError("PE resource directory is malformed")
        target = None
        for item in sections:
            name, virtual_size, virtual_address, raw_size, raw_ptr = item
            span = max(virtual_size, raw_size)
            if virtual_address <= old_rva < virtual_address + span:
                target = item
                break
        if target is None:
            raise ValueError("Existing resource directory is not inside a section")
        name, virtual_size, virtual_address, raw_size, raw_ptr = target
        if name != ".rsrc":
            raise ValueError(f"Existing resource directory is in unexpected section {name!r}")
        resource_blob = make_resource_blob(ico, old_rva)
        if len(resource_blob) > raw_size:
            raise ValueError("New icon resources do not fit in the existing .rsrc section")
        new_bytes = resource_blob + b"\0" * (raw_size - len(resource_blob))
        data[raw_ptr:raw_ptr + raw_size] = new_bytes
        section_header = section_table + sections.index(target) * 40
        struct.pack_into("<I", data, section_header + 8, len(resource_blob))
        struct.pack_into("<II", data, resource_dir_entry, old_rva, len(resource_blob))
        exe_path.write_bytes(data)
        return

    new_header = section_table + number_sections * 40
    if new_header + 40 > size_of_headers:
        raise ValueError("Not enough spare section-header space in PE headers")

    section_va = align(max_va_end, section_alignment)
    # First pass builds the resource tree. Its payload entries are relative to this RVA.
    resource_blob = make_resource_blob(ico, section_va)
    raw_ptr = align(len(data), file_alignment)
    raw_size = align(len(resource_blob), file_alignment)
    data.extend(b"\0" * (raw_ptr - len(data)))
    data.extend(resource_blob)
    data.extend(b"\0" * (raw_size - len(resource_blob)))

    # Add a read-only initialized-data section.
    section_name = b".rsrc\0\0\0"
    header = bytearray(40)
    header[0:8] = section_name
    struct.pack_into("<IIIIIIHHI", header, 8,
                     len(resource_blob), section_va, raw_size, raw_ptr,
                     0, 0, 0, 0, 0x40000040)
    data[new_header:new_header + 40] = header
    struct.pack_into("<H", data, coff + 2, number_sections + 1)
    struct.pack_into("<I", data, optional + 8,
                     struct.unpack_from("<I", data, optional + 8)[0] + raw_size)
    struct.pack_into("<I", data, optional + 56, align(section_va + len(resource_blob), section_alignment))
    struct.pack_into("<II", data, resource_dir_entry, section_va, len(resource_blob))
    exe_path.write_bytes(data)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python add_icon_resource.py VOID-OPTIMIZER.exe assets/void-icon.ico")
    patch_exe(Path(sys.argv[1]), Path(sys.argv[2]))
    print(f"Added native Windows icon resource to {sys.argv[1]}")
