package main

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

const testSteamKey = "0123456789abcdef0123456789abcdef"
const testSteamID = "76561198000000001"

func TestFetchRustPlayersReadsProfileAndHours(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/ISteamUser/GetPlayerSummaries/v2/":
			if r.URL.Query().Get("key") != testSteamKey || r.URL.Query().Get("steamids") != testSteamID {
				t.Errorf("unexpected summary query: %s", r.URL.RawQuery)
			}
			fmt.Fprintf(w, `{"response":{"players":[{"steamid":"%s","personaname":"VOID_TEST","profileurl":"https://steamcommunity.com/profiles/%s","avatarfull":"https://example.test/avatar.png","personastate":1,"gameid":"252490","gameextrainfo":"Rust","lastlogoff":1700000000}]}}`, testSteamID, testSteamID)
		case "/IPlayerService/GetOwnedGames/v1/":
			if r.URL.Query().Get("steamid") != testSteamID || r.URL.Query().Get("appids_filter[0]") != "252490" {
				t.Errorf("unexpected owned games query: %s", r.URL.RawQuery)
			}
			fmt.Fprint(w, `{"response":{"game_count":1,"games":[{"appid":252490,"playtime_forever":1530,"playtime_2weeks":120}]}}`)
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()

	players, err := fetchRustPlayers(context.Background(), srv.Client(), srv.URL, testSteamKey, []string{testSteamID})
	if err != nil {
		t.Fatal(err)
	}
	if len(players) != 1 {
		t.Fatalf("got %d players", len(players))
	}
	p := players[0]
	if !p.RustPlaying || !p.GameStatusKnown {
		t.Fatalf("expected known Rust presence: %+v", p)
	}
	if !p.HoursKnown || p.RustHours != 25.5 || p.RustHours2Weeks != 2 {
		t.Fatalf("unexpected playtime: %+v", p)
	}
	if p.PersonaName != "VOID_TEST" || p.ProfileURL == "" || p.LastLogoff.IsZero() {
		t.Fatalf("profile fields missing: %+v", p)
	}
}

func TestFetchRustPlayersDoesNotTreatHiddenHoursAsZero(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/ISteamUser/GetPlayerSummaries/v2/" {
			fmt.Fprintf(w, `{"response":{"players":[{"steamid":"%s","personaname":"PRIVATE","personastate":0}]}}`, testSteamID)
			return
		}
		fmt.Fprint(w, `{"response":{}}`)
	}))
	defer srv.Close()
	players, err := fetchRustPlayers(context.Background(), srv.Client(), srv.URL, testSteamKey, []string{testSteamID})
	if err != nil {
		t.Fatal(err)
	}
	if players[0].HoursKnown {
		t.Fatal("hidden playtime must not be represented as 0 hours")
	}
	if players[0].HoursError == "" {
		t.Fatal("expected privacy explanation")
	}
}

func TestValidationAndWatchLimit(t *testing.T) {
	if validSteamID64("not-a-steam-id") || validSteamID64("123") {
		t.Fatal("invalid SteamID64 accepted")
	}
	if validSteamAPIKey("bad-key") {
		t.Fatal("invalid API key accepted")
	}
	ids := make([]string, maxRustWatch+1)
	for i := range ids {
		ids[i] = fmt.Sprintf("76561198000000%03d", i)
	}
	if _, err := fetchRustPlayers(context.Background(), nil, "", testSteamKey, ids); err == nil {
		t.Fatal("watch limit not enforced")
	}
}

func TestRustPlayerTransitionsIgnoreUnknownState(t *testing.T) {
	before := RustTrackedPlayer{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: true, RustPlaying: true}
	unknown := RustTrackedPlayer{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: false, RustPlaying: false}
	if got := rustPlayerTransition(before, unknown); got != "" {
		t.Fatalf("unknown state caused false event: %q", got)
	}
	after := RustTrackedPlayer{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: true, RustPlaying: false}
	if got := rustPlayerTransition(before, after); got == "" {
		t.Fatal("expected leave notification")
	}
	if got := rustPlayerTransition(after, before); got == "" {
		t.Fatal("expected join notification")
	}
}

func TestSteamRequestHonorsContext(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Nanosecond)
	defer cancel()
	time.Sleep(time.Millisecond)
	var dst map[string]any
	if err := steamGETJSON(ctx, &http.Client{}, "https://example.invalid", &dst); err == nil {
		t.Fatal("expected canceled request")
	}
}

func TestParseSteamIDsDeduplicatesAndEnforcesLimit(t *testing.T) {
	ids, err := parseSteamIDs(testSteamID + "\n" + testSteamID + ", 76561198000000002")
	if err != nil {
		t.Fatal(err)
	}
	if len(ids) != 2 || ids[0] != testSteamID {
		t.Fatalf("unexpected ids: %#v", ids)
	}
	if _, err := parseSteamIDs("not-an-id"); err == nil {
		t.Fatal("invalid SteamID64 accepted")
	}
	tooMany := ""
	for i := 0; i < maxRustWatch+1; i++ {
		tooMany += fmt.Sprintf("76561198000000%03d\n", i)
	}
	if _, err := parseSteamIDs(tooMany); err == nil {
		t.Fatal("watch list limit was not enforced")
	}
}

func TestRustPlayerTransitionsOnlyKnownChanges(t *testing.T) {
	before := []RustTrackedPlayer{{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: true, RustPlaying: true}}
	after := []RustTrackedPlayer{{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: true, RustPlaying: false}}
	got := rustPlayerTransitions(before, after)
	if len(got) != 1 || got[0] != "A вышел из Rust" {
		t.Fatalf("unexpected transition: %#v", got)
	}
	unknown := []RustTrackedPlayer{{SteamID64: testSteamID, PersonaName: "A", GameStatusKnown: false}}
	if got := rustPlayerTransitions(before, unknown); len(got) != 0 {
		t.Fatalf("unknown status generated event: %#v", got)
	}
}
