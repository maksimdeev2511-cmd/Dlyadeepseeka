package main

import (
	"strings"
	"testing"
)

func TestMergeRustUtilityBindsPreservesOtherKeys(t *testing.T) {
	original := "bind f1 consoletoggle\r\nbind x forward\r\nbind q oldcommand\r\nbind z oldcrouch\r\nbind mouse4 oldloot\r\ninput.bind mouse3 +buttons.hoverloot\r\n// keep this comment\r\n"
	got := mergeRustUtilityBinds(original)
	for _, keep := range []string{"bind f1 consoletoggle", "bind x forward", "// keep this comment"} {
		if !strings.Contains(got, keep) {
			t.Fatalf("unmanaged binds/comments were lost: %q", got)
		}
	}
	keys := []string{"q", "z", "n", "mouse3", "mouse5", "f2", "b", "h", "l", "f3"}
	for _, key := range keys {
		if strings.Count(strings.ToLower(got), "bind "+key+" ") != 1 {
			t.Fatalf("expected exactly one %s bind, got %q", key, got)
		}
	}
	for _, want := range []string{
		"bind q forward;sprint",
		"bind z duck",
		"bind n +jump;+duck",
		"bind mouse3 +hoverloot",
		"bind mouse5 +voice",
		"bind f2 consoletoggle",
		"bind b \"craft.add -2072273936 1\"",
		"bind h \"client.headlerp 100\"",
		"bind l ~client.lookatradius 0;client.lookatradius 0.2;client.lookatradius 10",
		"bind f3 \"~graphics.vm_fov_scale true;graphics.vm_fov_scale false\"",
	} {
		if !strings.Contains(got, want) {
			t.Fatalf("missing utility bind %q in %q", want, got)
		}
	}
	if strings.Contains(got, "bind mouse4 oldloot") {
		t.Fatalf("old VOID quick-loot assignment was not migrated: %q", got)
	}
}

func TestMergeRustUtilityBindsIsIdempotent(t *testing.T) {
	first := mergeRustUtilityBinds("bind f1 consoletoggle\n")
	second := mergeRustUtilityBinds(first)
	if first != second {
		t.Fatalf("merge should be idempotent\nfirst: %q\nsecond: %q", first, second)
	}
}

func TestMergeRustUtilityBindsReplacesPriorVOIDProfile(t *testing.T) {
	prior := "// VOID OPTIMIZER — utility binds; restore with keys.cfg.void-backup\nbind q forward;sprint\nbind z duck\nbind f1 consoletoggle\n"
	got := mergeRustUtilityBinds(prior)
	if strings.Count(got, "// VOID OPTIMIZER — utility binds") != 1 || strings.Count(got, "bind q ") != 1 || !strings.Contains(got, "bind f1 consoletoggle") {
		t.Fatalf("prior profile was not cleanly replaced: %q", got)
	}
}

func TestMergeRustUtilityBindsCustomViewmodelKey(t *testing.T) {
	got := mergeRustUtilityBindsWithKeys("bind f1 consoletoggle\nbind v +voice\nbind f4 old-viewmodel\n", "mouse3", "f4")
	if !strings.Contains(got, "bind f4 \"~graphics.vm_fov_scale true;graphics.vm_fov_scale false\"") {
		t.Fatalf("custom viewmodel key missing: %q", got)
	}
	if !strings.Contains(got, "bind v +voice") {
		t.Fatalf("unmanaged user bind should be preserved: %q", got)
	}
	if strings.Contains(got, "bind f4 old-viewmodel") {
		t.Fatalf("old assignment on the selected key should be replaced: %q", got)
	}
}

func TestRustBindKey(t *testing.T) {
	cases := []struct{ line, want string }{
		{"bind q forward;sprint", "q"},
		{"  BIND [Q] forward;sprint", "q"},
		{"bind mouse3 +hoverloot", "mouse3"},
		{"input.bind mouse3 +buttons.hoverloot", "mouse3"},
		{"INPUT.BIND [L] +something", "l"},
		{"// bind q ignored", ""},
		{"unbind q", ""},
		{"bind f1 consoletoggle", "f1"},
		{"bind f3 \"~graphics.vm_fov_scale true;graphics.vm_fov_scale false\"", "f3"},
	}
	for _, tc := range cases {
		if got := rustBindKey(tc.line); got != tc.want {
			t.Errorf("rustBindKey(%q) = %q, want %q", tc.line, got, tc.want)
		}
	}
}

func TestMergeRustUtilityBindsWithCustomKeysForEveryBind(t *testing.T) {
	keys := defaultRustBindKeys()
	keys["autorun"] = "f4"
	keys["crouch"] = "f5"
	keys["jumpcrouch"] = "f6"
	keys["loot"] = "mouse4"
	keys["voice"] = "f7"
	keys["console"] = "f8"
	keys["bandage"] = "f9"
	keys["quickalt"] = "f10"
	keys["radius"] = "f11"
	keys["viewmodel"] = "f12"
	if err := validateRustBindKeys(keys); err != nil {
		t.Fatalf("unexpected key map validation failure: %v", err)
	}
	got := mergeRustUtilityBindsWithMap("bind f1 custom-command\nbind x keep-me\n", keys)
	for id, key := range keys {
		if !strings.Contains(got, "bind "+key+" ") {
			t.Errorf("custom key for %s was not written: %q", id, got)
		}
	}
	for _, keep := range []string{"bind f1 custom-command", "bind x keep-me"} {
		if !strings.Contains(got, keep) {
			t.Errorf("unmanaged bind was not preserved: %q", keep)
		}
	}
	if got2 := mergeRustUtilityBindsWithMap(got, keys); got2 != got {
		t.Fatalf("custom bind merge must be idempotent\nfirst: %q\nsecond: %q", got, got2)
	}
}

func TestValidateRustBindKeysRejectsDuplicates(t *testing.T) {
	keys := defaultRustBindKeys()
	keys["crouch"] = keys["autorun"]
	if err := validateRustBindKeys(keys); err == nil {
		t.Fatal("duplicate bind keys should be rejected")
	}
}

func TestMergePreservesUnrelatedMouseFourBind(t *testing.T) {
	got := mergeRustUtilityBinds("bind mouse4 +attack\nbind x +forward\n")
	if !strings.Contains(got, "bind mouse4 +attack") {
		t.Fatalf("unrelated Mouse4 bind should be preserved: %q", got)
	}
}
