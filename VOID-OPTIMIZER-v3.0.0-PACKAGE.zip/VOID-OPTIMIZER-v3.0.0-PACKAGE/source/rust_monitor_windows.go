//go:build windows

package main

import (
	"context"
	"net/http"
	"time"
)

func startRustMonitor() {
	if app.RustMonitorBusy {
		return
	}
	if !validSteamAPIKey(app.RustSteamAPIKey) {
		app.RustMonitorError = "Нужен корректный Steam Web API Key."
		app.Status = "Введи Steam Web API Key на странице RUST+ МОНИТОРИНГ."
		invalidate()
		return
	}
	ids := normalizeSteamIDs(app.RustTrackedIDs)
	if len(ids) == 0 {
		app.RustMonitorError = "Список SteamID64 пуст."
		app.Status = "Добавь SteamID64 игроков, которых нужно отслеживать."
		invalidate()
		return
	}
	app.RustTrackedIDs = ids
	key := app.RustSteamAPIKey
	ch := make(chan rustMonitorResult, 1)
	app.RustMonitorCh = ch
	app.RustMonitorBusy = true
	app.RustMonitorError = ""
	app.RustMonitorNextCheck = time.Now().Add(2 * time.Minute)
	app.Status = "Запрашиваем публичный статус Steam и часы в Rust…"
	invalidate()
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
		defer cancel()
		client := &http.Client{Timeout: 12 * time.Second}
		players, err := fetchRustPlayers(ctx, client, steamAPIBase, key, ids)
		ch <- rustMonitorResult{Players: players, Err: err}
	}()
}
