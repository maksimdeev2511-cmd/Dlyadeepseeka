package main

import (
	"strings"
	"testing"
)

func TestBuildRustCFGEntriesHasBroadUniqueGraphicsProfile(t *testing.T) {
	entries := buildRustCFGEntries(0, 1500)
	if len(entries) < 55 {
		t.Fatalf("expected 40+ supported graphics settings, got %d", len(entries))
	}
	seen := map[string]bool{}
	for _, e := range entries {
		key := strings.ToLower(e.key)
		if seen[key] {
			t.Fatalf("duplicate CFG key %q", key)
		}
		seen[key] = true
		allowedPrefixes := []string{"graphics.", "graphicssettings.", "grass.", "effects.", "decor.", "tree.", "mesh.", "culling."}
		allowed := false
		for _, prefix := range allowedPrefixes {
			if strings.HasPrefix(key, prefix) {
				allowed = true
				break
			}
		}
		if !allowed {
			t.Fatalf("non-graphics key escaped allow-list: %q", key)
		}
	}
	for _, removed := range []string{"graphics.quality", "graphics.shadowdistance", "graphics.shadowcascades", "graphics.shadowquality", "bind", "input.bind", "global.god", "player.infiniteammo"} {
		if seen[removed] {
			t.Fatalf("deprecated or unsafe key was included: %q", removed)
		}
	}
}

func TestBuildRustCFGEntriesClampsInputsAndScalesSettings(t *testing.T) {
	low := buildRustCFGEntries(-5, 1)
	balanced := buildRustCFGEntries(2, 1600)
	high := buildRustCFGEntries(9, 9000)
	find := func(entries []rustCFGEntry, key string) string {
		for _, e := range entries {
			if e.key == key {
				return e.value
			}
		}
		return ""
	}
	if find(low, "graphics.drawdistance") != "500" || find(high, "graphics.drawdistance") != "2500" {
		t.Fatal("draw distance was not clamped")
	}
	if find(low, "grass.quality") != "0" || find(balanced, "grass.quality") != "1" || find(high, "grass.quality") != "2" {
		t.Fatal("grass settings did not follow performance tiers")
	}
	if find(low, "graphicssettings.shadowdistance") != "50" || find(high, "graphicssettings.shadowdistance") != "180" {
		t.Fatal("shadow distance did not follow performance tiers")
	}
	if find(low, "tree.quality") != "200" || find(high, "tree.quality") != "900" {
		t.Fatal("tree LOD did not follow performance tiers")
	}
}

func TestMergeRustCFGPreservesUnknownEntriesAndIsIdempotent(t *testing.T) {
	entries := buildRustCFGEntries(0, 1500)
	original := "global.language \"en\"\r\ngraphics.fov \"75\"\r\ncustom.user.setting \"x\"\r\nbind q \"forward\"\r\n// keep comment\r\n"
	first := mergeRustCFG(original, entries)
	second := mergeRustCFG(first, entries)
	if first != second {
		t.Fatalf("merge not idempotent")
	}
	for _, keep := range []string{"global.language \"en\"", "custom.user.setting \"x\"", "bind q \"forward\"", "// keep comment"} {
		if !strings.Contains(first, keep) {
			t.Fatalf("unmanaged line lost: %q", keep)
		}
	}
	if strings.Count(strings.ToLower(first), "graphics.fov ") != 1 {
		t.Fatal("managed key should occur exactly once")
	}
}

func TestBuildRustCFGEntriesUsesSelectedDisplaySettingsAndCurrentPlayerKeys(t *testing.T) {
	entries := buildRustCFGEntriesWithDisplay(0, 4000, 120, true)
	find := func(key string) string {
		for _, entry := range entries {
			if entry.key == key {
				return entry.value
			}
		}
		return ""
	}
	if find("graphics.drawdistance") != "2500" || find("graphics.fov") != "90" || find("graphics.vsync") != "1" {
		t.Fatal("display settings were not clamped/applied")
	}
	if find("graphics.af") != "1" || find("gc.buffer_enabled") != "True" || find("water.reflections") != "0" {
		t.Fatal("expected current player-side performance keys are missing")
	}
	if find("graphicssettings.anisotropicfiltering") != "" || find("graphicssettings.enablelodcrossfade") != "" {
		t.Fatal("legacy/unconfirmed graphics key was emitted")
	}
}
