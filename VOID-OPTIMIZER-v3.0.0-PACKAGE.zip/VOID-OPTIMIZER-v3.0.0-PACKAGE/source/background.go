//go:build windows

package main

import (
	"bytes"
	"image"
	_ "image/png"
	"runtime"
	"unsafe"
)

const biRGB = 0

var cardFillDC uintptr
var cardFillBitmap uintptr
var cardFillColor uint32

type bitmapInfoHeader struct {
	Size          uint32
	Width         int32
	Height        int32
	Planes        uint16
	BitCount      uint16
	Compression   uint32
	SizeImage     uint32
	XPelsPerMeter int32
	YPelsPerMeter int32
	ClrUsed       uint32
	ClrImportant  uint32
}

type bitmapInfo struct {
	Header bitmapInfoHeader
	Colors [1]uint32
}

type blendFunction struct {
	Operation           byte
	Flags               byte
	SourceConstantAlpha byte
	AlphaFormat         byte
}

func createBackgroundBitmap() {
	if len(embeddedBackground) == 0 || app.BackgroundDC != 0 {
		return
	}
	img, _, err := image.Decode(bytes.NewReader(embeddedBackground))
	if err != nil || img == nil {
		return
	}
	bounds := img.Bounds()
	w, h := bounds.Dx(), bounds.Dy()
	if w < 1 || h < 1 || w > 4096 || h > 4096 {
		return
	}
	info := bitmapInfo{Header: bitmapInfoHeader{Size: uint32(unsafe.Sizeof(bitmapInfoHeader{})), Width: int32(w), Height: -int32(h), Planes: 1, BitCount: 32, Compression: biRGB}}
	var bits uintptr
	bitmap, _, _ := pCreateDIBSection.Call(0, uintptr(unsafe.Pointer(&info)), 0, uintptr(unsafe.Pointer(&bits)), 0, 0)
	runtime.KeepAlive(&info)
	if bitmap == 0 || bits == 0 {
		if bitmap != 0 {
			pDeleteObject.Call(bitmap)
		}
		return
	}
	pixels := unsafe.Slice((*byte)(unsafe.Pointer(bits)), w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			r, g, b, a := img.At(bounds.Min.X+x, bounds.Min.Y+y).RGBA()
			// Keep the decorative art deliberately translucent so every control
			// and text label remains legible over it. AlphaBlend needs premultiplied BGRA.
			// SourceConstantAlpha is set to 255 when drawing, so this per-pixel
			// opacity is the only global dimming factor. Keep the artwork clearly
			// visible while leaving room for the translucent cards and readable UI.
			const opacity = uint32(100)
			a8 := uint8((a >> 8) * opacity / 100)
			r8 := uint8((r >> 8) * opacity / 100)
			g8 := uint8((g >> 8) * opacity / 100)
			b8 := uint8((b >> 8) * opacity / 100)
			i := (y*w + x) * 4
			pixels[i+0], pixels[i+1], pixels[i+2], pixels[i+3] = b8, g8, r8, a8
		}
	}
	dc, _, _ := pCreateCompatibleDC.Call(0)
	if dc == 0 {
		pDeleteObject.Call(bitmap)
		return
	}
	pSelectObject.Call(dc, bitmap)
	app.BackgroundDC = dc
	app.BackgroundBitmap = bitmap
	app.BackgroundWidth = w
	app.BackgroundHeight = h
	runtime.KeepAlive(img)
	runtime.KeepAlive(pixels)
}

func drawBackgroundArt(hdc uintptr, r rect) {
	if app.BackgroundDC == 0 || app.BackgroundBitmap == 0 || app.BackgroundWidth <= 0 || app.BackgroundHeight <= 0 {
		return
	}
	w, h := int(r.Right-r.Left), int(r.Bottom-r.Top)
	if w <= 0 || h <= 0 {
		return
	}
	blend := blendFunction{Operation: 0, Flags: 0, SourceConstantAlpha: 255, AlphaFormat: 1}
	pAlphaBlend.Call(hdc,
		uintptr(r.Left), uintptr(r.Top), uintptr(w), uintptr(h),
		app.BackgroundDC, 0, 0, uintptr(app.BackgroundWidth), uintptr(app.BackgroundHeight),
		uintptr(unsafe.Pointer(&blend)))
	runtime.KeepAlive(&blend)
}

// drawCardFill paints a translucent card surface over the embedded artwork.
// The cached 1x1 premultiplied-alpha DIB is stretched by AlphaBlend, avoiding
// a new GDI allocation for every card on every repaint.
func drawCardFill(hdc uintptr, r rect) bool {
	if cardFillDC == 0 || cardFillColor != colCard {
		if cardFillDC != 0 {
			pDeleteDC.Call(cardFillDC)
			cardFillDC = 0
		}
		if cardFillBitmap != 0 {
			pDeleteObject.Call(cardFillBitmap)
			cardFillBitmap = 0
		}
		info := bitmapInfo{Header: bitmapInfoHeader{Size: uint32(unsafe.Sizeof(bitmapInfoHeader{})), Width: 1, Height: -1, Planes: 1, BitCount: 32, Compression: biRGB}}
		var bits uintptr
		bitmap, _, _ := pCreateDIBSection.Call(0, uintptr(unsafe.Pointer(&info)), 0, uintptr(unsafe.Pointer(&bits)), 0, 0)
		runtime.KeepAlive(&info)
		if bitmap == 0 || bits == 0 {
			if bitmap != 0 {
				pDeleteObject.Call(bitmap)
			}
			return false
		}
		// COLORREF is 0x00BBGGRR. Windows AlphaBlend expects premultiplied BGRA.
		const alpha = uint32(165) // about 65% opaque; reveal the full-screen artwork more clearly
		r8 := uint32(colCard & 0xFF)
		g8 := uint32((colCard >> 8) & 0xFF)
		b8 := uint32((colCard >> 16) & 0xFF)
		pixel := unsafe.Slice((*byte)(unsafe.Pointer(bits)), 4)
		pixel[0] = byte(b8 * alpha / 255)
		pixel[1] = byte(g8 * alpha / 255)
		pixel[2] = byte(r8 * alpha / 255)
		pixel[3] = byte(alpha)
		dc, _, _ := pCreateCompatibleDC.Call(0)
		if dc == 0 {
			pDeleteObject.Call(bitmap)
			return false
		}
		pSelectObject.Call(dc, bitmap)
		cardFillDC, cardFillBitmap, cardFillColor = dc, bitmap, colCard
		runtime.KeepAlive(pixel)
	}
	w, h := int(r.Right-r.Left), int(r.Bottom-r.Top)
	if w <= 0 || h <= 0 {
		return false
	}
	blend := blendFunction{Operation: 0, Flags: 0, SourceConstantAlpha: 255, AlphaFormat: 1}
	ok, _, _ := pAlphaBlend.Call(hdc,
		uintptr(r.Left), uintptr(r.Top), uintptr(w), uintptr(h),
		cardFillDC, 0, 0, 1, 1, uintptr(unsafe.Pointer(&blend)))
	runtime.KeepAlive(&blend)
	return ok != 0
}

func releaseCardFillSurface() {
	if cardFillDC != 0 {
		pDeleteDC.Call(cardFillDC)
		cardFillDC = 0
	}
	if cardFillBitmap != 0 {
		pDeleteObject.Call(cardFillBitmap)
		cardFillBitmap = 0
	}
	cardFillColor = 0
}
