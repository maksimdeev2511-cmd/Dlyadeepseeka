// Package main contains validation for the embedded and per-user updater feed.
package main

import (
	"fmt"
	"net/url"
	"strings"
)

// Publisher sets this once before distributing a public build. With a real
// HTTPS feed embedded here, every user can receive updates without entering a URL.
// It intentionally remains empty until the app has an actual release host.
const publisherUpdateFeedURL = ""

func validateUpdateFeedURL(feed string) (string, error) {
	feed = strings.TrimSpace(feed)
	if feed == "" {
		return "", fmt.Errorf("update server URL is not configured in this build")
	}
	u, err := url.Parse(feed)
	if err != nil || u.Scheme != "https" || u.Host == "" || u.User != nil {
		return "", fmt.Errorf("update feed must be a valid HTTPS URL")
	}
	return u.String(), nil
}

func effectiveUpdateFeedURL(savedURL, embeddedURL string) (string, error) {
	feed := strings.TrimSpace(savedURL)
	if feed == "" {
		feed = strings.TrimSpace(embeddedURL)
	}
	return validateUpdateFeedURL(feed)
}
