package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// RustPlusPairing contains the four values delivered by Rust+ after the user
// pairs their own Steam account with a Rust server. PlayerToken is secret.
type VoidRadarEvent struct {
	ID        string    `json:"id,omitempty"`
	Type      string    `json:"type"`
	Title     string    `json:"title"`
	Message   string    `json:"message"`
	Player    string    `json:"player,omitempty"`
	SteamID   string    `json:"steam_id,omitempty"`
	Grid      string    `json:"grid,omitempty"`
	X         float64   `json:"x,omitempty"`
	Z         float64   `json:"z,omitempty"`
	MapSize   float64   `json:"map_size,omitempty"`
	Server    string    `json:"server,omitempty"`
	Timestamp time.Time `json:"timestamp"`
}

type RustPlusPairing struct {
	Server      string `json:"server"`
	Port        int    `json:"port"`
	PlayerID    string `json:"playerId"`
	PlayerToken string `json:"playerToken"`
}

func (p RustPlusPairing) Validate() error {
	if strings.TrimSpace(p.Server) == "" || strings.ContainsAny(p.Server, " \t\r\n/\\") {
		return errors.New("укажи IP-адрес или имя Rust-сервера из Rust+ pairing")
	}
	if p.Port < 1 || p.Port > 65535 {
		return errors.New("порт Rust+ должен быть от 1 до 65535; это не игровой порт 28015")
	}
	playerID := strings.TrimSpace(p.PlayerID)
	if _, err := strconv.ParseUint(playerID, 10, 64); err != nil || len(playerID) != 17 {
		return errors.New("Player ID должен быть SteamID64 из 17 цифр")
	}
	if _, err := strconv.ParseInt(strings.TrimSpace(p.PlayerToken), 10, 32); err != nil {
		return errors.New("Player Token должен быть числом из уведомления Rust+ Pairing")
	}
	return nil
}

func rustPlusPairingPath() string {
	root := os.Getenv("LOCALAPPDATA")
	if root == "" {
		root, _ = os.UserConfigDir()
	}
	return filepath.Join(root, "VOID Optimizer", "rustplus-pairing.json")
}

func saveRustPlusPairing(p RustPlusPairing) error {
	if err := p.Validate(); err != nil {
		return err
	}
	path := rustPlusPairingPath()
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(p, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func loadRustPlusPairing() RustPlusPairing {
	var p RustPlusPairing
	b, err := os.ReadFile(rustPlusPairingPath())
	if err == nil {
		_ = json.Unmarshal(b, &p)
	}
	return p
}

// RustPlusRadar uses the Rust+ Companion WebSocket protocol. It polls team
// state and map markers, then publishes detections through Rust+ Team Chat.
// It does not inject input into Rust and does not require a server-side plugin.
type RustPlusRadar struct {
	pairing RustPlusPairing
	events  chan<- VoidRadarEvent
	stop    chan struct{}
	done    chan struct{}
	mu      sync.Mutex
	conn    *rustPlusSocket
}

func StartRustPlusRadar(pairing RustPlusPairing, events chan<- VoidRadarEvent) (*RustPlusRadar, error) {
	if err := pairing.Validate(); err != nil {
		return nil, err
	}
	r := &RustPlusRadar{pairing: pairing, events: events, stop: make(chan struct{}), done: make(chan struct{})}
	go r.run()
	return r, nil
}

func (r *RustPlusRadar) Stop() {
	select {
	case <-r.stop:
	default:
		close(r.stop)
	}
	r.mu.Lock()
	if r.conn != nil {
		_ = r.conn.Close()
		r.conn = nil
	}
	r.mu.Unlock()
	select {
	case <-r.done:
	case <-time.After(2 * time.Second):
	}
}

func (r *RustPlusRadar) emit(typ, title, message, player, steamID, grid string) {
	if r.events == nil {
		return
	}
	e := VoidRadarEvent{Type: typ, Title: title, Message: message, Player: player, SteamID: steamID, Grid: grid, Server: r.pairing.Server, Timestamp: time.Now().UTC()}
	select {
	case r.events <- e:
	default:
	}
}

func (r *RustPlusRadar) run() {
	defer close(r.done)
	for {
		select {
		case <-r.stop:
			return
		default:
		}
		conn, err := dialRustPlus(r.pairing)
		if err != nil {
			r.emit("connection_error", "Rust+ не подключён", err.Error(), "", "", "")
			if !waitOrStop(r.stop, 8*time.Second) {
				return
			}
			continue
		}
		r.mu.Lock()
		r.conn = conn
		r.mu.Unlock()
		r.emit("connected", "VOID Radar подключён к Rust+", "Подключение к Rust+ успешно. Проверяю команду и события.", "", "", "")
		r.monitorConnection(conn)
		r.mu.Lock()
		if r.conn == conn {
			r.conn = nil
		}
		r.mu.Unlock()
		_ = conn.Close()
		r.emit("disconnected", "Связь с Rust+ потеряна", "Пробую переподключиться…", "", "", "")
		if !waitOrStop(r.stop, 5*time.Second) {
			return
		}
	}
}

func waitOrStop(stop <-chan struct{}, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-stop:
		return false
	case <-t.C:
		return true
	}
}

func (r *RustPlusRadar) monitorConnection(c *rustPlusSocket) {
	ctx := context.Background()
	info, err := c.getInfo(ctx)
	if err != nil {
		r.emit("connection_error", "Не удалось прочитать сервер Rust+", err.Error(), "", "", "")
		return
	}
	mapSize := float64(info.MapSize)
	if mapSize < 1000 {
		r.emit("connection_error", "Rust+ не вернул размер карты", "Не могу точно определить квадрат смерти без размера карты сервера.", "", "", "")
		return
	}
	team, err := c.getTeamInfo(ctx)
	if err != nil {
		r.emit("connection_error", "Rust+ не отдал состав команды", err.Error(), "", "", "")
		return
	}
	if len(team) == 0 {
		r.emit("waiting_team", "Ожидание команды Rust", "Войди в команду Rust на этом сервере — тогда появятся тиммейты.", "", "", "")
	}
	previous := make(map[string]RustTeamMember, len(team))
	for _, m := range team {
		previous[m.SteamID] = m
	}
	knownMarkers := make(map[uint32]bool)
	markersInitialized := false
	lastMarkers := time.Time{}
	for {
		if !waitOrStop(r.stop, 3*time.Second) {
			return
		}
		fresh, err := c.getTeamInfo(ctx)
		if err != nil {
			return
		}
		for _, cur := range fresh {
			old, existed := previous[cur.SteamID]
			if existed {
				if old.IsAlive && !cur.IsAlive {
					posX, posY := cur.X, cur.Y
					if posX == 0 && posY == 0 {
						posX, posY = old.X, old.Y
					}
					grid := rustPlusGrid(posX, posY, mapSize)
					msg := fmt.Sprintf("[VOID] %s погиб! Квадрат: %s", safeRustChatName(cur.Name), grid)
					if err := c.sendTeamMessage(ctx, msg); err != nil {
						return
					}
					r.emit("teammate_death", "Тиммейт погиб: "+safeRustChatName(cur.Name), msg, cur.Name, cur.SteamID, grid)
				} else if !old.IsOnline && cur.IsOnline {
					msg := "[VOID] " + safeRustChatName(cur.Name) + " подключился к серверу"
					if err := c.sendTeamMessage(ctx, msg); err != nil {
						return
					}
					r.emit("team_join", "Тиммейт подключился", msg, cur.Name, cur.SteamID, "")
				} else if old.IsOnline && !cur.IsOnline {
					msg := "[VOID] " + safeRustChatName(cur.Name) + " вышел с сервера"
					if err := c.sendTeamMessage(ctx, msg); err != nil {
						return
					}
					r.emit("team_leave", "Тиммейт вышел", msg, cur.Name, cur.SteamID, "")
				}
			}
			previous[cur.SteamID] = cur
		}
		if time.Since(lastMarkers) >= 15*time.Second {
			markers, markerErr := c.getMapMarkers(ctx)
			if markerErr == nil {
				for _, marker := range markers {
					if marker.ID == 0 || knownMarkers[marker.ID] {
						continue
					}
					knownMarkers[marker.ID] = true
					if !markersInitialized {
						continue
					}
					grid := rustPlusGrid(marker.X, marker.Y, mapSize)
					msg := rustMarkerChatText(marker, grid)
					if msg == "" {
						continue
					}
					if err := c.sendTeamMessage(ctx, msg); err != nil {
						return
					}
					r.emit("world_event", "Событие Rust: "+markerLabel(marker.Type), msg, "", "", grid)
				}
				markersInitialized = true
				lastMarkers = time.Now()
			}
		}
	}
}

func safeRustChatName(name string) string {
	name = strings.TrimSpace(name)
	name = strings.Map(func(r rune) rune {
		if r < 0x20 || r == 0x7f {
			return -1
		}
		return r
	}, name)
	if name == "" {
		return "Тиммейт"
	}
	if len([]rune(name)) > 32 {
		name = string([]rune(name)[:32])
	}
	return name
}

func rustPlusGrid(x, y, mapSize float64) string {
	if mapSize < 1000 || math.IsNaN(mapSize) || math.IsInf(mapSize, 0) {
		return "?"
	}
	if math.IsNaN(x) || math.IsNaN(y) || math.IsInf(x, 0) || math.IsInf(y, 0) {
		return "?"
	}
	cells := int(math.Round(mapSize/1024.0)) * 7
	if cells < 7 {
		cells = 28
	}
	if cells > 70 {
		cells = 70
	}
	if x < 0 {
		x = 0
	}
	if x >= 1 {
		x = math.Nextafter(1, 0)
	}
	if y < 0 {
		y = 0
	}
	if y >= 1 {
		y = math.Nextafter(1, 0)
	}
	col := int(math.Floor(x * float64(cells)))
	row := int(math.Floor((1 - y) * float64(cells)))
	if row >= cells {
		row = cells - 1
	}
	return rustGridColumn(col) + strconv.Itoa(row+1)
}

func rustGridColumn(n int) string {
	if n < 0 {
		n = 0
	}
	var out string
	for n >= 0 {
		out = string(rune('A'+n%26)) + out
		n = n/26 - 1
	}
	return out
}

func markerLabel(t uint32) string {
	switch t {
	case 4:
		return "CH-47"
	case 5:
		return "Cargo"
	case 6:
		return "Locked Crate"
	case 8:
		return "Patrol Helicopter"
	default:
		return "событие"
	}
}
func rustMarkerChatText(m RustMapMarker, grid string) string {
	switch m.Type {
	case 4:
		return "[VOID] CH-47 замечен. Квадрат: " + grid
	case 5:
		return "[VOID] Cargo Ship замечен. Квадрат: " + grid
	case 6:
		return "[VOID] Locked Crate обнаружен. Квадрат: " + grid
	case 8:
		return "[VOID] Patrol Helicopter замечен. Квадрат: " + grid
	default:
		return ""
	}
}

// ---- Minimal Rust+ protobuf + RFC6455 WebSocket client (no third-party DLLs). ----
type rustPlusSocket struct {
	conn        net.Conn
	reader      *bufio.Reader
	playerID    uint64
	playerToken int32
	seq         uint32
	mu          sync.Mutex
}

type RustTeamMember struct {
	SteamID, Name        string
	X, Y                 float64
	IsOnline, IsAlive    bool
	SpawnTime, DeathTime uint32
}
type rustPlusInfo struct {
	Name    string
	MapSize uint32
}
type RustMapMarker struct {
	ID, Type uint32
	X, Y     float64
}

func dialRustPlus(p RustPlusPairing) (*rustPlusSocket, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
	defer cancel()
	addr := net.JoinHostPort(strings.Trim(strings.TrimSpace(p.Server), "[]"), strconv.Itoa(p.Port))
	conn, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("не удалось открыть Rust+ соединение (%s:%d): %w", p.Server, p.Port, err)
	}
	fail := func(e error) (*rustPlusSocket, error) { _ = conn.Close(); return nil, e }
	keyBytes := make([]byte, 16)
	if _, err := rand.Read(keyBytes); err != nil {
		return fail(err)
	}
	key := base64.StdEncoding.EncodeToString(keyBytes)
	host := net.JoinHostPort(strings.Trim(strings.TrimSpace(p.Server), "[]"), strconv.Itoa(p.Port))
	if strings.Contains(p.Server, ":") && !strings.HasPrefix(p.Server, "[") {
		host = "[" + p.Server + "]:" + strconv.Itoa(p.Port)
	}
	request := "GET / HTTP/1.1\r\nHost: " + host + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\nOrigin: https://companion-rust.facepunch.com\r\n\r\n"
	if _, err := io.WriteString(conn, request); err != nil {
		return fail(err)
	}
	reader := bufio.NewReader(conn)
	_ = conn.SetReadDeadline(time.Now().Add(10 * time.Second))
	resp, err := http.ReadResponse(reader, &http.Request{Method: http.MethodGet})
	if err != nil {
		return fail(fmt.Errorf("ошибка WebSocket handshake: %w", err))
	}
	if resp.StatusCode != http.StatusSwitchingProtocols {
		return fail(fmt.Errorf("сервер Rust+ отклонил WebSocket: HTTP %d (порт должен быть Rust+ app.port, а сервер должен разрешать прямое Rust+ подключение)", resp.StatusCode))
	}
	accept := resp.Header.Get("Sec-WebSocket-Accept")
	sum := sha1.Sum([]byte(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
	if accept != base64.StdEncoding.EncodeToString(sum[:]) {
		return fail(errors.New("Rust+ вернул неверный WebSocket handshake"))
	}
	playerID, _ := strconv.ParseUint(strings.TrimSpace(p.PlayerID), 10, 64)
	token64, _ := strconv.ParseInt(strings.TrimSpace(p.PlayerToken), 10, 32)
	_ = conn.SetReadDeadline(time.Time{})
	return &rustPlusSocket{conn: conn, reader: reader, playerID: playerID, playerToken: int32(token64)}, nil
}

func (s *rustPlusSocket) Close() error {
	if s == nil || s.conn == nil {
		return nil
	}
	// Closing the TCP connection is enough here and avoids racing a close-frame
	// write against a request currently using the same socket.
	return s.conn.Close()
}

func (s *rustPlusSocket) writeFrame(opcode byte, payload []byte) error {
	if s.conn == nil {
		return net.ErrClosed
	}
	var h []byte
	h = append(h, 0x80|(opcode&0x0f))
	n := len(payload)
	switch {
	case n < 126:
		h = append(h, 0x80|byte(n))
	case n <= 65535:
		h = append(h, 0x80|126, byte(n>>8), byte(n))
	default:
		h = append(h, 0x80|127)
		var b [8]byte
		binary.BigEndian.PutUint64(b[:], uint64(n))
		h = append(h, b[:]...)
	}
	mask := make([]byte, 4)
	if _, err := rand.Read(mask); err != nil {
		return err
	}
	h = append(h, mask...)
	masked := make([]byte, n)
	for i := range payload {
		masked[i] = payload[i] ^ mask[i%4]
	}
	if _, err := s.conn.Write(h); err != nil {
		return err
	}
	_, err := s.conn.Write(masked)
	return err
}

func (s *rustPlusSocket) readFrame() (byte, []byte, error) {
	var h [2]byte
	if _, err := io.ReadFull(s.reader, h[:]); err != nil {
		return 0, nil, err
	}
	opcode := h[0] & 0x0f
	masked := h[1]&0x80 != 0
	n := uint64(h[1] & 0x7f)
	if n == 126 {
		var b [2]byte
		if _, err := io.ReadFull(s.reader, b[:]); err != nil {
			return 0, nil, err
		}
		n = uint64(binary.BigEndian.Uint16(b[:]))
	}
	if n == 127 {
		var b [8]byte
		if _, err := io.ReadFull(s.reader, b[:]); err != nil {
			return 0, nil, err
		}
		n = binary.BigEndian.Uint64(b[:])
	}
	if n > 2<<20 {
		return 0, nil, errors.New("Rust+ frame превышает 2 МБ")
	}
	var mask [4]byte
	if masked {
		if _, err := io.ReadFull(s.reader, mask[:]); err != nil {
			return 0, nil, err
		}
	}
	payload := make([]byte, int(n))
	if _, err := io.ReadFull(s.reader, payload); err != nil {
		return 0, nil, err
	}
	if masked {
		for i := range payload {
			payload[i] ^= mask[i%4]
		}
	}
	return opcode, payload, nil
}

func (s *rustPlusSocket) request(ctx context.Context, commandField int, nested []byte) ([]byte, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
	}
	s.seq++
	req := pbVarint(nil, 1, uint64(s.seq))
	req = pbVarint(req, 2, s.playerID)
	req = pbVarint(req, 3, uint64(int64(s.playerToken)))
	req = pbBytes(req, commandField, nested)
	message := pbBytes(nil, 1, req)
	_ = s.conn.SetWriteDeadline(time.Now().Add(8 * time.Second))
	if err := s.writeFrame(2, message); err != nil {
		return nil, err
	}
	_ = s.conn.SetWriteDeadline(time.Time{})
	for {
		_ = s.conn.SetReadDeadline(time.Now().Add(12 * time.Second))
		op, data, err := s.readFrame()
		if err != nil {
			return nil, err
		}
		switch op {
		case 8:
			return nil, errors.New("Rust+ закрыл соединение")
		case 9:
			if err := s.writeFrame(10, data); err != nil {
				return nil, err
			}
			continue
		case 10:
			continue
		case 1, 2:
		default:
			continue
		}
		respSeq, response, parseErr := findResponse(data)
		if respSeq != s.seq {
			continue
		}
		if parseErr != nil {
			return nil, parseErr
		}
		return response, nil
	}
}

func (s *rustPlusSocket) getInfo(ctx context.Context) (rustPlusInfo, error) {
	b, err := s.request(ctx, 8, nil)
	if err != nil {
		return rustPlusInfo{}, err
	}
	var out rustPlusInfo
	fields, e := pbFields(b)
	if e != nil {
		return out, e
	}
	for _, f := range fields {
		if f.num == 6 && f.wire == 2 {
			inner, _ := pbFields(f.data)
			for _, q := range inner {
				if q.num == 1 && q.wire == 2 {
					out.Name = string(q.data)
				}
				if q.num == 5 && q.wire == 0 {
					out.MapSize = uint32(q.v)
				}
			}
		}
	}
	return out, nil
}
func (s *rustPlusSocket) getTeamInfo(ctx context.Context) ([]RustTeamMember, error) {
	b, err := s.request(ctx, 11, nil)
	if err != nil {
		return nil, err
	}
	return parseRustTeamInfo(b)
}
func (s *rustPlusSocket) getMapMarkers(ctx context.Context) ([]RustMapMarker, error) {
	b, err := s.request(ctx, 18, nil)
	if err != nil {
		return nil, err
	}
	return parseRustMapMarkers(b)
}
func (s *rustPlusSocket) sendTeamMessage(ctx context.Context, message string) error {
	msg := pbBytes(nil, 1, []byte(message))
	_, err := s.request(ctx, 13, msg)
	return err
}

// protobuf fields are read without generated code; unknown fields are skipped.
type pbField struct {
	num  int
	wire int
	v    uint64
	data []byte
}

func pbVarint(dst []byte, field int, value uint64) []byte {
	dst = appendUvarint(dst, uint64(field<<3))
	return appendUvarint(dst, value)
}
func pbBytes(dst []byte, field int, value []byte) []byte {
	dst = appendUvarint(dst, uint64(field<<3|2))
	dst = appendUvarint(dst, uint64(len(value)))
	return append(dst, value...)
}
func appendUvarint(dst []byte, v uint64) []byte {
	for v >= 0x80 {
		dst = append(dst, byte(v)|0x80)
		v >>= 7
	}
	return append(dst, byte(v))
}
func consumeUvarint(b []byte, i *int) (uint64, error) {
	var v uint64
	for shift := uint(0); shift < 64; shift += 7 {
		if *i >= len(b) {
			return 0, io.ErrUnexpectedEOF
		}
		c := b[*i]
		*i++
		v |= uint64(c&0x7f) << shift
		if c < 0x80 {
			return v, nil
		}
	}
	return 0, errors.New("protobuf varint overflow")
}
func pbFields(b []byte) ([]pbField, error) {
	out := []pbField{}
	i := 0
	for i < len(b) {
		key, e := consumeUvarint(b, &i)
		if e != nil {
			return nil, e
		}
		f := pbField{num: int(key >> 3), wire: int(key & 7)}
		if f.num <= 0 {
			return nil, errors.New("invalid protobuf field")
		}
		switch f.wire {
		case 0:
			f.v, e = consumeUvarint(b, &i)
			if e != nil {
				return nil, e
			}
		case 1:
			if i+8 > len(b) {
				return nil, io.ErrUnexpectedEOF
			}
			f.data = b[i : i+8]
			i += 8
		case 2:
			n, er := consumeUvarint(b, &i)
			if er != nil {
				return nil, er
			}
			if n > uint64(len(b)-i) {
				return nil, io.ErrUnexpectedEOF
			}
			f.data = b[i : i+int(n)]
			i += int(n)
		case 5:
			if i+4 > len(b) {
				return nil, io.ErrUnexpectedEOF
			}
			f.data = b[i : i+4]
			i += 4
		default:
			return nil, fmt.Errorf("unsupported protobuf wire type %d", f.wire)
		}
		out = append(out, f)
	}
	return out, nil
}
func findResponse(raw []byte) (uint32, []byte, error) {
	outer, e := pbFields(raw)
	if e != nil {
		return 0, nil, e
	}
	for _, f := range outer {
		if f.num == 1 && f.wire == 2 {
			fields, er := pbFields(f.data)
			if er != nil {
				return 0, nil, er
			}
			var seq uint32
			var body []byte
			var apiErr string
			for _, q := range fields {
				if q.num == 1 && q.wire == 0 {
					seq = uint32(q.v)
				}
				if q.num >= 6 && q.num <= 17 && q.wire == 2 {
					body = appendUvarint(body, uint64(q.num<<3|2))
					body = appendUvarint(body, uint64(len(q.data)))
					body = append(body, q.data...)
				}
				if q.num == 5 && q.wire == 2 {
					ef, _ := pbFields(q.data)
					for _, v := range ef {
						if v.num == 1 && v.wire == 2 {
							apiErr = string(v.data)
						}
					}
				}
			}
			if apiErr != "" {
				return seq, nil, errors.New(apiErr)
			}
			return seq, body, nil
		}
	}
	return 0, nil, errors.New("Rust+ response block is missing")
}
func parseRustTeamInfo(body []byte) ([]RustTeamMember, error) {
	fields, err := pbFields(body)
	if err != nil {
		return nil, err
	}
	var teamData []byte
	for _, f := range fields {
		if f.num == 9 && f.wire == 2 {
			teamData = f.data
			break
		}
	}
	if teamData == nil {
		return nil, errors.New("Rust+ не вернул TeamInfo; проверь, что персонаж состоит в команде")
	}
	teamFields, err := pbFields(teamData)
	if err != nil {
		return nil, err
	}
	out := []RustTeamMember{}
	for _, f := range teamFields {
		if f.num != 2 || f.wire != 2 {
			continue
		}
		mf, e := pbFields(f.data)
		if e != nil {
			return nil, e
		}
		var m RustTeamMember
		for _, q := range mf {
			switch {
			case q.num == 1 && q.wire == 0:
				m.SteamID = strconv.FormatUint(q.v, 10)
			case q.num == 2 && q.wire == 2:
				m.Name = string(q.data)
			case (q.num == 3 || q.num == 4) && q.wire == 5:
				v := math.Float32frombits(binary.LittleEndian.Uint32(q.data))
				if q.num == 3 {
					m.X = float64(v)
				} else {
					m.Y = float64(v)
				}
			case q.num == 5 && q.wire == 0:
				m.IsOnline = q.v != 0
			case q.num == 6 && q.wire == 0:
				m.SpawnTime = uint32(q.v)
			case q.num == 7 && q.wire == 0:
				m.IsAlive = q.v != 0
			case q.num == 8 && q.wire == 0:
				m.DeathTime = uint32(q.v)
			}
		}
		if m.SteamID != "" {
			out = append(out, m)
		}
	}
	return out, nil
}
func parseRustMapMarkers(body []byte) ([]RustMapMarker, error) {
	fields, err := pbFields(body)
	if err != nil {
		return nil, err
	}
	var markerData []byte
	for _, f := range fields {
		if f.num == 13 && f.wire == 2 {
			markerData = f.data
			break
		}
	}
	if markerData == nil {
		return nil, nil
	}
	list, err := pbFields(markerData)
	if err != nil {
		return nil, err
	}
	out := []RustMapMarker{}
	for _, f := range list {
		if f.num != 1 || f.wire != 2 {
			continue
		}
		fs, e := pbFields(f.data)
		if e != nil {
			return nil, e
		}
		var m RustMapMarker
		for _, q := range fs {
			switch {
			case q.num == 1 && q.wire == 0:
				m.ID = uint32(q.v)
			case q.num == 2 && q.wire == 0:
				m.Type = uint32(q.v)
			case (q.num == 3 || q.num == 4) && q.wire == 5:
				v := math.Float32frombits(binary.LittleEndian.Uint32(q.data))
				if q.num == 3 {
					m.X = float64(v)
				} else {
					m.Y = float64(v)
				}
			}
		}
		if m.ID != 0 {
			out = append(out, m)
		}
	}
	return out, nil
}
