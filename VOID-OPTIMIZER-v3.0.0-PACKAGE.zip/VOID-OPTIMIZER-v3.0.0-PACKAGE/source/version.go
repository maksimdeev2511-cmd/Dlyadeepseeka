package main

import (
	"strconv"
	"strings"
)

func versionParts(v string) ([3]int, bool) {
	var out [3]int
	v = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(v), "v"))
	parts := strings.Split(v, ".")
	if len(parts) != 3 {
		return out, false
	}
	for i, part := range parts {
		if part == "" {
			return out, false
		}
		for _, ch := range part {
			if ch < '0' || ch > '9' {
				return out, false
			}
		}
		n, err := strconv.Atoi(part)
		if err != nil || n < 0 || n > 999999 {
			return out, false
		}
		out[i] = n
	}
	return out, true
}

func isNewerVersion(latest, current string) bool {
	a, okA := versionParts(latest)
	b, okB := versionParts(current)
	if !okA || !okB {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return a[i] > b[i]
		}
	}
	return false
}
