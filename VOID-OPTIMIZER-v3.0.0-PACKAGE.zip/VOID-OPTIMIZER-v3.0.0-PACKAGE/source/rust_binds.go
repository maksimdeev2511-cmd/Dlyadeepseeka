// Package main contains Rust keybind-file helpers shared with tests.
package main

import (
	"fmt"
	"strings"
)

type rustBindSpec struct {
	ID         string
	DefaultKey string
	TitleRU    string
	DescRU     string
	TitleEN    string
	DescEN     string
	Command    string
}

func rustUtilityBindSpecs() []rustBindSpec {
	return []rustBindSpec{
		{ID: "autorun", DefaultKey: "q", TitleRU: "АВТОБЕГ", DescRU: "Вперёд с бегом; W отменяет движение.", TitleEN: "AUTO-RUN", DescEN: "Move forward while sprinting; W cancels movement.", Command: "forward;sprint"},
		{ID: "crouch", DefaultKey: "z", TitleRU: "ПРИСЕДАНИЕ", DescRU: "Переключатель приседания.", TitleEN: "CROUCH", DescEN: "Crouch toggle.", Command: "duck"},
		{ID: "jumpcrouch", DefaultKey: "n", TitleRU: "ПРЫЖОК + ПРИСЕД", DescRU: "Прыжок и приседание при удержании.", TitleEN: "JUMP + CROUCH", DescEN: "Jump and crouch while held.", Command: "+jump;+duck"},
		{ID: "loot", DefaultKey: "mouse3", TitleRU: "БЫСТРЫЙ ЛУТ", DescRU: "Удерживай и веди курсор по ячейкам инвентаря.", TitleEN: "QUICK LOOT", DescEN: "Hold while moving the cursor across inventory slots.", Command: "+hoverloot"},
		{ID: "voice", DefaultKey: "mouse5", TitleRU: "ГОЛОСОВОЙ ЧАТ", DescRU: "Голосовой чат при удержании.", TitleEN: "VOICE CHAT", DescEN: "Proximity voice while held.", Command: "+voice"},
		{ID: "console", DefaultKey: "f2", TitleRU: "КОНСОЛЬ", DescRU: "Открывает и закрывает консоль Rust.", TitleEN: "CONSOLE", DescEN: "Opens and closes the Rust console.", Command: "consoletoggle"},
		{ID: "bandage", DefaultKey: "b", TitleRU: "КРАФТ БИНТА", DescRU: "Добавляет один бинт в очередь крафта.", TitleEN: "BANDAGE CRAFT", DescEN: "Queues one bandage for crafting.", Command: `"craft.add -2072273936 1"`},
		{ID: "quickalt", DefaultKey: "h", TitleRU: "БЫСТРЫЙ ALT", DescRU: "Изменяет плавность возврата камеры через client.headlerp.", TitleEN: "QUICK ALT", DescEN: "Changes camera-return interpolation via client.headlerp.", Command: `"client.headlerp 100"`},
		{ID: "radius", DefaultKey: "l", TitleRU: "РАДИУС ВЗАИМОДЕЙСТВИЯ", DescRU: "Переключает client.lookatradius между 0, 0.2 и 10.", TitleEN: "INTERACTION RADIUS", DescEN: "Cycles client.lookatradius between 0, 0.2 and 10.", Command: "~client.lookatradius 0;client.lookatradius 0.2;client.lookatradius 10"},
		{ID: "viewmodel", DefaultKey: "f3", TitleRU: "МАСШТАБ РУК", DescRU: "Переключает стандартное и альтернативное отображение рук.", TitleEN: "VIEWMODEL SCALE", DescEN: "Toggles standard and alternate hand display.", Command: `"~graphics.vm_fov_scale true;graphics.vm_fov_scale false"`},
	}
}

func defaultRustBindKeys() map[string]string {
	keys := make(map[string]string, len(rustUtilityBindSpecs()))
	for _, spec := range rustUtilityBindSpecs() {
		keys[spec.ID] = spec.DefaultKey
	}
	return keys
}

func normalizedRustBindKeys(input map[string]string) map[string]string {
	keys := defaultRustBindKeys()
	for id, key := range input {
		if _, ok := keys[id]; ok && validRustCustomKey(key) {
			keys[id] = strings.ToLower(strings.TrimSpace(key))
		}
	}
	return keys
}

func validateRustBindKeys(keys map[string]string) error {
	seen := map[string]string{}
	for _, spec := range rustUtilityBindSpecs() {
		key := strings.ToLower(strings.TrimSpace(keys[spec.ID]))
		if !validRustCustomKey(key) {
			return fmt.Errorf("недопустимая клавиша для %s", spec.ID)
		}
		if previous, exists := seen[key]; exists {
			return fmt.Errorf("клавиша %s назначена одновременно для %s и %s", strings.ToUpper(key), previous, spec.ID)
		}
		seen[key] = spec.ID
	}
	return nil
}

func rustBindKey(line string) string {
	line = strings.TrimSpace(line)
	if line == "" || strings.HasPrefix(line, "//") || strings.HasPrefix(line, "#") {
		return ""
	}
	fields := strings.Fields(line)
	if len(fields) < 3 {
		return ""
	}
	if !strings.EqualFold(fields[0], "bind") && !strings.EqualFold(fields[0], "input.bind") {
		return ""
	}
	return strings.ToLower(strings.Trim(fields[1], "[]"))
}

func mergeRustUtilityBinds(original string) string {
	return mergeRustUtilityBindsWithMap(original, nil)
}

func mergeRustUtilityBindsWithLootKey(original, lootKey string) string {
	keys := defaultRustBindKeys()
	keys["loot"] = lootKey
	return mergeRustUtilityBindsWithMap(original, keys)
}

func mergeRustUtilityBindsWithKeys(original, lootKey, viewmodelKey string) string {
	keys := defaultRustBindKeys()
	keys["loot"] = lootKey
	keys["viewmodel"] = viewmodelKey
	return mergeRustUtilityBindsWithMap(original, keys)
}

// mergeRustUtilityBindsWithMap replaces only VOID-managed assignments. The original
// keys.cfg is backed up by the caller before this function is used.
func mergeRustUtilityBindsWithMap(original string, input map[string]string) string {
	keys := normalizedRustBindKeys(input)
	managed := map[string]bool{}
	for _, spec := range rustUtilityBindSpecs() {
		managed[spec.DefaultKey] = true // migrate legacy VOID defaults cleanly
		managed[keys[spec.ID]] = true
	}
	lines := strings.Split(strings.ReplaceAll(original, "\r\n", "\n"), "\n")
	kept := make([]string, 0, len(lines)+len(keys)+2)
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		key := rustBindKey(line)
		lowerLine := strings.ToLower(trimmed)
		legacyMouse4Loot := key == "mouse4" && (strings.Contains(lowerLine, "hoverloot") || strings.Contains(lowerLine, "oldloot"))
		if managed[key] || legacyMouse4Loot || strings.Contains(lowerLine, "graphics.vm_fov_scale") ||
			strings.HasPrefix(trimmed, "// VOID OPTIMIZER — utility bind") ||
			strings.HasPrefix(trimmed, "// VOID OPTIMIZER — utility binds") ||
			strings.HasPrefix(trimmed, "// VOID OPTIMIZER — customizable utility binds") ||
			strings.HasPrefix(trimmed, "// VOID OPTIMIZER — viewmodel scale toggle") {
			continue
		}
		kept = append(kept, line)
	}
	for len(kept) > 0 && strings.TrimSpace(kept[len(kept)-1]) == "" {
		kept = kept[:len(kept)-1]
	}
	if len(kept) > 0 {
		kept = append(kept, "")
	}
	kept = append(kept, "// VOID OPTIMIZER — utility binds; restore with keys.cfg.void-backup")
	for _, spec := range rustUtilityBindSpecs() {
		kept = append(kept, "bind "+keys[spec.ID]+" "+spec.Command)
	}
	return strings.Join(kept, "\r\n") + "\r\n"
}
