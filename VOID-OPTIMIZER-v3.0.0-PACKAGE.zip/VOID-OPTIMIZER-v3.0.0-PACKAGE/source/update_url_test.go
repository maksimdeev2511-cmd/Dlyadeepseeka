package main

import "testing"

func TestValidateUpdateFeedURL(t *testing.T) {
	cases := []struct {
		name string
		url  string
		ok   bool
	}{
		{name: "https", url: "https://updates.example.net/void/update.json", ok: true},
		{name: "trim spaces", url: "  https://updates.example.net/update.json  ", ok: true},
		{name: "http rejected", url: "http://updates.example.net/update.json", ok: false},
		{name: "no host", url: "https:///update.json", ok: false},
		{name: "credentials rejected", url: "https://user:pass@updates.example.net/update.json", ok: false},
		{name: "empty rejected", url: "", ok: false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := validateUpdateFeedURL(tc.url)
			if tc.ok && err != nil {
				t.Fatalf("expected valid URL, got error: %v", err)
			}
			if !tc.ok && err == nil {
				t.Fatalf("expected invalid URL, got %q", got)
			}
			if tc.ok && got == "" {
				t.Fatal("validated URL is empty")
			}
		})
	}
}

func TestEffectiveUpdateFeedURL(t *testing.T) {
	const embedded = "https://publisher.example/releases/update.json"
	got, err := effectiveUpdateFeedURL("", embedded)
	if err != nil || got != embedded {
		t.Fatalf("expected embedded publisher URL, got %q, err %v", got, err)
	}
	saved := "https://custom.example/update.json"
	got, err = effectiveUpdateFeedURL(saved, embedded)
	if err != nil || got != saved {
		t.Fatalf("saved URL should take precedence, got %q, err %v", got, err)
	}
	if _, err := effectiveUpdateFeedURL("", ""); err == nil {
		t.Fatal("an absent publisher URL must not pretend updates are configured")
	}
}
