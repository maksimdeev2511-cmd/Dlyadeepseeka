package main

import "testing"

func TestRecommendRustHardwareConservativeAndTiers(t *testing.T) {
	low := recommendRustHardware(hardwareInfo{CPU: "Old CPU", GPU: "Intel UHD Graphics", RAMGB: 8, LogicalCPUs: 4})
	if low.Tier != "LOW" || low.Quality != 0 || low.DrawDistance >= 1200 {
		t.Fatalf("unexpected low recommendation: %+v", low)
	}
	balanced := recommendRustHardware(hardwareInfo{GPU: "NVIDIA GeForce RTX 3060", RAMGB: 16, LogicalCPUs: 8})
	if balanced.Tier != "BALANCED" || balanced.DrawDistance < 1400 {
		t.Fatalf("unexpected balanced recommendation: %+v", balanced)
	}
	high := recommendRustHardware(hardwareInfo{GPU: "NVIDIA GeForce RTX 4090", RAMGB: 64, LogicalCPUs: 24, GPUMemoryGB: 24})
	if high.Tier != "HIGH" || high.Quality < 2 || high.DrawDistance < 2000 {
		t.Fatalf("unexpected high recommendation: %+v", high)
	}
	unknown := recommendRustHardware(hardwareInfo{})
	if unknown.Tier != "SAFE" || unknown.Quality != 0 {
		t.Fatalf("unknown hardware should get conservative defaults: %+v", unknown)
	}
}

func TestValidRustCustomKey(t *testing.T) {
	for _, key := range []string{"q", "Mouse4", "F12", "LeftAlt", "tab"} {
		if !validRustCustomKey(key) {
			t.Fatalf("key should be accepted: %s", key)
		}
	}
	for _, key := range []string{"", "bad key", "bind q forward", "../x", ";quit"} {
		if validRustCustomKey(key) {
			t.Fatalf("key should be rejected: %q", key)
		}
	}
}

func TestRecommendRustHardwareRecognizesCommon12GBRadeonWithoutWMIEnoughVRAM(t *testing.T) {
	got := recommendRustHardware(hardwareInfo{
		CPU: "Intel Xeon E5-2690 v4", GPU: "AMD Radeon RX 6700 XT",
		RAMGB: 32, LogicalCPUs: 28, GPUMemoryGB: 4,
	})
	if got.Tier != "HIGH" || got.DrawDistance < 2000 {
		t.Fatalf("RX 6700 XT system should not be misclassified due to WMI VRAM cap: %+v", got)
	}
}

func TestRecommendRustHardwareDoesNotMisclassifyHybridLaptop(t *testing.T) {
	got := recommendRustHardware(hardwareInfo{
		CPU: "Intel Core i7", GPU: "Intel UHD Graphics / NVIDIA GeForce RTX 3060 Laptop GPU",
		RAMGB: 16, LogicalCPUs: 12, GPUMemoryGB: 4,
	})
	if got.Tier != "BALANCED" {
		t.Fatalf("hybrid laptop with a discrete RTX GPU should not be treated as integrated-only: %+v", got)
	}
}

func TestRecommendRustHardwareRecognizesStrongGPUDespiteWMI4GBCap(t *testing.T) {
	got := recommendRustHardware(hardwareInfo{
		CPU: "AMD Ryzen 7", GPU: "NVIDIA GeForce RTX 4070 Laptop GPU",
		RAMGB: 32, LogicalCPUs: 16, GPUMemoryGB: 4,
	})
	if got.Tier != "HIGH" {
		t.Fatalf("strong discrete GPU should use HIGH despite WMI VRAM cap: %+v", got)
	}
}
