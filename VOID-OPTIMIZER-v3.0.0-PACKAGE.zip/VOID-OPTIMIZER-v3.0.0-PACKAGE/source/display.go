//go:build windows

package main

import (
	"fmt"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const (
	enumCurrentSettings = 0xFFFFFFFF
	cdsTest             = 0x00000002
	dmBitsPerPel        = 0x00040000
	dmPelsWidth         = 0x00080000
	dmPelsHeight        = 0x00100000
	dmDisplayFrequency  = 0x00400000
)

type displayMode struct {
	Width, Height, Refresh, Bits int
}

type devModeW struct {
	DeviceName         [32]uint16
	SpecVersion        uint16
	DriverVersion      uint16
	Size               uint16
	DriverExtra        uint16
	Fields             uint32
	PositionX          int32
	PositionY          int32
	DisplayOrientation uint32
	DisplayFixedOutput uint32
	Color              uint16
	Duplex             uint16
	YResolution        uint16
	TTOption           uint16
	Collate            uint16
	FormName           [32]uint16
	LogPixels          uint16
	BitsPerPel         uint32
	PelsWidth          uint32
	PelsHeight         uint32
	DisplayFlags       uint32
	DisplayFrequency   uint32
	ICMMethod          uint32
	ICMIntent          uint32
	MediaType          uint32
	DitherType         uint32
	Reserved1          uint32
	Reserved2          uint32
	PanningWidth       uint32
	PanningHeight      uint32
}

var (
	pEnumDisplaySettings     = user32.NewProc("EnumDisplaySettingsW")
	pChangeDisplaySettingsEx = user32.NewProc("ChangeDisplaySettingsExW")
)

func modeToDevMode(mode displayMode) devModeW {
	// Change only geometry. Forcing the current bit depth can make an otherwise
	// supported resolution fail on HDR, 10-bit, virtual and hybrid display paths.
	dm := devModeW{Size: uint16(unsafe.Sizeof(devModeW{})), Fields: dmPelsWidth | dmPelsHeight}
	dm.PelsWidth = uint32(mode.Width)
	dm.PelsHeight = uint32(mode.Height)
	if mode.Refresh > 0 {
		dm.Fields |= dmDisplayFrequency
		dm.DisplayFrequency = uint32(mode.Refresh)
	}
	return dm
}

func readDisplayMode(index uint32) (displayMode, bool) {
	var dm devModeW
	dm.Size = uint16(unsafe.Sizeof(dm))
	ok, _, _ := pEnumDisplaySettings.Call(0, uintptr(index), uintptr(unsafe.Pointer(&dm)))
	if ok == 0 || dm.PelsWidth == 0 || dm.PelsHeight == 0 {
		return displayMode{}, false
	}
	return displayMode{Width: int(dm.PelsWidth), Height: int(dm.PelsHeight), Refresh: int(dm.DisplayFrequency), Bits: int(dm.BitsPerPel)}, true
}

func refreshDisplayModes() {
	current, ok := readDisplayMode(enumCurrentSettings)
	if ok {
		app.CurrentDisplayMode = current
	}
	modes := make([]displayMode, 0, 64)
	seen := map[string]bool{}
	for i := uint32(0); i < 4096; i++ {
		m, found := readDisplayMode(i)
		if !found {
			break
		}
		if m.Width < 800 || m.Height < 600 || m.Width > 7680 || m.Height > 4320 || m.Refresh < 20 || m.Refresh > 500 {
			continue
		}
		key := fmt.Sprintf("%dx%d@%d", m.Width, m.Height, m.Refresh)
		if !seen[key] {
			seen[key] = true
			modes = append(modes, m)
		}
	}
	if ok {
		key := fmt.Sprintf("%dx%d@%d", current.Width, current.Height, current.Refresh)
		if !seen[key] {
			modes = append(modes, current)
		}
	}
	sort.Slice(modes, func(i, j int) bool {
		if modes[i].Width != modes[j].Width {
			return modes[i].Width < modes[j].Width
		}
		if modes[i].Height != modes[j].Height {
			return modes[i].Height < modes[j].Height
		}
		return modes[i].Refresh > modes[j].Refresh
	})
	app.MonitorModes = modes
	app.MonitorIndex = 0
	for i, m := range modes {
		if ok && m.Width == current.Width && m.Height == current.Height && m.Refresh == current.Refresh {
			app.MonitorIndex = i
			break
		}
	}
}

func displayModeLabel(m displayMode) string {
	if m.Width == 0 || m.Height == 0 {
		return "Режим не определён"
	}
	if m.Refresh > 0 {
		return fmt.Sprintf("%d × %d  •  %d Гц", m.Width, m.Height, m.Refresh)
	}
	return fmt.Sprintf("%d × %d", m.Width, m.Height)
}

func applyDisplayMode(mode displayMode) {
	if mode.Width < 800 || mode.Height < 600 || mode.Width > 7680 || mode.Height > 4320 {
		app.Status = "Недопустимое разрешение. Допустимый диапазон: 800×600 — 7680×4320."
		if app.Language == "en" {
			app.Status = "Invalid resolution. Allowed range: 800×600 to 7680×4320."
		}
		return
	}
	dm := modeToDevMode(mode)
	// Some display drivers report a mode at a nominal refresh rate but reject
	// applying it explicitly. First try the requested refresh; if the driver
	// rejects it, let Windows select the refresh rate for the chosen geometry.
	result, _, _ := pChangeDisplaySettingsEx.Call(0, uintptr(unsafe.Pointer(&dm)), 0, cdsTest, 0)
	if int32(result) != 0 && dm.Fields&dmDisplayFrequency != 0 {
		dm.Fields &^= dmDisplayFrequency
		dm.DisplayFrequency = 0
		result, _, _ = pChangeDisplaySettingsEx.Call(0, uintptr(unsafe.Pointer(&dm)), 0, cdsTest, 0)
	}
	if int32(result) != 0 {
		app.Status = fmt.Sprintf("Драйвер монитора не поддерживает режим %s (код %d). Текущий экран не изменён.", displayModeLabel(mode), int32(result))
		if app.Language == "en" {
			app.Status = fmt.Sprintf("The display driver rejected %s (code %d). The current mode was not changed.", displayModeLabel(mode), int32(result))
		}
		runtime.KeepAlive(&dm)
		return
	}
	old := app.CurrentDisplayMode
	result, _, _ = pChangeDisplaySettingsEx.Call(0, uintptr(unsafe.Pointer(&dm)), 0, 0, 0)
	if int32(result) != 0 && dm.Fields&dmDisplayFrequency != 0 {
		// Retry once without a forced refresh rate; geometry remains the same.
		dm.Fields &^= dmDisplayFrequency
		dm.DisplayFrequency = 0
		testResult, _, _ := pChangeDisplaySettingsEx.Call(0, uintptr(unsafe.Pointer(&dm)), 0, cdsTest, 0)
		if int32(testResult) == 0 {
			result, _, _ = pChangeDisplaySettingsEx.Call(0, uintptr(unsafe.Pointer(&dm)), 0, 0, 0)
		}
	}
	runtime.KeepAlive(&dm)
	if int32(result) != 0 {
		app.Status = fmt.Sprintf("Windows не смогла применить режим (код %d).", int32(result))
		if app.Language == "en" {
			app.Status = fmt.Sprintf("Windows could not apply the display mode (code %d).", int32(result))
		}
		return
	}
	if old.Width > 0 && old.Height > 0 && (old.Width != mode.Width || old.Height != mode.Height || old.Refresh != mode.Refresh) {
		app.PreviousDisplayMode = old
		app.HasPreviousDisplayMode = true
	}
	app.CurrentDisplayMode = mode
	refreshDisplayModes()
	app.Status = "Разрешение применено: " + displayModeLabel(app.CurrentDisplayMode) + ". Если картинка отображается некорректно, используй «Вернуть предыдущее»."
	if app.Language == "en" {
		app.Status = "Resolution applied: " + displayModeLabel(app.CurrentDisplayMode) + ". Use Restore Previous if the display does not look right."
	}
}

func applyCustomDisplayMode() {
	if app.DisplayWidthEdit == 0 || app.DisplayHeightEdit == 0 {
		app.Status = "Поля пользовательского разрешения не созданы."
		if app.Language == "en" {
			app.Status = "Custom resolution fields are unavailable."
		}
		return
	}
	readEdit := func(hwnd uintptr) (int, error) {
		buf := make([]uint16, 32)
		pGetWindowText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		return strconv.Atoi(strings.TrimSpace(syscall.UTF16ToString(buf)))
	}
	width, errW := readEdit(app.DisplayWidthEdit)
	height, errH := readEdit(app.DisplayHeightEdit)
	if errW != nil || errH != nil {
		app.Status = "Введи ширину и высоту целыми числами, например 1920 и 1080."
		if app.Language == "en" {
			app.Status = "Enter the width and height as whole numbers, for example 1920 and 1080."
		}
		return
	}
	if width < 800 || width > 7680 || height < 600 || height > 4320 {
		app.Status = "Разрешение вне допустимого диапазона 800×600 — 7680×4320."
		if app.Language == "en" {
			app.Status = "Resolution is outside the allowed range of 800×600 to 7680×4320."
		}
		return
	}
	mode := app.CurrentDisplayMode
	mode.Width, mode.Height = width, height
	applyDisplayMode(mode)
}

func addDisplayEdits() {
	createEdit := func(hwnd *uintptr, x int, cue string) {
		if *hwnd != 0 {
			return
		}
		class, _ := syscall.UTF16PtrFromString("EDIT")
		style := wsChild | wsVisible | wsBorder | esAutoHScroll
		h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), uintptr(x), 555, 145, 36, app.HWND, 0, app.Instance, 0)
		runtime.KeepAlive(class)
		*hwnd = h
		if h != 0 {
			app.Controls = append(app.Controls, h)
			placeholder, _ := syscall.UTF16PtrFromString(cue)
			pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder)))
			runtime.KeepAlive(placeholder)
		}
	}
	createEdit(&app.DisplayWidthEdit, 520, "Ширина")
	createEdit(&app.DisplayHeightEdit, 680, "Высота")
}

func paintDisplay(hdc uintptr, c rect) {
	topTitle, topBody := "АВТОМАТИЧЕСКОЕ ОБНАРУЖЕНИЕ МОНИТОРА", "VOID читает активное разрешение, частоту обновления и список режимов, которые сообщает драйвер дисплея."
	section, custom, safe := "ТЕКУЩИЙ РЕЖИМ И СПИСОК", "СВОЁ РАЗРЕШЕНИЕ", "БЕЗОПАСНОСТЬ"
	currentLabel, countLabel := "Сейчас: ", "Доступных режимов: %d"
	chooseHint := "Выбирай только режимы, которые реально поддерживает монитор. Windows сначала проверяет совместимость и только затем меняет картинку."
	widthLabel, heightLabel := "Ширина (px)", "Высота (px)"
	customHint := "Например: 1920 × 1080. Пользовательский режим будет применён только если его принимает драйвер."
	safeHint := "Не поддерживаемые монитором разрешения не применяются. Настройка меняет текущий режим Windows, а не разгоняет панель и не меняет её физические характеристики."
	if app.Language == "en" {
		topTitle, topBody = "AUTOMATIC DISPLAY DETECTION", "VOID reads the active resolution, refresh rate and display modes exposed by the monitor driver."
		section, custom, safe = "CURRENT MODE AND AVAILABLE MODES", "CUSTOM RESOLUTION", "SAFETY"
		currentLabel, countLabel = "Current: ", "Available modes: %d"
		chooseHint = "Choose only a mode supported by the display. Windows checks compatibility before changing the screen."
		widthLabel, heightLabel = "Width (px)", "Height (px)"
		customHint = "Example: 1920 × 1080. A custom mode is applied only when the display driver accepts it."
		safeHint = "Unsupported resolutions are rejected. This changes the active Windows mode; it does not overclock the panel or alter its physical capabilities."
	}
	card(hdc, rect{260, 125, c.Right - 26, 225}, topTitle, topBody)
	current := displayModeLabel(app.CurrentDisplayMode)
	selected := "Нет поддерживаемых режимов"
	if app.Language == "en" {
		selected = "No supported modes found"
	}
	if len(app.MonitorModes) > 0 && app.MonitorIndex >= 0 && app.MonitorIndex < len(app.MonitorModes) {
		selected = displayModeLabel(app.MonitorModes[app.MonitorIndex])
	}
	card(hdc, rect{260, 245, c.Right - 26, 455}, section, "")
	drawText(hdc, currentLabel+current, rect{285, 295, c.Right - 50, 328}, 13, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colGreen))
	drawText(hdc, fmt.Sprintf(countLabel, len(app.MonitorModes)), rect{285, 335, 500, 360}, 9, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	drawText(hdc, selected, rect{590, 292, 805, 340}, 13, true, dtCenter|dtVCenter|dtWordBreak|dtNoPrefix, uint32(colText))
	drawText(hdc, chooseHint, rect{285, 365, c.Right - 55, 420}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	card(hdc, rect{260, 480, c.Right - 26, 680}, custom, "")
	drawText(hdc, widthLabel, rect{520, 525, 665, 550}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, heightLabel, rect{680, 525, 825, 550}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, customHint, rect{285, 648, c.Right - 50, 675}, 7, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	card(hdc, rect{260, 705, c.Right - 26, 800}, safe, safeHint)
	status := app.Status
	if status == "" {
		status = "Монитор определён автоматически."
		if app.Language == "en" {
			status = "Display detected automatically."
		}
	}
	drawText(hdc, status, rect{285, 815, c.Right - 50, 850}, 8, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colPurple))
}
