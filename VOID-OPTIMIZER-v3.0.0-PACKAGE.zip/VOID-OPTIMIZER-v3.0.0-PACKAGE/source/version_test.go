package main

import "testing"

func TestIsNewerVersion(t *testing.T) {
	cases := []struct {
		latest, current string
		want            bool
	}{
		{"1.7.1", "1.7.0", true},
		{"1.8.0", "1.7.9", true},
		{"1.9.0", "1.8.0", true},
		{"1.9.0", "1.9.0", false},
		{"2.0.0", "1.99.99", true},
		{"2.0.0", "1.9.9", true},
		{"2.0.0", "2.0.0", false},
		{"1.7.0", "1.7.0", false},
		{"1.6.9", "1.7.0", false},
		{"v1.8.0", "1.7.0", true},
		{"latest", "1.7.0", false},
		{"1.7", "1.7.0", false},
		{"1.-1.0", "1.7.0", false},
		{"1.+2.0", "1.7.0", false},
	}
	for _, tc := range cases {
		if got := isNewerVersion(tc.latest, tc.current); got != tc.want {
			t.Errorf("isNewerVersion(%q, %q) = %v, want %v", tc.latest, tc.current, got, tc.want)
		}
	}
}

func TestVersionParts(t *testing.T) {
	got, ok := versionParts(" v12.34.56 ")
	if !ok || got != [3]int{12, 34, 56} {
		t.Fatalf("versionParts returned %v, %v", got, ok)
	}
	if _, ok := versionParts("1.2.3.4"); ok {
		t.Fatal("versionParts accepted too many components")
	}
}
