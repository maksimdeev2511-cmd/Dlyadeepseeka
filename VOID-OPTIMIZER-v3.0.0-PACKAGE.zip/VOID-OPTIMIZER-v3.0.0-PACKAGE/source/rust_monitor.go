package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strings"
	"time"
)

const (
	steamRustAppID = 252490
	maxRustWatch   = 7
	steamAPIBase   = "https://api.steampowered.com"
)

var steamID64Pattern = regexp.MustCompile(`^[0-9]{17}$`)
var steamAPIKeyPattern = regexp.MustCompile(`(?i)^[0-9a-f]{32}$`)

type RustTrackedPlayer struct {
	SteamID64       string    `json:"steam_id64"`
	PersonaName     string    `json:"persona_name"`
	ProfileURL      string    `json:"profile_url"`
	AvatarFull      string    `json:"avatar_full,omitempty"`
	PersonaState    int       `json:"persona_state"`
	CurrentGame     string    `json:"current_game,omitempty"`
	RustPlaying     bool      `json:"rust_playing"`
	GameStatusKnown bool      `json:"game_status_known"`
	RustHours       float64   `json:"rust_hours,omitempty"`
	RustHours2Weeks float64   `json:"rust_hours_2weeks,omitempty"`
	HoursKnown      bool      `json:"hours_known"`
	HoursError      string    `json:"hours_error,omitempty"`
	LastLogoff      time.Time `json:"last_logoff,omitempty"`
	CheckedAt       time.Time `json:"checked_at"`
}

type rustMonitorResult struct {
	Players []RustTrackedPlayer
	Err     error
}

type steamSummariesResponse struct {
	Response struct {
		Players []struct {
			SteamID       string `json:"steamid"`
			PersonaName   string `json:"personaname"`
			ProfileURL    string `json:"profileurl"`
			AvatarFull    string `json:"avatarfull"`
			PersonaState  int    `json:"personastate"`
			GameID        string `json:"gameid"`
			GameExtraInfo string `json:"gameextrainfo"`
			LastLogoff    int64  `json:"lastlogoff"`
		} `json:"players"`
	} `json:"response"`
}

type steamOwnedGamesResponse struct {
	Response struct {
		GameCount int `json:"game_count"`
		Games     []struct {
			AppID           int `json:"appid"`
			PlaytimeForever int `json:"playtime_forever"`
			Playtime2Weeks  int `json:"playtime_2weeks"`
		} `json:"games"`
	} `json:"response"`
}

func validSteamID64(id string) bool    { return steamID64Pattern.MatchString(strings.TrimSpace(id)) }
func validSteamAPIKey(key string) bool { return steamAPIKeyPattern.MatchString(strings.TrimSpace(key)) }

// fetchRustPlayers reads only Steam's documented public profile/game-library fields.
// A missing game-library response is treated as private/hidden, never as zero hours.
func fetchRustPlayers(ctx context.Context, client *http.Client, baseURL, apiKey string, steamIDs []string) ([]RustTrackedPlayer, error) {
	apiKey = strings.TrimSpace(apiKey)
	if !validSteamAPIKey(apiKey) {
		return nil, errors.New("нужен корректный Steam Web API key (32 символа)")
	}
	ids := make([]string, 0, len(steamIDs))
	seen := map[string]bool{}
	for _, id := range steamIDs {
		id = strings.TrimSpace(id)
		if !validSteamID64(id) {
			return nil, fmt.Errorf("некорректный SteamID64: %q", id)
		}
		if !seen[id] {
			seen[id] = true
			ids = append(ids, id)
		}
	}
	if len(ids) == 0 {
		return nil, errors.New("список наблюдения пуст")
	}
	if len(ids) > maxRustWatch {
		return nil, fmt.Errorf("можно отслеживать не более %d профилей", maxRustWatch)
	}
	if client == nil {
		client = &http.Client{Timeout: 12 * time.Second}
	}
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	if baseURL == "" {
		baseURL = steamAPIBase
	}

	q := url.Values{}
	q.Set("key", apiKey)
	q.Set("steamids", strings.Join(ids, ","))
	var summaries steamSummariesResponse
	if err := steamGETJSON(ctx, client, baseURL+"/ISteamUser/GetPlayerSummaries/v2/?"+q.Encode(), &summaries); err != nil {
		return nil, fmt.Errorf("Steam profile API: %w", err)
	}
	byID := make(map[string]RustTrackedPlayer, len(ids))
	for _, p := range summaries.Response.Players {
		if !validSteamID64(p.SteamID) {
			continue
		}
		player := RustTrackedPlayer{
			SteamID64: p.SteamID, PersonaName: p.PersonaName, ProfileURL: p.ProfileURL,
			AvatarFull: p.AvatarFull, PersonaState: p.PersonaState,
			CurrentGame: p.GameExtraInfo, CheckedAt: time.Now(),
		}
		if p.LastLogoff > 0 {
			player.LastLogoff = time.Unix(p.LastLogoff, 0).UTC()
		}
		gameID := strings.TrimSpace(p.GameID)
		gameName := strings.EqualFold(strings.TrimSpace(p.GameExtraInfo), "Rust")
		if gameID == fmt.Sprint(steamRustAppID) || gameName {
			player.RustPlaying = true
			player.GameStatusKnown = true
			player.CurrentGame = "Rust"
		} else if gameID != "" || p.PersonaState == 0 {
			player.RustPlaying = false
			player.GameStatusKnown = true
		}
		byID[p.SteamID] = player
	}

	out := make([]RustTrackedPlayer, 0, len(ids))
	for _, id := range ids {
		player, ok := byID[id]
		if !ok {
			return nil, fmt.Errorf("Steam не вернул профиль %s: профиль может быть скрыт или ID неверен", id)
		}
		gamesQ := url.Values{}
		gamesQ.Set("key", apiKey)
		gamesQ.Set("steamid", id)
		gamesQ.Set("include_appinfo", "0")
		gamesQ.Set("include_played_free_games", "1")
		gamesQ.Set("appids_filter[0]", fmt.Sprint(steamRustAppID))
		var owned steamOwnedGamesResponse
		gamesURL := baseURL + "/IPlayerService/GetOwnedGames/v1/?" + gamesQ.Encode()
		if err := steamGETJSON(ctx, client, gamesURL, &owned); err != nil {
			player.HoursError = err.Error()
		} else {
			for _, game := range owned.Response.Games {
				if game.AppID == steamRustAppID {
					player.RustHours = float64(game.PlaytimeForever) / 60
					player.RustHours2Weeks = float64(game.Playtime2Weeks) / 60
					player.HoursKnown = true
					break
				}
			}
			if !player.HoursKnown {
				player.HoursError = "часы скрыты в настройках приватности Steam или игра не отображается"
			}
		}
		out = append(out, player)
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].PersonaName < out[j].PersonaName })
	return out, nil
}

func steamGETJSON(ctx context.Context, client *http.Client, endpoint string, dst any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return err
	}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
		return fmt.Errorf("HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(body)))
	}
	dec := json.NewDecoder(io.LimitReader(resp.Body, 2<<20))
	if err := dec.Decode(dst); err != nil {
		return fmt.Errorf("ошибка чтения ответа: %w", err)
	}
	return nil
}

// rustPlayerTransition returns a notification only when Steam exposed a known state.
// Unknown/private game status must not be misreported as a player leaving Rust.
func rustPlayerTransition(previous, current RustTrackedPlayer) string {
	if !current.GameStatusKnown || !previous.GameStatusKnown || previous.RustPlaying == current.RustPlaying {
		return ""
	}
	name := current.PersonaName
	if strings.TrimSpace(name) == "" {
		name = current.SteamID64
	}
	if current.RustPlaying {
		return name + " зашёл в Rust"
	}
	return name + " вышел из Rust"
}

func rustPresenceLabel(p RustTrackedPlayer) string {
	if p.GameStatusKnown && p.RustPlaying {
		return "В RUST СЕЙЧАС"
	}
	if p.GameStatusKnown && !p.RustPlaying && p.PersonaState == 0 {
		return "НЕ В СЕТИ"
	}
	if p.GameStatusKnown && !p.RustPlaying {
		return "STEAM ONLINE · НЕ RUST"
	}
	if p.PersonaState == 0 {
		return "НЕ В СЕТИ · ДАННЫЕ ИГРЫ СКРЫТЫ"
	}
	return "STEAM ONLINE · ИГРА СКРЫТА"
}

// normalizeSteamIDs keeps the saved list valid and duplicate-free.
func normalizeSteamIDs(input []string) []string {
	seen := make(map[string]bool)
	out := make([]string, 0, len(input))
	for _, raw := range input {
		id := strings.TrimSpace(raw)
		if !validSteamID64(id) || seen[id] {
			continue
		}
		seen[id] = true
		out = append(out, id)
		if len(out) == maxRustWatch {
			break
		}
	}
	return out
}

// parseSteamIDs accepts one SteamID64 per line, or comma/semicolon separated.
func parseSteamIDs(raw string) ([]string, error) {
	parts := strings.FieldsFunc(raw, func(r rune) bool {
		return r == '\n' || r == '\r' || r == ',' || r == ';' || r == '\t' || r == ' '
	})
	seen := make(map[string]bool)
	ids := make([]string, 0, len(parts))
	for _, part := range parts {
		id := strings.TrimSpace(part)
		if id == "" {
			continue
		}
		if !validSteamID64(id) {
			return nil, fmt.Errorf("некорректный SteamID64: %q — нужен идентификатор из 17 цифр", id)
		}
		if seen[id] {
			continue
		}
		seen[id] = true
		ids = append(ids, id)
		if len(ids) > maxRustWatch {
			return nil, fmt.Errorf("лимит списка — %d игроков", maxRustWatch)
		}
	}
	return ids, nil
}

// rustPlayerTransitions reports only confirmed state changes between two polls.
// Hidden/private statuses and first-seen players never generate false alerts.
func rustPlayerTransitions(previous, current []RustTrackedPlayer) []string {
	before := make(map[string]RustTrackedPlayer, len(previous))
	for _, p := range previous {
		before[p.SteamID64] = p
	}
	var events []string
	for _, now := range current {
		old, ok := before[now.SteamID64]
		if !ok {
			continue
		}
		if event := rustPlayerTransition(old, now); event != "" {
			events = append(events, event)
		}
	}
	return events
}
