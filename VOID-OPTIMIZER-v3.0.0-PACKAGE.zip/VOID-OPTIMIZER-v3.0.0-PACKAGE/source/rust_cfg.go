package main

import (
	"strconv"
	"strings"
)

type rustCFGEntry struct {
	key   string
	value string
}

// buildRustCFGEntries is kept as a simple default for callers and tests.
func buildRustCFGEntries(quality, drawDistance int) []rustCFGEntry {
	return buildRustCFGEntriesWithDisplay(quality, drawDistance, 90, false)
}

// buildRustCFGEntriesWithDisplay creates an adaptive client profile. It only
// writes player-side graphics/performance settings and leaves controls,
// resolution, audio, networking and server variables untouched.
func buildRustCFGEntriesWithDisplay(quality, drawDistance, fov int, vsync bool) []rustCFGEntry {
	if quality < 0 {
		quality = 0
	}
	if quality > 5 {
		quality = 5
	}
	if drawDistance < 500 {
		drawDistance = 500
	}
	// Current Rust's draw-distance slider is capped at 2500 metres.
	if drawDistance > 2500 {
		drawDistance = 2500
	}
	if fov < 70 {
		fov = 70
	}
	if fov > 90 {
		fov = 90
	}

	low := quality == 0
	high := quality >= 3
	shadowMode, shadowLights, queuedFrames := "1", "0", "1"
	lodBias, parallax := "0.5", "0"
	shadowDistance, cascades, pixelLights, shadowMap, shadowPreset := "50", "1", "1", "0", "0"
	anisotropic, softParticles := "1", "False"
	grassDistance, grassQuality := "100", "0"
	antialiasing, maxGibDistance, maxGibLife, maxGibs, minGibLife := "0", "80", "4", "20", "1"
	decorQuality, treeQuality, meshQuality, entityDistance := "40", "200", "500", "2500"
	waterQuality, waterReflections, particleQuality, terrainQuality := "0", "0", "0", "0"
	planarReflections, planarCount, sssQuality := "False", "0", "0"

	if !low {
		// Mid-range profile: keep hard shadows simple and disable the costly
		// water reflections/planar reflection pass.
		shadowMode, shadowLights = "1", "1"
		lodBias, parallax = "0.75", "0"
		shadowDistance, cascades, pixelLights, shadowMap, shadowPreset = "80", "1", "1", "0", "0"
		anisotropic, softParticles = "4", "False"
		grassDistance, grassQuality = "120", "0"
		antialiasing, maxGibDistance, maxGibLife, maxGibs, minGibLife = "1", "100", "5", "30", "2"
		decorQuality, treeQuality, meshQuality, entityDistance = "55", "400", "650", "3500"
		waterQuality, waterReflections, particleQuality, terrainQuality = "1", "0", "30", "45"
	}
	if high {
		// High tier is deliberately not an ultra preset: two shadow cascades,
		// moderate reflections and reduced particles avoid wasting GPU headroom.
		shadowMode, shadowLights, queuedFrames = "2", "2", "2"
		lodBias, parallax = "1", "1"
		shadowDistance, cascades, pixelLights, shadowMap, shadowPreset = "140", "2", "2", "1", "1"
		anisotropic, softParticles = "8", "True"
		grassDistance, grassQuality = "160", "1"
		antialiasing, maxGibDistance, maxGibLife, maxGibs, minGibLife = "2", "130", "8", "45", "4"
		decorQuality, treeQuality, meshQuality, entityDistance = "80", "750", "850", "4500"
		waterQuality, waterReflections, particleQuality, terrainQuality = "1", "1", "60", "80"
		planarReflections, planarCount, sssQuality = "True", "2", "1"
	}

	bool := func(v bool) string {
		if v {
			return "True"
		}
		return "False"
	}
	vsyncValue := "0"
	if vsync {
		vsyncValue = "1"
	}

	return []rustCFGEntry{
		{"graphics.aggressiveshadowlod", bool(true)},
		{"graphics.aggressiveshadowlodwearable", bool(true)},
		{"graphics.contactshadows", bool(false)},
		{"graphics.dof", bool(false)},
		{"graphics.drawdistance", strconv.Itoa(drawDistance)},
		{"graphics.fov", strconv.Itoa(fov)},
		{"graphics.grassshadows", bool(false)},
		{"graphics.hlod", bool(true)},
		{"graphics.impostorshadows", bool(false)},
		{"graphics.jitterspread", "1"},
		{"graphics.lodbias", lodBias},
		{"graphics.maxqueuedframes", queuedFrames},
		{"graphics.parallax", parallax},
		{"graphics.renderscale", "1"},
		{"graphics.shadowlights", shadowLights},
		{"graphics.shadowmode", shadowMode},
		{"graphics.shaderlod", "214"},
		{"graphics.vsync", vsyncValue},
		{"graphics.af", anisotropic},
		{"graphicssettings.numshadowcascades", cascades},
		{"graphicssettings.pixellightcount", pixelLights},
		{"graphicssettings.shadowdistance", shadowDistance},
		{"graphicssettings.shadowmapresolution", shadowMap},
		{"graphicssettings.shadowqualitypreset", shadowPreset},
		{"graphicssettings.softparticles", softParticles},
		{"grass.displacement", bool(false)},
		{"grass.distance", grassDistance},
		{"grass.quality", grassQuality},
		{"grass.refresh_budget", "0.3"},
		{"effects.antialiasing", antialiasing},
		{"effects.ao", bool(false)},
		{"effects.bloom", bool(false)},
		{"effects.creationeffects", bool(false)},
		{"effects.lensdirt", bool(false)},
		{"effects.maxgibdist", maxGibDistance},
		{"effects.maxgiblife", maxGibLife},
		{"effects.maxgibs", maxGibs},
		{"effects.mingiblife", minGibLife},
		{"effects.motionblur", bool(false)},
		{"effects.otherplayerslightflares", bool(false)},
		{"effects.shafts", bool(false)},
		{"effects.sharpen", bool(true)},
		{"effects.showoutlines", bool(true)},
		{"effects.vignet", bool(false)},
		{"decor.quality", decorQuality},
		{"tree.quality", treeQuality},
		{"mesh.quality", meshQuality},
		{"culling.entitymaxdist", entityDistance},
		{"water.quality", waterQuality},
		{"water.reflections", waterReflections},
		{"particle.quality", particleQuality},
		{"terrain.quality", terrainQuality},
		{"reflection.planarreflections", planarReflections},
		{"reflection.planarcount", planarCount},
		{"sss.quality", sssQuality},
		{"gc.buffer_enabled", bool(true)},
	}
}

func cfgLineKey(line string) string {
	line = strings.TrimSpace(line)
	if line == "" || strings.HasPrefix(line, "//") || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
		return ""
	}
	fields := strings.Fields(line)
	if len(fields) == 0 {
		return ""
	}
	return strings.ToLower(fields[0])
}

// mergeRustCFG only replaces VOID's allow-listed rendering keys. Unknown keys,
// user comments, binds and other client preferences are preserved unchanged.
func mergeRustCFG(original string, entries []rustCFGEntry) string {
	managed := make(map[string]string, len(entries))
	for _, e := range entries {
		managed[strings.ToLower(e.key)] = e.value
	}
	lines := strings.Split(strings.ReplaceAll(original, "\r\n", "\n"), "\n")
	kept := make([]string, 0, len(lines)+len(entries))
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if _, ok := managed[cfgLineKey(line)]; ok || strings.HasPrefix(trimmed, "// VOID OPTIMIZER — graphics profile") {
			continue
		}
		kept = append(kept, line)
	}
	for len(kept) > 0 && kept[len(kept)-1] == "" {
		kept = kept[:len(kept)-1]
	}
	if len(kept) > 0 {
		kept = append(kept, "")
	}
	kept = append(kept, "// VOID OPTIMIZER — graphics profile; restore with VOID or edit in Rust")
	for _, e := range entries {
		kept = append(kept, e.key+" \""+e.value+"\"")
	}
	return strings.Join(kept, "\r\n") + "\r\n"
}
