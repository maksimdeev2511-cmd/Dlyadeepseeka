@echo off
setlocal
cd /d "%~dp0"
where go >nul 2>nul
if errorlevel 1 (
  echo Go SDK not found. Install Go 1.23 or newer for Windows x64 from https://go.dev/dl/
  pause
  exit /b 1
)
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -ldflags="-H windowsgui -s -w" -trimpath -o VOID-OPTIMIZER-v3.0.0.exe .
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 add_icon_resource.py VOID-OPTIMIZER-v3.0.0.exe assets\void-icon.ico
  if errorlevel 1 echo Warning: EXE built, but Explorer icon embedding failed.
) else (
  echo Python 3 not found: window icon still loads, Explorer may show default icon.
)
echo Built: %~dp0VOID-OPTIMIZER-v3.0.0.exe
pause
