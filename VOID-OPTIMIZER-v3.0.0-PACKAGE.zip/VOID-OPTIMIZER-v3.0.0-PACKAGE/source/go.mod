module void-optimizer

go 1.23
