//go:build windows

package main

import (
	"crypto/sha256"
	_ "embed"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"
)

const (
	wmDestroy         = 0x0002
	wmPaint           = 0x000F
	wmKeyDown         = 0x0100
	wmSysKeyDown      = 0x0104
	wmNCHitTest       = 0x0084
	wmNCCalcSize      = 0x0083
	wmNCPaint         = 0x0085
	wmNCActivate      = 0x0086
	wmNCLButtonDblClk = 0x00A3
	wmCtlColorEdit    = 0x0133
	wmSize            = 0x0005
	wmCommand         = 0x0111
	wmDrawItem        = 0x002B
	wmTimer           = 0x0113
	wmLButtonDown     = 0x0201
	wmMButtonDown     = 0x0207
	wmXButtonDown     = 0x020B
	wmLButtonUp       = 0x0202
	wmMouseMove       = 0x0200
	wmMouseLeave      = 0x02A3
	wmMouseWheel      = 0x020A
	wmEraseBkgnd      = 0x0014
	wmCancelMode      = 0x001F
	wmCaptureChanged  = 0x0215
	wmSetIcon         = 0x0080
	wmCreate          = 0x0001
	wmSetCursor       = 0x0020
	htClient          = 1
	htCaption         = 2
	htLeft            = 10
	htRight           = 11
	htTop             = 12
	htTopLeft         = 13
	htTopRight        = 14
	htBottom          = 15
	htBottomLeft      = 16
	htBottomRight     = 17
	swShow            = 5
	swMinimize        = 6
	swRestore         = 9
	swMaximize        = 3
	swpNoZOrder       = 0x0004
	swpNoActivate     = 0x0010
	wmAppQuit         = 0x8001
	wsOverlapped      = 0x00CF0000
	wsPopup           = 0x80000000
	wsThickFrame      = 0x00040000
	wsMaximizeBox     = 0x00010000
	wsMinimizeBox     = 0x00020000
	wsVisible         = 0x10000000
	wsClipChildren    = 0x02000000
	wsChild           = 0x40000000
	wsBorder          = 0x00800000
	wsExClientEdge    = 0x00000200
	bsOwnerDraw       = 0x0000000B
	bsNotify          = 0x00004000
	esAutoHScroll     = 0x0080
	esMultiline       = 0x0004
	esPassword        = 0x0020
	esAutoVScroll     = 0x0040
	wsVScroll         = 0x00200000
	odsSelected       = 0x0001
	odsDisabled       = 0x0004
	odsHotlight       = 0x0040
	dtLeft            = 0x00000000
	dtRight           = 0x00000002
	dtTop             = 0x00000000
	dtWordBreak       = 0x00000010
	dtSingleLine      = 0x00000020
	dtVCenter         = 0x00000004
	dtCenter          = 0x00000001
	dtNoPrefix        = 0x00000800
	th32csSnap        = 0x00000002
	ofFileMust        = 0x00001000
	ofPathMust        = 0x00000800
	ofNoChangeDir     = 0x00000008
	imageBitmap       = 0
	imageIcon         = 1
	imageCursor       = 2
	lrLoadFromFile    = 0x0010
	lrDefaultSize     = 0x0040
	srccopy           = 0x00CC0020
	diNormal          = 0x0003
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")

	pGetModuleHandle        = kernel32.NewProc("GetModuleHandleW")
	pGetSystemMetrics       = user32.NewProc("GetSystemMetrics")
	pGetSystemTimes         = kernel32.NewProc("GetSystemTimes")
	pGetSystemPowerStatus   = kernel32.NewProc("GetSystemPowerStatus")
	pGlobalMemoryStatusEx   = kernel32.NewProc("GlobalMemoryStatusEx")
	pCreateToolhelpSnap     = kernel32.NewProc("CreateToolhelp32Snapshot")
	pProcess32First         = kernel32.NewProc("Process32FirstW")
	pProcess32Next          = kernel32.NewProc("Process32NextW")
	pCloseHandle            = kernel32.NewProc("CloseHandle")
	pRegisterClassEx        = user32.NewProc("RegisterClassExW")
	pCreateWindowEx         = user32.NewProc("CreateWindowExW")
	pDefWindowProc          = user32.NewProc("DefWindowProcW")
	pShowWindow             = user32.NewProc("ShowWindow")
	pUpdateWindow           = user32.NewProc("UpdateWindow")
	pGetMessage             = user32.NewProc("GetMessageW")
	pTranslateMessage       = user32.NewProc("TranslateMessage")
	pDispatchMessage        = user32.NewProc("DispatchMessageW")
	pPostQuitMessage        = user32.NewProc("PostQuitMessage")
	pBeginPaint             = user32.NewProc("BeginPaint")
	pEndPaint               = user32.NewProc("EndPaint")
	pGetClientRect          = user32.NewProc("GetClientRect")
	pGetWindowRect          = user32.NewProc("GetWindowRect")
	pScreenToClient         = user32.NewProc("ScreenToClient")
	pSetWindowPos           = user32.NewProc("SetWindowPos")
	pClientToScreen         = user32.NewProc("ClientToScreen")
	pTrackMouseEvent        = user32.NewProc("TrackMouseEvent")
	pMoveFileEx             = kernel32.NewProc("MoveFileExW")
	pDwmSetWindowAttribute  = syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
	pGetWindowText          = user32.NewProc("GetWindowTextW")
	pSetWindowText          = user32.NewProc("SetWindowTextW")
	pIsZoomed               = user32.NewProc("IsZoomed")
	pSetFocus               = user32.NewProc("SetFocus")
	pInvalidateRect         = user32.NewProc("InvalidateRect")
	pDestroyWindow          = user32.NewProc("DestroyWindow")
	pSetCapture             = user32.NewProc("SetCapture")
	pReleaseCapture         = user32.NewProc("ReleaseCapture")
	pSendMessage            = user32.NewProc("SendMessageW")
	pSetTimer               = user32.NewProc("SetTimer")
	pKillTimer              = user32.NewProc("KillTimer")
	pGetDC                  = user32.NewProc("GetDC")
	pReleaseDC              = user32.NewProc("ReleaseDC")
	pGetOpenFileName        = comdlg32.NewProc("GetOpenFileNameW")
	pShellExecute           = shell32.NewProc("ShellExecuteW")
	pGetDeviceGammaRamp     = gdi32.NewProc("GetDeviceGammaRamp")
	pSetDeviceGammaRamp     = gdi32.NewProc("SetDeviceGammaRamp")
	pCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	pCreatePen              = gdi32.NewProc("CreatePen")
	pSelectObject           = gdi32.NewProc("SelectObject")
	pDeleteObject           = gdi32.NewProc("DeleteObject")
	pRoundRect              = gdi32.NewProc("RoundRect")
	pFillRect               = user32.NewProc("FillRect")
	pDrawText               = user32.NewProc("DrawTextW")
	pSetTextColor           = gdi32.NewProc("SetTextColor")
	pSetBkColor             = gdi32.NewProc("SetBkColor")
	pSetBkMode              = gdi32.NewProc("SetBkMode")
	pCreateFont             = gdi32.NewProc("CreateFontW")
	pSetProcessDPIAware     = user32.NewProc("SetProcessDPIAware")
	pCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	pCreateDIBSection       = gdi32.NewProc("CreateDIBSection")
	pBitBlt                 = gdi32.NewProc("BitBlt")
	pDeleteDC               = gdi32.NewProc("DeleteDC")
	pStretchBlt             = gdi32.NewProc("StretchBlt")
	pLoadImage              = user32.NewProc("LoadImageW")
	pDrawIconEx             = user32.NewProc("DrawIconEx")
	pDestroyIcon            = user32.NewProc("DestroyIcon")
	pGetFileAttributes      = kernel32.NewProc("GetFileAttributesW")
	pPostMessage            = user32.NewProc("PostMessageW")
	pGetDlgCtrlID           = user32.NewProc("GetDlgCtrlID")
	pGetStockObject         = gdi32.NewProc("GetStockObject")
	pSaveDC                 = gdi32.NewProc("SaveDC")
	pRestoreDC              = gdi32.NewProc("RestoreDC")
	pIntersectClipRect      = gdi32.NewProc("IntersectClipRect")
	pEllipse                = gdi32.NewProc("Ellipse")
	pMoveToEx               = gdi32.NewProc("MoveToEx")
	pLineTo                 = gdi32.NewProc("LineTo")
	pSetMapMode             = gdi32.NewProc("SetMapMode")
	pSetWindowExtEx         = gdi32.NewProc("SetWindowExtEx")
	pSetViewportExtEx       = gdi32.NewProc("SetViewportExtEx")
	pSetViewportOrgEx       = gdi32.NewProc("SetViewportOrgEx")
	pSetCursor              = user32.NewProc("SetCursor")
	pDestroyCursor          = user32.NewProc("DestroyCursor")
	pLoadCursor             = user32.NewProc("LoadCursorW")
	pGetCursorPos           = user32.NewProc("GetCursorPos")
	pAlphaBlend             = syscall.NewLazyDLL("msimg32.dll").NewProc("AlphaBlend")
	pShellNotifyIcon        = shell32.NewProc("Shell_NotifyIconW")
	pMessageBeep            = user32.NewProc("MessageBeep")
	pFlashWindow            = user32.NewProc("FlashWindow")
)

var (
	colBg       uint32 = 0x140D0B
	colSidebar  uint32 = 0x1C1512
	colCard     uint32 = 0x271F19
	colCardLine uint32 = 0x49385A
	colPurple   uint32 = 0xFF5B9D
	colPurple2  uint32 = 0xBE3666
	colText     uint32 = 0xFAEDF1
	colMuted    uint32 = 0xB99AA4
	colGreen    uint32 = 0x75D6A0
	colOrange   uint32 = 0x55A9FF
)

const appVersion = "3.0.0"

const (
	idOverview               = 100
	idClean                  = 101
	idBoost                  = 102
	idRust                   = 103
	idColors                 = 104
	idScan                   = 200
	idCleanNow               = 201
	idApply                  = 210
	idRestore                = 211
	idDetect                 = 220
	idBrowse                 = 221
	idLow                    = 222
	idBalanced               = 223
	idCustom                 = 224
	idBackup                 = 225
	idVsync                  = 226
	idColorAmd               = 230
	idColorReset             = 231
	idPvp                    = 232
	idSurvival               = 233
	idQuality                = 234
	idOpenRust               = 235
	idTweaks                 = 236
	idSettings               = 237
	idTweakGame              = 238
	idTweakDVR               = 239
	idTweakTrans             = 240
	idTweakFX                = 241
	idTweakRestore           = 242
	idDNSFlush               = 243
	idLang                   = 244
	idTheme                  = 245
	idColorWarm              = 246
	idColorCool              = 247
	idAutostart              = 249
	idRescanHardware         = 250
	idColorNeutral           = 248
	idApplyRustCFG           = 251
	idRestoreRustCFG         = 252
	idTweakAnim              = 253
	idTweakMenu              = 254
	idLangRU                 = 257
	idLangEN                 = 258
	idThemePurple            = 259
	idThemeBlue              = 260
	idUpdate                 = 261
	idCheckUpdates           = 262
	idWindowMinimize         = 270
	idWindowMaximize         = 271
	idWindowClose            = 272
	idLoginContinue          = 273
	idLoginEdit              = 274
	idSaveUpdateURL          = 275
	idRustBinds              = 276
	idApplyBinds             = 277
	idRestoreBinds           = 278
	idTweakOverlay           = 279
	idTweakRustGPU           = 280
	idTweakMouseAccel        = 281
	idColorNightVision       = 282
	idColorDusk              = 283
	idRustAuto               = 284
	idTweakTaskbarAnim       = 285
	idTweakAeroPeek          = 286
	idTweakListAlpha         = 287
	idTweakDragFull          = 288
	idTweakExplorerThumbs    = 289
	idSaveCustomBind         = 290
	idBindKeyEdit            = 291
	idTweakWidgets           = 292
	idTweakTaskView          = 293
	idTweakTaskbarSearch     = 294
	idTweakStartRecs         = 295
	idTweakStartupDelay      = 296
	idTweakRecentFiles       = 297
	idSaveViewmodelBind      = 298
	idViewmodelBindKeyEdit   = 299
	idBindAssignBase         = 310 // ten per-bind key capture buttons
	idHomeOptimize           = 321
	idDisplay                = 322
	idMonitorPrev            = 323
	idMonitorNext            = 324
	idMonitorRefresh         = 325
	idMonitorApply           = 326
	idMonitorCustom          = 327
	idMonitorRestore         = 328
	idTweakBackgroundApps    = 330
	idTweakSearchHighlights  = 331
	idTweakSearchSuggestions = 332
	idRustPlus               = 340
	idRustPlusSave           = 341
	idRustPlusRefresh        = 342
	idRustAPIHelp            = 343
	idRustPlusConnect        = 344
	idRustPlusMap            = 345
	idRustPlusOpenRadar      = 346
	idRustPlusChangelog      = 347
	idRustPlusEventMonitor   = 348
	idVoidRadar              = 349
	idRadarOpen              = 350 // open VOID Radar page
	idRadarCopyToken         = 360
	idRadarCreateConfig      = 361
	idRadarOpenPluginFolder  = 362
	idRustRadarConnect       = 363
	idRustRadarDisconnect    = 364
)

type point struct{ X, Y int32 }
type gdiSize struct{ Cx, Cy int32 }
type rect struct{ Left, Top, Right, Bottom int32 }
type fileTime struct{ Low, High uint32 }
type systemPowerStatus struct {
	ACLineStatus, BatteryFlag, BatteryLifePercent, SystemStatusFlag byte
	BatteryLifeTime, BatteryFullLifeTime                            uint32
}
type notifyIconData struct {
	CbSize           uint32
	HWnd             uintptr
	UID              uint32
	UFlags           uint32
	CallbackMessage  uint32
	HIcon            uintptr
	Tip              [128]uint16
	State            uint32
	StateMask        uint32
	Info             [256]uint16
	TimeoutOrVersion uint32
	InfoTitle        [64]uint16
	InfoFlags        uint32
	GuidItem         [16]byte
	BalloonIcon      uintptr
}
type msg struct {
	Hwnd     uintptr
	Message  uint32
	_        uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       point
	LPrivate uint32
}
type paintStruct struct {
	HDC         uintptr
	Erase       int32
	Paint       rect
	Restore     int32
	IncUpdate   int32
	RGBReserved [32]byte
}
type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}
type drawItem struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	_          uint32
	HwndItem   uintptr
	HDC        uintptr
	RC         rect
	ItemData   uintptr
}
type processEntry32 struct {
	Size        uint32
	Usage       uint32
	PID         uint32
	DefaultHeap uintptr
	ModuleID    uint32
	Threads     uint32
	ParentPID   uint32
	Priority    int32
	Flags       uint32
	ExeFile     [260]uint16
}
type memoryStatusEx struct {
	Length               uint32
	MemoryLoad           uint32
	TotalPhys            uint64
	AvailPhys            uint64
	TotalPageFile        uint64
	AvailPageFile        uint64
	TotalVirtual         uint64
	AvailVirtual         uint64
	AvailExtendedVirtual uint64
}
type openFileName struct {
	Size          uint32
	Owner         uintptr
	Instance      uintptr
	Filter        *uint16
	CustomFilter  *uint16
	MaxCustFilter uint32
	FilterIndex   uint32
	File          *uint16
	MaxFile       uint32
	FileTitle     *uint16
	MaxFileTitle  uint32
	InitialDir    *uint16
	Title         *uint16
	Flags         uint32
	FileOffset    uint16
	FileExtension uint16
	DefExt        *uint16
	CustData      uintptr
	Hook          uintptr
	TemplateName  *uint16
	Reserved      uintptr
	Reserved2     uint32
	FlagsEx       uint32
}
type buttonInfo struct {
	Text    string
	Primary bool
	Bounds  rect
}
type cleanupFile struct {
	Path string
	Size int64
}
type scanResult struct {
	Files  []cleanupFile
	Status string
}
type cleanResult struct {
	Count   int
	Bytes   int64
	Skipped int
	Failed  int
	Status  string
}
type updateManifest struct {
	Version     string `json:"version"`
	DownloadURL string `json:"download_url"`
	SHA256      string `json:"sha256"`
	Notes       string `json:"notes"`
}
type updateResult struct {
	Available    bool
	Manifest     updateManifest
	Status       string
	InstallReady bool
}
type optimizerState struct {
	PreviousPowerPlan string `json:"previousPowerPlan"`
	HadAuto           bool   `json:"hadAuto"`
	Auto              int    `json:"auto"`
	HadAllow          bool   `json:"hadAllow"`
	Allow             int    `json:"allow"`
	BoostTweaks       []int  `json:"boostTweaks"`
}
type regSnapshot struct {
	Exists bool   `json:"exists"`
	Type   string `json:"type"`
	Value  string `json:"value"`
}
type regChange struct{ Key, Name, Desired string }
type prefsState struct {
	Language       string            `json:"language"`
	Theme          string            `json:"theme"`
	Login          string            `json:"login"`
	UpdateFeedURL  string            `json:"update_feed_url,omitempty"`
	CustomLootKey  string            `json:"custom_loot_key,omitempty"`
	ViewmodelKey   string            `json:"viewmodel_key,omitempty"`
	BindKeys       map[string]string `json:"bind_keys,omitempty"`
	RustTrackedIDs []string          `json:"rust_tracked_ids,omitempty"`
}

type appState struct {
	HWND                   uintptr
	Instance               uintptr
	Page                   string
	Controls               []uintptr
	Buttons                map[int]buttonInfo
	Status                 string
	RustFolder             string
	Quality                int
	DrawDistance           int
	FOV                    int
	VSync                  bool
	Brightness             int
	Contrast               int
	Gamma                  int
	RedGain                int
	GreenGain              int
	BlueGain               int
	RustRunning            bool
	RustProfileID          int
	RustBackupReady        bool
	RustBindsBackupReady   bool
	Language               string
	Theme                  string
	Login                  string
	LoginEdit              uintptr
	UpdateURLEdit          uintptr
	DisplayWidthEdit       uintptr
	DisplayHeightEdit      uintptr
	RustAPIKeyEdit         uintptr
	RustIDsEdit            uintptr
	RustRadarServerEdit    uintptr
	RustRadarPortEdit      uintptr
	RustRadarPlayerIDEdit  uintptr
	RustRadarTokenEdit     uintptr
	BackgroundDC           uintptr
	BackgroundBitmap       uintptr
	BackgroundWidth        int
	BackgroundHeight       int
	MonitorModes           []displayMode
	MonitorIndex           int
	CurrentDisplayMode     displayMode
	PreviousDisplayMode    displayMode
	HasPreviousDisplayMode bool
	BindKeyEdit            uintptr
	ViewmodelBindKeyEdit   uintptr
	UpdateFeedURL          string
	CustomLootKey          string
	ViewmodelKey           string
	BindKeys               map[string]string
	CapturingBind          string
	BindScroll             int
	LoginBrush             uintptr
	BannerBitmapBlue       uintptr
	CursorPurple           uintptr
	CursorBlue             uintptr
	ActiveCursor           uintptr
	TweaksBackup           map[string]regSnapshot
	TweaksBackupError      string
	BannerBitmap           uintptr
	AppIcon                uintptr
	GammaOriginal          [768]uint16
	GammaAvailable         bool
	GammaSetFailed         bool
	Dragging               string
	HotButton              int
	PressedButton          int
	TrackingMouse          bool
	ResizeMode             string
	ResizeStartX           int
	ResizeStartY           int
	ResizeStartRect        rect
	Preview                []cleanupFile
	Scanned                bool
	Busy                   bool
	ScanCh                 chan scanResult
	CleanCh                chan cleanResult
	CPUPercent             string
	RAMPercent             string
	LastIdle               uint64
	LastKernel             uint64
	LastUser               uint64
	HasCPUSample           bool
	Autostart              bool
	RustSteamAPIKey        string
	RustTrackedIDs         []string
	RustMonitorPlayers     []RustTrackedPlayer
	RustMonitorEvents      []string
	RustMonitorCh          chan rustMonitorResult
	RustMonitorBusy        bool
	RustMonitorError       string
	RustMonitorLastUpdate  time.Time
	RustMonitorNextCheck   time.Time
	RadarEvents            []VoidRadarEvent
	RadarEventCh           chan VoidRadarEvent
	RadarTrayAdded         bool
	RustRadarPairing       RustPlusPairing
	RustRadarClient        *RustPlusRadar
	RustRadarConnected     bool
	Hardware               hardwareInfo
	HardwareReady          bool
	HardwareCh             chan hardwareInfo
	UpdateAvailable        bool
	UpdateVersion          string
	UpdateURL              string
	UpdateSHA256           string
	UpdateNotes            string
	UpdateStatus           string
	UpdateCh               chan updateResult
	NextUpdateCheck        time.Time
	UpdateInstalling       bool
	TweakScroll            int
	Fullscreen             bool
	WindowedRect           rect
}

// Embedded artwork is extracted to the user's LocalAppData on launch, so the EXE stays self-contained.
//
//go:embed assets/void-banner.bmp
var embeddedBanner []byte

//go:embed assets/void-banner-blue.bmp
var embeddedBannerBlue []byte

//go:embed assets/void-icon.ico
var embeddedIcon []byte

//go:embed assets/void-cursor-purple.cur
var embeddedCursorPurple []byte

//go:embed assets/void-cursor-blue.cur
var embeddedCursorBlue []byte

//go:embed assets/void-background.png
var embeddedBackground []byte

var app = &appState{Page: "overview", Status: "Готов к работе.", CPUPercent: "—", RAMPercent: "—", Quality: 0, DrawDistance: 1500, FOV: 90, Contrast: 100, Gamma: 100, RedGain: 100, GreenGain: 100, BlueGain: 100, Language: "ru", Theme: "purple", TweaksBackup: map[string]regSnapshot{}, Buttons: map[int]buttonInfo{}, CustomLootKey: "mouse3", ViewmodelKey: "f3", BindKeys: defaultRustBindKeys()}

func main() {
	runtime.LockOSThread()
	pSetProcessDPIAware.Call()
	inst, _, _ := pGetModuleHandle.Call(0)
	app.Instance = inst
	prepareAssets()
	loadPrefs()
	app.RadarEventCh = make(chan VoidRadarEvent, 64)
	app.RustRadarPairing = loadRustPlusPairing()
	if strings.TrimSpace(app.Login) == "" {
		app.Page = "login"
	}
	applyTheme()
	loadTweaksBackup()
	if app.TweaksBackupError != "" {
		app.Status = app.TweaksBackupError
	}
	className, _ := syscall.UTF16PtrFromString("VOIDOptimizerWindow")
	proc := syscall.NewCallback(windowProc)
	wc := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), Style: 0x0002 | 0x0001, WndProc: proc, Instance: inst, Icon: app.AppIcon, IconSm: app.AppIcon, Cursor: app.ActiveCursor, ClassName: className}
	regResult, _, _ := pRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	runtime.KeepAlive(&wc)
	runtime.KeepAlive(className)
	if regResult == 0 {
		return
	}
	title, _ := syscall.UTF16PtrFromString("VOID OPTIMIZER")
	// Frameless themed window: the app draws its own title controls and supports
	// native resize hit-tests plus a custom maximize/restore button.
	windowStyle := wsPopup | wsClipChildren
	winX, winY, winW, winH := initialWindowBounds()
	hwnd, _, _ := pCreateWindowEx.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(title)), uintptr(windowStyle), uintptr(winX), uintptr(winY), uintptr(winW), uintptr(winH), 0, 0, inst, 0)
	runtime.KeepAlive(className)
	runtime.KeepAlive(title)
	if hwnd == 0 {
		return
	}
	app.HWND = hwnd
	// The window is fully custom-drawn. Ask DWM not to paint its remaining
	// system border, which otherwise appears as a thin white strip on Win11.
	setDWMColorAttribute(hwnd, 34, 0xFFFFFFFE) // DWMWA_BORDER_COLOR = NONE
	setDWMColorAttribute(hwnd, 35, uint32(colBg))
	if app.AppIcon != 0 {
		pSendMessage.Call(hwnd, wmSetIcon, 1, app.AppIcon)
		pSendMessage.Call(hwnd, wmSetIcon, 0, app.AppIcon)
	}
	captureGamma()
	app.RustFolder = findRust()
	app.RustRunning = rustRunning()
	refreshDisplayModes()
	app.Autostart = autostartEnabled()
	app.HardwareCh = make(chan hardwareInfo, 1)
	go func(ch chan hardwareInfo) { ch <- detectHardware() }(app.HardwareCh)
	startUpdateCheck()
	showButtons()
	pSetTimer.Call(hwnd, 1, 5000, 0)
	pShowWindow.Call(hwnd, swShow)
	pUpdateWindow.Call(hwnd)
	var m msg
	for {
		r, _, _ := pGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
}

func windowProc(hwnd uintptr, message uint32, wParam, lParam uintptr) uintptr {
	switch message {
	case wmCreate:
		return 0
	case wmNCCalcSize, wmNCPaint:
		// Fully consume non-client drawing/calculation: Windows must not add
		// a caption, resize frame, shadow stripe or themed white border.
		return 0
	case wmNCActivate:
		return 1
	case wmSetCursor:
		if uint32(lParam&0xFFFF) == htClient {
			cursor := app.ActiveCursor
			if cursor == 0 {
				cursor, _, _ = pLoadCursor.Call(0, 32512) // IDC_ARROW fallback
				app.ActiveCursor = cursor
			}
			if cursor != 0 {
				pSetCursor.Call(cursor)
				return 1
			}
		}
	case wmNCHitTest:
		sx := int(int16(uint16(lParam)))
		sy := int(int16(uint16(lParam >> 16)))
		pt := point{X: int32(sx), Y: int32(sy)}
		pScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
		var cr rect
		pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&cr)))
		maximized, _, _ := pIsZoomed.Call(hwnd)
		if app.Fullscreen {
			return htClient
		}
		// Keep the outer 8 physical pixels client-visible for the custom resize handler.
		if maximized == 0 && (pt.X < 8 || pt.X >= cr.Right-8 || pt.Y < 8 || pt.Y >= cr.Bottom-8) {
			return htClient
		}
		logicalX, logicalY := deviceToCanvas(int(pt.X), int(pt.Y))
		if logicalY >= 0 && logicalY < 38 && logicalX < 1320-390 {
			return htCaption
		}
		return htClient
	case wmKeyDown, wmSysKeyDown:
		if app.CapturingBind != "" {
			if wParam == 0x1B { // ESC cancels key capture.
				app.CapturingBind = ""
				app.Status = "Назначение клавиши отменено."
				showButtons()
				return 0
			}
			key := rustKeyFromVirtualKey(uint32(wParam))
			if key == "" || !validRustCustomKey(key) {
				app.Status = "Эту клавишу нельзя использовать. Нажми другую клавишу или Esc для отмены."
				invalidate()
				return 0
			}
			assignRustBindKey(app.CapturingBind, key)
			return 0
		}
		if wParam == 0x7A { // F11 toggles true monitor-sized fullscreen.
			toggleFullscreen()
			return 0
		}
	case wmCtlColorEdit:
		if (app.LoginEdit != 0 && lParam == app.LoginEdit) || (app.UpdateURLEdit != 0 && lParam == app.UpdateURLEdit) || (app.BindKeyEdit != 0 && lParam == app.BindKeyEdit) || (app.ViewmodelBindKeyEdit != 0 && lParam == app.ViewmodelBindKeyEdit) || (app.DisplayWidthEdit != 0 && lParam == app.DisplayWidthEdit) || (app.DisplayHeightEdit != 0 && lParam == app.DisplayHeightEdit) || (app.RustAPIKeyEdit != 0 && lParam == app.RustAPIKeyEdit) || (app.RustIDsEdit != 0 && lParam == app.RustIDsEdit) || (app.RustRadarServerEdit != 0 && lParam == app.RustRadarServerEdit) || (app.RustRadarPortEdit != 0 && lParam == app.RustRadarPortEdit) || (app.RustRadarPlayerIDEdit != 0 && lParam == app.RustRadarPlayerIDEdit) || (app.RustRadarTokenEdit != 0 && lParam == app.RustRadarTokenEdit) {
			pSetTextColor.Call(wParam, uintptr(uint32(colText)))
			pSetBkColor.Call(wParam, uintptr(uint32(colCard)))
			if app.LoginBrush == 0 {
				app.LoginBrush, _, _ = pCreateSolidBrush.Call(uintptr(uint32(colCard)))
			}
			return app.LoginBrush
		}
		return 0
	case wmEraseBkgnd:
		return 1
	case wmPaint:
		paint(hwnd)
		return 0
	case wmAppQuit:
		pDestroyWindow.Call(hwnd)
		return 0
	case wmCommand:
		// The login edit is the only native child control. All buttons are
		// painted on the parent surface to avoid themed white corners/flicker.
		return 0
	case wmTimer:
		oldCPU, oldRAM := app.CPUPercent, app.RAMPercent
		refreshMetrics()
		for app.RadarEventCh != nil {
			select {
			case event := <-app.RadarEventCh:
				app.RadarEvents = append([]VoidRadarEvent{event}, app.RadarEvents...)
				if len(app.RadarEvents) > 16 {
					app.RadarEvents = app.RadarEvents[:16]
				}
				app.Status = "VOID Radar: " + event.Title
				if event.Type == "connected" {
					app.RustRadarConnected = true
				}
				if event.Type == "disconnected" || event.Type == "connection_error" {
					app.RustRadarConnected = false
				}
				if event.Type == "teammate_death" || event.Type == "world_event" {
					showVoidRadarNotification(event)
				}
				if app.Page == "void_radar" || app.Page == "rust_plus" {
					invalidate()
				}
			default:
				goto radarQueueDrained
			}
		}
	radarQueueDrained:
		if app.ScanCh != nil {
			select {
			case result := <-app.ScanCh:
				app.Preview = result.Files
				app.Scanned = true
				app.ScanCh = nil
				app.Busy = false
				app.Status = result.Status
				invalidate()
			default:
			}
		}
		if app.CleanCh != nil {
			select {
			case result := <-app.CleanCh:
				app.CleanCh = nil
				app.Busy = false
				app.Preview = nil
				app.Scanned = false
				app.Status = result.Status
				invalidate()
			default:
			}
		}
		if app.HardwareCh != nil {
			select {
			case info := <-app.HardwareCh:
				app.Hardware = info
				app.HardwareReady = info.CPU != "" || info.GPU != "" || info.RAMGB > 0
				app.HardwareCh = nil
				if app.Page == "overview" || app.Page == "settings" {
					if app.HardwareReady {
						app.Status = "Компоненты ПК обнаружены автоматически."
					} else {
						app.Status = "Не удалось получить сведения о комплектующих через Windows."
					}
					invalidate()
				}
			default:
			}
		}
		if app.RustMonitorCh != nil {
			select {
			case result := <-app.RustMonitorCh:
				app.RustMonitorCh = nil
				app.RustMonitorBusy = false
				if result.Err != nil {
					app.RustMonitorError = result.Err.Error()
					app.Status = "Мониторинг Steam: " + result.Err.Error()
				} else {
					app.RustMonitorError = ""
					if len(app.RustMonitorPlayers) > 0 {
						for _, event := range rustPlayerTransitions(app.RustMonitorPlayers, result.Players) {
							app.RustMonitorEvents = append([]string{time.Now().Format("15:04:05") + " · " + event}, app.RustMonitorEvents...)
						}
						if len(app.RustMonitorEvents) > 8 {
							app.RustMonitorEvents = app.RustMonitorEvents[:8]
						}
					}
					app.RustMonitorPlayers = result.Players
					app.RustMonitorLastUpdate = time.Now()
					app.Status = fmt.Sprintf("Мониторинг обновлён: %d профилей. Следующее обновление примерно через 2 минуты.", len(result.Players))
				}
				if app.Page == "rust_plus" {
					invalidate()
				}
			default:
			}
		}
		if app.Page == "rust_plus" && !app.RustMonitorBusy && validSteamAPIKey(app.RustSteamAPIKey) && len(app.RustTrackedIDs) > 0 && !app.RustMonitorNextCheck.IsZero() && time.Now().After(app.RustMonitorNextCheck) {
			startRustMonitor()
		}
		if app.UpdateCh == nil && !app.UpdateAvailable && !app.NextUpdateCheck.IsZero() && time.Now().After(app.NextUpdateCheck) {
			startUpdateCheck()
		}
		if app.UpdateCh != nil {
			select {
			case result := <-app.UpdateCh:
				app.UpdateCh = nil
				app.UpdateStatus = result.Status
				if result.Available {
					app.UpdateAvailable = true
					app.UpdateVersion = result.Manifest.Version
					app.UpdateURL = result.Manifest.DownloadURL
					app.UpdateSHA256 = result.Manifest.SHA256
					app.UpdateNotes = result.Manifest.Notes
					// Automatic mode: when a valid publisher feed reports a newer release,
					// download, verify and stage it without asking the user to click Update.
					startUpdateInstall()
				}
				if result.InstallReady {
					pPostMessage.Call(app.HWND, wmAppQuit, 0, 0)
				} else if app.UpdateInstalling {
					app.UpdateInstalling = false
				}
				invalidate()
			default:
			}
		}
		wasRunning := app.RustRunning
		if app.Page == "rust" {
			app.RustRunning = rustRunning()
		}
		if wasRunning != app.RustRunning {
			if app.RustRunning {
				app.Status = "Rust обнаружен: игра запущена. VOID работает только в режиме наблюдения."
			} else {
				app.Status = "Rust закрыт. Можно безопасно применить или откатить CFG."
			}
			if app.Page == "rust" {
				invalidate()
			}
		}
		if oldCPU != app.CPUPercent || oldRAM != app.RAMPercent {
			invalidateFooter()
		}
		return 0
	case wmMouseWheel:
		delta := int(int16(uint16(wParam >> 16)))
		step := -72 // positive wheel delta moves content up
		if delta < 0 {
			step = 72
		}
		switch app.Page {
		case "tweaks":
			app.TweakScroll += step
			app.TweakScroll = clampInt(app.TweakScroll, 0, tweakScrollMax())
			showButtons()
			invalidate()
		case "rust_binds":
			app.BindScroll += step
			app.BindScroll = clampInt(app.BindScroll, 0, bindScrollMax())
			showButtons()
			invalidate()
		}
		return 0
	case wmMButtonDown:
		if app.CapturingBind != "" {
			assignRustBindKey(app.CapturingBind, "mouse3")
			return 0
		}
	case wmXButtonDown:
		if app.CapturingBind != "" {
			button := uint16(wParam >> 16)
			if button == 1 {
				assignRustBindKey(app.CapturingBind, "mouse4")
			} else if button == 2 {
				assignRustBindKey(app.CapturingBind, "mouse5")
			}
			return 1
		}
	case wmLButtonDown:
		x, y := int(int16(uint16(lParam))), int(int16(uint16(lParam>>16)))
		if beginManualResize(x, y) {
			pSetCapture.Call(hwnd)
			return 0
		}
		logicalX, logicalY := deviceToCanvas(x, y)
		if id := buttonAt(logicalX, logicalY); id != 0 {
			app.PressedButton = id
			app.HotButton = id
			pSetCapture.Call(hwnd)
			invalidate()
			return 0
		}
		logicalX, logicalY = deviceToCanvas(x, y)
		handleMouse(logicalX, logicalY, true)
		if app.Dragging != "" {
			pSetCapture.Call(hwnd)
		}
		return 0
	case wmMouseMove:
		if app.ResizeMode != "" {
			updateManualResize(int(int16(uint16(lParam))), int(int16(uint16(lParam>>16))))
			return 0
		}
		if app.Dragging != "" {
			lx, ly := deviceToCanvas(int(int16(uint16(lParam))), int(int16(uint16(lParam>>16))))
			handleMouse(lx, ly, true)
			return 0
		}
		x, y := int(int16(uint16(lParam))), int(int16(uint16(lParam>>16)))
		lx, ly := deviceToCanvas(x, y)
		newHot := buttonAt(lx, ly)
		if newHot != app.HotButton {
			old := app.HotButton
			app.HotButton = newHot
			invalidateButton(old)
			invalidateButton(newHot)
		}
		if !app.TrackingMouse {
			track := trackMouseEvent{Size: uint32(unsafe.Sizeof(trackMouseEvent{})), Flags: 0x00000002, HWND: hwnd, HoverTime: 0xFFFFFFFF}
			pTrackMouseEvent.Call(uintptr(unsafe.Pointer(&track)))
			app.TrackingMouse = true
			runtime.KeepAlive(&track)
		}
		return 0
	case wmMouseLeave:
		app.TrackingMouse = false
		if app.PressedButton == 0 && app.HotButton != 0 {
			old := app.HotButton
			app.HotButton = 0
			invalidateButton(old)
		}
		return 0
	case wmLButtonUp:
		x, y := int(int16(uint16(lParam))), int(int16(uint16(lParam>>16)))
		if app.ResizeMode != "" {
			app.ResizeMode = ""
			pReleaseCapture.Call()
			return 0
		}
		if app.PressedButton != 0 {
			pressed := app.PressedButton
			app.PressedButton = 0
			lx, ly := deviceToCanvas(x, y)
			app.HotButton = buttonAt(lx, ly)
			pReleaseCapture.Call()
			invalidate()
			if app.HotButton == pressed {
				handleCommand(pressed)
			}
			return 0
		}
		if app.Dragging != "" {
			lx, ly := deviceToCanvas(x, y)
			handleMouse(lx, ly, true)
			app.Dragging = ""
		}
		pReleaseCapture.Call()
		return 0
	case wmCancelMode, wmCaptureChanged:
		app.Dragging = ""
		app.ResizeMode = ""
		app.PressedButton = 0
		return 0
	case wmSize:
		positionWindowChrome()
		refreshButtons()
		invalidate()
		return 0
	case wmDestroy:
		pKillTimer.Call(hwnd, 1)
		if app.RustRadarClient != nil {
			app.RustRadarClient.Stop()
			app.RustRadarClient = nil
		}
		if app.RadarTrayAdded {
			removeVoidRadarTrayIcon()
		}
		restoreGamma()
		releaseCardFillSurface()
		if app.BackgroundDC != 0 {
			pDeleteDC.Call(app.BackgroundDC)
			app.BackgroundDC = 0
		}
		if app.BackgroundBitmap != 0 {
			pDeleteObject.Call(app.BackgroundBitmap)
			app.BackgroundBitmap = 0
		}
		if app.BannerBitmap != 0 {
			pDeleteObject.Call(app.BannerBitmap)
			app.BannerBitmap = 0
		}
		if app.BannerBitmapBlue != 0 {
			pDeleteObject.Call(app.BannerBitmapBlue)
			app.BannerBitmapBlue = 0
		}
		if app.LoginBrush != 0 {
			pDeleteObject.Call(app.LoginBrush)
			app.LoginBrush = 0
		}
		if app.AppIcon != 0 {
			pDestroyIcon.Call(app.AppIcon)
			app.AppIcon = 0
		}
		if app.CursorPurple != 0 {
			pDestroyCursor.Call(app.CursorPurple)
			app.CursorPurple = 0
		}
		if app.CursorBlue != 0 {
			pDestroyCursor.Call(app.CursorBlue)
			app.CursorBlue = 0
		}
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProc.Call(hwnd, uintptr(message), wParam, lParam)
	return r
}

type trackMouseEvent struct {
	Size      uint32
	Flags     uint32
	HWND      uintptr
	HoverTime uint32
}

func initialWindowBounds() (x, y, w, h int) {
	screenW, _, _ := pGetSystemMetrics.Call(0) // SM_CXSCREEN
	screenH, _, _ := pGetSystemMetrics.Call(1) // SM_CYSCREEN
	w, h = 1480, 940
	if screenW > 0 {
		preferred := int(float64(screenW) * 0.90)
		if preferred > w {
			w = preferred
		}
		if w > int(screenW)-40 {
			w = int(screenW) - 40
		}
	}
	if screenH > 0 {
		preferred := int(float64(screenH) * 0.90)
		if preferred > h {
			h = preferred
		}
		if h > int(screenH)-100 {
			h = int(screenH) - 100
		}
	}
	if w < 960 {
		w = maxInt(800, int(screenW)-20)
	}
	if h < 620 {
		h = maxInt(560, int(screenH)-60)
	}
	x = maxInt(0, (int(screenW)-w)/2)
	y = maxInt(0, (int(screenH)-h)/2)
	return
}

func setDWMColorAttribute(hwnd uintptr, attribute uint32, color uint32) {
	if hwnd == 0 {
		return
	}
	value := color
	pDwmSetWindowAttribute.Call(hwnd, uintptr(attribute), uintptr(unsafe.Pointer(&value)), unsafe.Sizeof(value))
	runtime.KeepAlive(&value)
}

func beginManualResize(x, y int) bool {
	maximized, _, _ := pIsZoomed.Call(app.HWND)
	if app.Fullscreen || maximized != 0 {
		return false
	}
	w, h := clientSize()
	const edge = 8
	mode := ""
	left, right, top, bottom := x < edge, x >= w-edge, y < edge, y >= h-edge
	switch {
	case top && left:
		mode = "top-left"
	case top && right:
		mode = "top-right"
	case bottom && left:
		mode = "bottom-left"
	case bottom && right:
		mode = "bottom-right"
	case left:
		mode = "left"
	case right:
		mode = "right"
	case top:
		mode = "top"
	case bottom:
		mode = "bottom"
	default:
		return false
	}
	var wr rect
	pGetWindowRect.Call(app.HWND, uintptr(unsafe.Pointer(&wr)))
	pt := point{X: int32(x), Y: int32(y)}
	pClientToScreen.Call(app.HWND, uintptr(unsafe.Pointer(&pt)))
	app.ResizeMode = mode
	app.ResizeStartX, app.ResizeStartY = int(pt.X), int(pt.Y)
	app.ResizeStartRect = wr
	return true
}

func updateManualResize(x, y int) {
	if app.ResizeMode == "" {
		return
	}
	pt := point{X: int32(x), Y: int32(y)}
	pClientToScreen.Call(app.HWND, uintptr(unsafe.Pointer(&pt)))
	dx, dy := int(pt.X)-app.ResizeStartX, int(pt.Y)-app.ResizeStartY
	r := app.ResizeStartRect
	left, top, right, bottom := int(r.Left), int(r.Top), int(r.Right), int(r.Bottom)
	const minW, minH = 960, 620
	mode := app.ResizeMode
	if strings.Contains(mode, "left") {
		left += dx
	}
	if strings.Contains(mode, "right") {
		right += dx
	}
	if strings.Contains(mode, "top") {
		top += dy
	}
	if strings.Contains(mode, "bottom") {
		bottom += dy
	}
	if right-left < minW {
		if strings.Contains(mode, "left") {
			left = right - minW
		} else {
			right = left + minW
		}
	}
	if bottom-top < minH {
		if strings.Contains(mode, "top") {
			top = bottom - minH
		} else {
			bottom = top + minH
		}
	}
	pSetWindowPos.Call(app.HWND, 0, uintptr(left), uintptr(top), uintptr(right-left), uintptr(bottom-top), swpNoZOrder|swpNoActivate)
}

func hasButton(id int) bool {
	_, ok := app.Buttons[id]
	return ok
}

func clientSize() (int, int) {
	var c rect
	if app.HWND != 0 {
		pGetClientRect.Call(app.HWND, uintptr(unsafe.Pointer(&c)))
	}
	return int(c.Right - c.Left), int(c.Bottom - c.Top)
}

func canvasScaleAndOffset(w, h int) (float64, int, int) {
	if w < 1 || h < 1 {
		return 1, 0, 0
	}
	// Stretch the fixed logical canvas to the full client area. This avoids
	// letterbox gutters and keeps the navigation/sidebar sized to the maximized window.
	return 1, 0, 0
}

func setCanvasTransform(hdc uintptr, w, h int) {
	scale, ox, oy := canvasScaleAndOffset(w, h)
	if scale <= 0 {
		return
	}
	pSetMapMode.Call(hdc, 8) // MM_ANISOTROPIC
	windowExt := gdiSize{1320, 900}
	viewExt := gdiSize{int32(w), int32(h)}
	origin := point{int32(ox), int32(oy)}
	pSetWindowExtEx.Call(hdc, uintptr(windowExt.Cx), uintptr(windowExt.Cy), 0)
	pSetViewportExtEx.Call(hdc, uintptr(viewExt.Cx), uintptr(viewExt.Cy), 0)
	pSetViewportOrgEx.Call(hdc, uintptr(origin.X), uintptr(origin.Y), 0)
	runtime.KeepAlive(&windowExt)
	runtime.KeepAlive(&viewExt)
	runtime.KeepAlive(&origin)
}

func deviceToCanvas(x, y int) (int, int) {
	w, h := clientSize()
	if w < 1 || h < 1 {
		return x, y
	}
	return int(math.Round(float64(x) * 1320 / float64(w))), int(math.Round(float64(y) * 900 / float64(h)))
}

func canvasRectToDevice(x, y, w, h int) (int, int, int, int) {
	cw, ch := clientSize()
	if cw < 1 || ch < 1 {
		return x, y, w, h
	}
	left := int(math.Round(float64(x) * float64(cw) / 1320))
	top := int(math.Round(float64(y) * float64(ch) / 900))
	width := int(math.Round(float64(w) * float64(cw) / 1320))
	height := int(math.Round(float64(h) * float64(ch) / 900))
	return left, top, width, height
}

func positionWindowChrome() {
	if app.HWND == 0 {
		return
	}
	w, h := 1320, 900
	setBounds := func(id, x, y, bw, bh int) {
		if info, ok := app.Buttons[id]; ok {
			info.Bounds = rect{int32(x), int32(y), int32(x + bw), int32(y + bh)}
			app.Buttons[id] = info
		}
	}
	setBounds(idWindowMinimize, w-142, 8, 38, 28)
	setBounds(idWindowMaximize, w-98, 8, 38, 28)
	setBounds(idWindowClose, w-54, 8, 38, 28)
	setBounds(idSettings, 16, h-62, 194, 40)
	setBounds(idCheckUpdates, w-390, 8, 220, 28)
	setBounds(idUpdate, w-390, 8, 220, 28)
	setBounds(idDetect, w-520, 170, 170, 40)
	setBounds(idBrowse, w-338, 170, 230, 40)
	setBounds(idLangRU, w-485, 170, 165, 42)
	setBounds(idLangEN, w-305, 170, 165, 42)
	setBounds(idThemePurple, w-485, 315, 165, 42)
	setBounds(idThemeBlue, w-305, 315, 165, 42)
	setBounds(idAutostart, w-390, 455, 330, 42)
	setBounds(idSaveUpdateURL, w-220, 660, 180, 36)
	setBounds(idRescanHardware, w-390, 780, 330, 36)
	if app.UpdateURLEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(280, 660, maxInt(360, w-530), 34)
		pSetWindowPos.Call(app.UpdateURLEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.LoginEdit != 0 {
		x, y, cw, ch := canvasRectToDevice((w-390)/2, 430, 390, 42)
		pSetWindowPos.Call(app.LoginEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.DisplayWidthEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(520, 555, 145, 36)
		pSetWindowPos.Call(app.DisplayWidthEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.DisplayHeightEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(680, 555, 145, 36)
		pSetWindowPos.Call(app.DisplayHeightEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustAPIKeyEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(280, 368, 330, 34)
		pSetWindowPos.Call(app.RustAPIKeyEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustIDsEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(280, 437, 485, 50)
		pSetWindowPos.Call(app.RustIDsEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustRadarServerEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(280, 235, 450, 34)
		pSetWindowPos.Call(app.RustRadarServerEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustRadarPortEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(750, 235, 150, 34)
		pSetWindowPos.Call(app.RustRadarPortEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustRadarPlayerIDEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(280, 300, 450, 34)
		pSetWindowPos.Call(app.RustRadarPlayerIDEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
	if app.RustRadarTokenEdit != 0 {
		x, y, cw, ch := canvasRectToDevice(750, 300, 360, 34)
		pSetWindowPos.Call(app.RustRadarTokenEdit, 0, uintptr(x), uintptr(y), uintptr(cw), uintptr(ch), swpNoZOrder|swpNoActivate)
	}
}

func showButtons() {
	// Only the first-run login field is a native child control. Destroy it
	// after login; all action/navigation buttons live in the custom canvas.
	if app.Page != "login" && app.LoginEdit != 0 {
		pDestroyWindow.Call(app.LoginEdit)
		app.LoginEdit = 0
	}
	if app.Page != "settings" && app.UpdateURLEdit != 0 {
		pDestroyWindow.Call(app.UpdateURLEdit)
		app.UpdateURLEdit = 0
	}
	if app.Page != "rust_binds" && app.BindKeyEdit != 0 {
		pDestroyWindow.Call(app.BindKeyEdit)
		app.BindKeyEdit = 0
	}
	if app.Page != "rust_binds" && app.ViewmodelBindKeyEdit != 0 {
		pDestroyWindow.Call(app.ViewmodelBindKeyEdit)
		app.ViewmodelBindKeyEdit = 0
	}
	if app.Page != "rust_plus" {
		if app.RustAPIKeyEdit != 0 {
			pDestroyWindow.Call(app.RustAPIKeyEdit)
			app.RustAPIKeyEdit = 0
		}
		if app.RustIDsEdit != 0 {
			pDestroyWindow.Call(app.RustIDsEdit)
			app.RustIDsEdit = 0
		}
	}
	if app.Page != "void_radar" {
		for _, h := range []uintptr{app.RustRadarServerEdit, app.RustRadarPortEdit, app.RustRadarPlayerIDEdit, app.RustRadarTokenEdit} {
			if h != 0 {
				pDestroyWindow.Call(h)
			}
		}
		app.RustRadarServerEdit, app.RustRadarPortEdit, app.RustRadarPlayerIDEdit, app.RustRadarTokenEdit = 0, 0, 0, 0
	}
	if app.Page != "display" {
		if app.DisplayWidthEdit != 0 {
			pDestroyWindow.Call(app.DisplayWidthEdit)
			app.DisplayWidthEdit = 0
		}
		if app.DisplayHeightEdit != 0 {
			pDestroyWindow.Call(app.DisplayHeightEdit)
			app.DisplayHeightEdit = 0
		}
	}
	app.Controls = nil
	app.Buttons = make(map[int]buttonInfo)
	app.HotButton = 0
	app.PressedButton = 0
	w, h := 1320, 900
	if app.Page != "login" {
		nav := []struct {
			id   int
			text string
			y    int
		}{
			{idOverview, tx("ГЛАВНАЯ"), 155}, {idClean, tx("ОЧИСТКА"), 205}, {idBoost, tx("ОПТИМИЗАЦИЯ ПК"), 255},
			{idRust, tx("ОПТИМИЗАЦИЯ RUST"), 305}, {idRustBinds, tx("БИНДЫ RUST"), 355}, {idColors, tx("ЦВЕТА МОНИТОРА"), 405},
			{idDisplay, tx("РАЗРЕШЕНИЕ ЭКРАНА"), 455}, {idTweaks, tx("ТВИКИ WINDOWS"), 505}, {idRustPlus, tx("RUST+"), 555}, {idVoidRadar, tx("VOID RADAR"), 605},
		}
		for _, n := range nav {
			primary := (n.id == idOverview && app.Page == "overview") || (n.id == idClean && app.Page == "clean") || (n.id == idBoost && app.Page == "boost") || (n.id == idRust && app.Page == "rust") || (n.id == idRustBinds && app.Page == "rust_binds") || (n.id == idColors && app.Page == "colors") || (n.id == idTweaks && app.Page == "tweaks") || (n.id == idDisplay && app.Page == "display") || (n.id == idRustPlus && app.Page == "rust_plus") || (n.id == idVoidRadar && app.Page == "void_radar")
			addButton(n.id, n.text, 16, n.y, 194, 42, primary)
		}
		addButton(idSettings, tx("НАСТРОЙКИ"), 16, h-62, 194, 40, app.Page == "settings")
	}
	// Themed window chrome and a built-in update control are always present.
	addButton(idWindowMinimize, "—", w-142, 8, 38, 28, false)
	addButton(idWindowMaximize, "□", w-98, 8, 38, 28, false)
	addButton(idWindowClose, "×", w-54, 8, 38, 28, false)
	if app.UpdateAvailable {
		label := "ОБНОВИТЬ · v" + app.UpdateVersion
		if app.Language == "en" {
			label = "UPDATE · v" + app.UpdateVersion
		}
		addButton(idUpdate, label, w-390, 8, 220, 28, true)
	} else {
		label := "ПРОВЕРИТЬ ОБНОВЛЕНИЯ"
		if app.Language == "en" {
			label = "CHECK FOR UPDATES"
		}
		addButton(idCheckUpdates, label, w-390, 8, 220, 28, false)
	}
	if app.Page == "login" {
		addLoginControls()
	} else {
		switch app.Page {
		case "overview":
			label := "АВТООПТИМИЗАЦИЯ ПК"
			if app.Language == "en" {
				label = "AUTO-OPTIMIZE PC"
			}
			addButton(idHomeOptimize, label, 985, 177, 280, 42, true)
		case "clean":
			addButton(idScan, "СКАНИРОВАТЬ", 280, 250, 160, 42, true)
			addButton(idCleanNow, "УДАЛИТЬ НАЙДЕННОЕ", 454, 250, 220, 42, false)
		case "boost":
			addButton(idApply, "БЫСТРАЯ ОПТИМИЗАЦИЯ", 280, 235, 225, 42, true)
			addButton(idRestore, "ОТКАТИТЬ НАСТРОЙКИ", 520, 235, 215, 42, false)
		case "rust":
			addButton(idDetect, "ОБНОВИТЬ ПОИСК", w-520, 170, 170, 40, true)
			addButton(idBrowse, "ВЫБРАТЬ RUSTCLIENT.EXE", w-338, 170, 230, 40, false)
			addButton(idLow, "МАКС. FPS", 280, 555, 140, 40, app.RustProfileID == 0)
			addButton(idPvp, "PVP", 432, 555, 140, 40, app.RustProfileID == 1)
			addButton(idSurvival, "ВЫЖИВАНИЕ", 584, 555, 140, 40, app.RustProfileID == 2)
			addButton(idQuality, "ДАЛЬНОСТЬ 2000", 736, 555, 160, 40, app.RustProfileID == 3)
			addButton(idRustAuto, "АВТО ПОД ЖЕЛЕЗО", 910, 555, 190, 40, app.RustProfileID == idRustAuto)
			addButton(idOpenRust, "ОТКРЫТЬ ПАПКУ ИГРЫ", 280, 780, 210, 38, false)
			addButton(idApplyRustCFG, "ПРИМЕНИТЬ CFG", 510, 780, 180, 38, true)
			addButton(idRestoreRustCFG, "ОТКАТИТЬ CFG", 706, 780, 160, 38, false)
		case "rust_binds":
			for i := range rustUtilityBindSpecs() {
				y := 205 + i*68 - app.BindScroll
				if y >= 185 && y <= 815 {
					label := "ИЗМЕНИТЬ"
					if app.CapturingBind == rustUtilityBindSpecs()[i].ID {
						label = "НАЖМИ КЛАВИШУ"
					}
					if app.Language == "en" {
						label = "CHANGE KEY"
						if app.CapturingBind == rustUtilityBindSpecs()[i].ID {
							label = "PRESS A KEY"
						}
					}
					addButton(idBindAssignBase+i, label, 1110, y+15, 150, 30, app.CapturingBind == rustUtilityBindSpecs()[i].ID)
				}
			}
			applyLabel, restoreLabel := "УСТАНОВИТЬ БИНДЫ", "ВОССТАНОВИТЬ ОРИГИНАЛ"
			if app.Language == "en" {
				applyLabel, restoreLabel = "APPLY BINDS", "RESTORE ORIGINAL"
			}
			actionY := 205 + len(rustUtilityBindSpecs())*68 + 78 - app.BindScroll
			if actionY >= 190 && actionY <= 845 {
				addButton(idApplyBinds, applyLabel, 280, actionY, 210, 34, true)
				addButton(idRestoreBinds, restoreLabel, 500, actionY, 210, 34, false)
			}
		case "colors":
			labels := []string{"ПУСТЫНЯ", "ЛЕС", "ЗИМА", "НОЧНАЯ ВИДИМОСТЬ", "ЗАКАТ", "СБРОС"}
			if app.Language == "en" {
				labels = []string{"DESERT", "FOREST", "WINTER", "NIGHT VISIBILITY", "DUSK", "RESET"}
			}
			addButton(idColorWarm, labels[0], 280, 790, 125, 38, false)
			addButton(idColorNeutral, labels[1], 413, 790, 110, 38, false)
			addButton(idColorCool, labels[2], 531, 790, 110, 38, false)
			addButton(idColorNightVision, labels[3], 649, 790, 175, 38, true)
			addButton(idColorDusk, labels[4], 832, 790, 110, 38, false)
			addButton(idColorReset, labels[5], 950, 790, 110, 38, false)
		case "tweaks":
			for i, item := range tweakCardCatalog() {
				y := 150 + i*58 - app.TweakScroll
				if y >= 125 && y <= 820 {
					addButton(item.id, tweakButtonLabel(item.id), 1120, y+12, 145, 28, tweakEnabled(item.id))
				}
			}
			actionY := 150 + len(tweakCardCatalog())*58 + 184 - app.TweakScroll
			if actionY >= 125 && actionY <= 845 {
				addButton(idTweakRestore, "ОТКАТИТЬ ВСЕ ТВИКИ", 280, actionY, 220, 38, false)
				addButton(idDNSFlush, "ОЧИСТИТЬ DNS-КЭШ", 520, actionY, 210, 38, false)
			}
		case "void_radar":
			addRustPlusRadarEdits()
			addButton(idRustRadarConnect, "СОХРАНИТЬ И ПОДКЛЮЧИТЬ", 280, 350, 245, 42, true)
			addButton(idRustRadarDisconnect, "ОТКЛЮЧИТЬ", 540, 350, 170, 42, false)
		case "rust_plus":
			addRustMonitorEdits()
			connectLabel, mapLabel := "ПОДКЛЮЧИТЬ RUST+", "ОТКРЫТЬ RUST+ WEB"
			keyLabel, saveLabel, refreshLabel := "ГДЕ ВЗЯТЬ STEAM KEY?", "СОХРАНИТЬ И НАЧАТЬ", "ОБНОВИТЬ СЕЙЧАС"
			deathLabel, botMapLabel, changesLabel := "ОТКРЫТЬ VOID RADAR", "МОНИТОРИНГ СОБЫТИЙ", "ИЗМЕНЕНИЯ RUST+"
			if app.Language == "en" {
				connectLabel, mapLabel = "PAIR RUST+", "OPEN RUST+ WEB"
				keyLabel, saveLabel, refreshLabel = "GET STEAM API KEY", "SAVE & START", "REFRESH NOW"
				deathLabel, botMapLabel, changesLabel = "OPEN VOID RADAR", "EVENT MONITOR", "RUST+ CHANGES"
			}
			addButton(idRustPlusConnect, connectLabel, 850, 178, 190, 42, true)
			addButton(idRustPlusMap, mapLabel, 1048, 178, 210, 42, false)
			addButton(idRustAPIHelp, keyLabel, 625, 365, 140, 34, false)
			addButton(idRustPlusSave, saveLabel, 280, 503, 220, 38, true)
			addButton(idRustPlusRefresh, refreshLabel, 510, 503, 190, 38, false)
			addButton(idRustPlusOpenRadar, deathLabel, 282, 770, 235, 38, false)
			addButton(idRustPlusEventMonitor, botMapLabel, 530, 770, 220, 38, true)
			addButton(idRustPlusChangelog, changesLabel, 765, 770, 205, 38, false)
		case "display":
			refreshLabel, applyLabel, restoreLabel, customLabel := "ОБНОВИТЬ МОНИТОР", "ПРИМЕНИТЬ РАЗРЕШЕНИЕ", "ВЕРНУТЬ ПРЕДЫДУЩЕЕ", "ПРИМЕНИТЬ СВОЁ"
			if app.Language == "en" {
				refreshLabel, applyLabel, restoreLabel, customLabel = "RESCAN DISPLAY", "APPLY RESOLUTION", "RESTORE PREVIOUS", "APPLY CUSTOM"
			}
			addButton(idMonitorRefresh, refreshLabel, 280, 165, 190, 38, false)
			addButton(idMonitorPrev, "‹", 520, 292, 52, 42, false)
			addButton(idMonitorNext, "›", 810, 292, 52, 42, false)
			addButton(idMonitorApply, applyLabel, 280, 390, 250, 42, true)
			addButton(idMonitorRestore, restoreLabel, 550, 390, 230, 42, false)
			addDisplayEdits()
			addButton(idMonitorCustom, customLabel, 760, 600, 190, 42, true)
		case "settings":
			addButton(idLangRU, "РУССКИЙ", w-485, 170, 165, 42, app.Language == "ru")
			addButton(idLangEN, "ENGLISH", w-305, 170, 165, 42, app.Language == "en")
			addButton(idThemePurple, "VOID PURPLE", w-485, 315, 165, 42, app.Theme == "purple")
			addButton(idThemeBlue, "ARCTIC BLUE", w-305, 315, 165, 42, app.Theme == "blue")
			addButton(idAutostart, autostartButtonLabel(), w-390, 455, 330, 42, app.Autostart)
			addButton(idSaveUpdateURL, "СОХРАНИТЬ URL", w-220, 660, 180, 36, true)
			addButton(idRescanHardware, rescanButtonLabel(), w-390, 780, 330, 36, false)
			addUpdateURLEdit()
		}
	}
	positionWindowChrome()
	refreshButtons()
}

func addLoginControls() {
	if app.LoginEdit == 0 {
		class, _ := syscall.UTF16PtrFromString("EDIT")
		style := wsChild | wsVisible | wsBorder | esAutoHScroll
		h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 465, 430, 390, 42, app.HWND, uintptr(idLoginEdit), app.Instance, 0)
		runtime.KeepAlive(class)
		app.LoginEdit = h
		if h != 0 {
			app.Controls = append(app.Controls, h)
		}
	}
	addButton(idLoginContinue, "ПРОДОЛЖИТЬ", 570, 500, 180, 44, true)
	pSetFocus.Call(app.LoginEdit)
}

func addRustPlusRadarEdits() {
	makeEdit := func(slot *uintptr, x, y, w, h int, placeholder string, password bool) {
		if *slot != 0 {
			return
		}
		class, _ := syscall.UTF16PtrFromString("EDIT")
		style := wsChild | wsVisible | wsBorder | esAutoHScroll
		if password {
			style |= esPassword
		}
		hwnd, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), uintptr(x), uintptr(y), uintptr(w), uintptr(h), app.HWND, uintptr(idRustRadarConnect), app.Instance, 0)
		runtime.KeepAlive(class)
		*slot = hwnd
		if hwnd != 0 {
			app.Controls = append(app.Controls, hwnd)
			text := ""
			switch slot {
			case &app.RustRadarServerEdit:
				text = app.RustRadarPairing.Server
			case &app.RustRadarPortEdit:
				if app.RustRadarPairing.Port > 0 {
					text = strconv.Itoa(app.RustRadarPairing.Port)
				}
			case &app.RustRadarPlayerIDEdit:
				text = app.RustRadarPairing.PlayerID
			case &app.RustRadarTokenEdit:
				text = app.RustRadarPairing.PlayerToken
			}
			if text != "" {
				v, _ := syscall.UTF16PtrFromString(text)
				pSetWindowText.Call(hwnd, uintptr(unsafe.Pointer(v)))
				runtime.KeepAlive(v)
			}
			ph, _ := syscall.UTF16PtrFromString(placeholder)
			pSendMessage.Call(hwnd, 0x1501, 1, uintptr(unsafe.Pointer(ph)))
			runtime.KeepAlive(ph)
		}
	}
	makeEdit(&app.RustRadarServerEdit, 280, 235, 450, 34, "IP / адрес сервера из Rust+ pairing", false)
	makeEdit(&app.RustRadarPortEdit, 750, 235, 150, 34, "Rust+ app.port", false)
	makeEdit(&app.RustRadarPlayerIDEdit, 280, 300, 450, 34, "SteamID64 / playerId", false)
	makeEdit(&app.RustRadarTokenEdit, 750, 300, 360, 34, "PlayerToken (секретный)", true)
}

func addRustMonitorEdits() {
	if app.RustAPIKeyEdit == 0 {
		class, _ := syscall.UTF16PtrFromString("EDIT")
		style := wsChild | wsVisible | wsBorder | esAutoHScroll | esPassword
		h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 280, 368, 330, 34, app.HWND, uintptr(idRustPlusSave), app.Instance, 0)
		runtime.KeepAlive(class)
		app.RustAPIKeyEdit = h
		if h != 0 {
			app.Controls = append(app.Controls, h)
			if app.RustSteamAPIKey != "" {
				value, _ := syscall.UTF16PtrFromString(app.RustSteamAPIKey)
				pSetWindowText.Call(h, uintptr(unsafe.Pointer(value)))
				runtime.KeepAlive(value)
			}
			placeholder, _ := syscall.UTF16PtrFromString("Steam Web API Key (не Rust+ ключ)")
			pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder)))
			runtime.KeepAlive(placeholder)
		}
	}
	if app.RustIDsEdit == 0 {
		class, _ := syscall.UTF16PtrFromString("EDIT")
		style := wsChild | wsVisible | wsBorder | esMultiline | esAutoVScroll | wsVScroll
		h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 280, 437, 485, 50, app.HWND, uintptr(idRustPlusSave), app.Instance, 0)
		runtime.KeepAlive(class)
		app.RustIDsEdit = h
		if h != 0 {
			app.Controls = append(app.Controls, h)
			value, _ := syscall.UTF16PtrFromString(strings.Join(app.RustTrackedIDs, "\r\n"))
			pSetWindowText.Call(h, uintptr(unsafe.Pointer(value)))
			runtime.KeepAlive(value)
			placeholder, _ := syscall.UTF16PtrFromString("SteamID64 — по одному на строку (до 7)")
			pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder)))
			runtime.KeepAlive(placeholder)
		}
	}
}

func addUpdateURLEdit() {
	if app.UpdateURLEdit != 0 {
		return
	}
	class, _ := syscall.UTF16PtrFromString("EDIT")
	style := wsChild | wsVisible | esAutoHScroll
	h, _, _ := pCreateWindowEx.Call(0, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 280, 660, 520, 34, app.HWND, uintptr(idSaveUpdateURL), app.Instance, 0)
	runtime.KeepAlive(class)
	app.UpdateURLEdit = h
	if h != 0 {
		app.Controls = append(app.Controls, h)
		value, _ := syscall.UTF16PtrFromString(app.UpdateFeedURL)
		pSetWindowText.Call(h, uintptr(unsafe.Pointer(value)))
		runtime.KeepAlive(value)
		placeholder, _ := syscall.UTF16PtrFromString("https://your-site.example/update.json")
		pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder))) // EM_SETCUEBANNER
		runtime.KeepAlive(placeholder)
	}
}

func addViewmodelBindKeyEdit() {
	if app.ViewmodelBindKeyEdit != 0 {
		return
	}
	class, _ := syscall.UTF16PtrFromString("EDIT")
	style := wsChild | wsVisible | wsBorder | esAutoHScroll
	h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 900, 810, 150, 34, app.HWND, uintptr(idViewmodelBindKeyEdit), app.Instance, 0)
	runtime.KeepAlive(class)
	app.ViewmodelBindKeyEdit = h
	if h != 0 {
		app.Controls = append(app.Controls, h)
		value, _ := syscall.UTF16PtrFromString(strings.ToUpper(app.ViewmodelKey))
		pSetWindowText.Call(h, uintptr(unsafe.Pointer(value)))
		runtime.KeepAlive(value)
		placeholder, _ := syscall.UTF16PtrFromString("F3")
		pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder)))
		runtime.KeepAlive(placeholder)
	}
}

func addBindKeyEdit() {
	if app.BindKeyEdit != 0 {
		return
	}
	class, _ := syscall.UTF16PtrFromString("EDIT")
	style := wsChild | wsVisible | wsBorder | esAutoHScroll
	h, _, _ := pCreateWindowEx.Call(wsExClientEdge, uintptr(unsafe.Pointer(class)), 0, uintptr(style), 900, 750, 150, 34, app.HWND, uintptr(idBindKeyEdit), app.Instance, 0)
	runtime.KeepAlive(class)
	app.BindKeyEdit = h
	if h != 0 {
		app.Controls = append(app.Controls, h)
		value, _ := syscall.UTF16PtrFromString(strings.ToUpper(app.CustomLootKey))
		pSetWindowText.Call(h, uintptr(unsafe.Pointer(value)))
		runtime.KeepAlive(value)
		placeholder, _ := syscall.UTF16PtrFromString("Mouse3")
		pSendMessage.Call(h, 0x1501, 1, uintptr(unsafe.Pointer(placeholder))) // EM_SETCUEBANNER
		runtime.KeepAlive(placeholder)
	}
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func addUpdateButton() {
	// Update affordance is part of the in-app title bar and is rebuilt with
	// the current page. This function remains for async update results.
	if app.HWND != 0 {
		showButtons()
	}
}

func refreshButtons() {
	for id, info := range app.Buttons {
		switch id {
		case idTweakGame, idTweakDVR, idTweakTrans, idTweakFX, idTweakAnim, idTweakMenu, idTweakOverlay, idTweakRustGPU, idTweakMouseAccel, idTweakTaskbarAnim, idTweakAeroPeek, idTweakListAlpha, idTweakDragFull, idTweakExplorerThumbs, idTweakWidgets, idTweakTaskView, idTweakTaskbarSearch, idTweakStartRecs, idTweakStartupDelay, idTweakRecentFiles, idTweakBackgroundApps, idTweakSearchHighlights, idTweakSearchSuggestions:
			info.Text = tweakButtonLabel(id)
			info.Primary = tweakEnabled(id)
		case idAutostart:
			info.Text = autostartButtonLabel()
		case idLow:
			info.Primary = app.RustProfileID == 0
		case idPvp:
			info.Primary = app.RustProfileID == 1
		case idSurvival:
			info.Primary = app.RustProfileID == 2
		case idQuality:
			info.Primary = app.RustProfileID == 3
		case idRustAuto:
			info.Primary = app.RustProfileID == idRustAuto
		case idCheckUpdates:
			info.Text = "ПРОВЕРИТЬ ОБНОВЛЕНИЯ"
			if app.Language == "en" {
				info.Text = "CHECK FOR UPDATES"
			}
		case idLangRU:
			info.Primary = app.Language == "ru"
		case idLangEN:
			info.Primary = app.Language == "en"
		case idThemePurple:
			info.Primary = app.Theme == "purple"
		case idThemeBlue:
			info.Primary = app.Theme == "blue"
		case idWindowMaximize:
			if app.Fullscreen {
				info.Text = "❐"
			} else {
				info.Text = "□"
			}
		case idUpdate:
			info.Text = "ОБНОВИТЬ · v" + app.UpdateVersion
			if app.Language == "en" {
				info.Text = "UPDATE · v" + app.UpdateVersion
			}
		}
		app.Buttons[id] = info
	}
	invalidate()
}

func addButton(id int, text string, x, y, w, h int, primary bool) {
	app.Buttons[id] = buttonInfo{Text: text, Primary: primary, Bounds: rect{int32(x), int32(y), int32(x + w), int32(y + h)}}
}

func drawCustomButtons(hdc uintptr) {
	for id, info := range app.Buttons {
		r := info.Bounds
		if r.Right <= r.Left || r.Bottom <= r.Top {
			continue
		}
		// Window controls are plain glyphs only: no button tiles, outlines or square backgrounds.
		if id == idWindowMinimize || id == idWindowMaximize || id == idWindowClose {
			color := uint32(colMuted)
			if app.HotButton == id || app.PressedButton == id {
				color = uint32(colPurple)
			}
			if id == idWindowClose && (app.HotButton == id || app.PressedButton == id) {
				color = 0x6060FF
			}
			drawText(hdc, info.Text, rect{r.Left, r.Top - 1, r.Right, r.Bottom + 1}, 17, true, dtCenter|dtVCenter|dtSingleLine|dtNoPrefix, color)
			continue
		}
		bg := uint32(colCard)
		if info.Primary {
			bg = uint32(colPurple2)
		}
		// Hover feedback uses a themed outline; the button fill stays unchanged.
		border := uint32(colCardLine)
		penWidth := 1
		if info.Primary {
			border = uint32(colPurple)
		}
		if app.HotButton == id {
			border = uint32(colPurple)
			penWidth = 2
		}
		if app.PressedButton == id {
			border = uint32(colText)
			penWidth = 2
		}
		brush, _, _ := pCreateSolidBrush.Call(uintptr(bg))
		pen, _, _ := pCreatePen.Call(0, uintptr(penWidth), uintptr(border))
		oldB, _, _ := pSelectObject.Call(hdc, brush)
		oldP, _, _ := pSelectObject.Call(hdc, pen)
		pRoundRect.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), 10, 10)
		pSelectObject.Call(hdc, oldB)
		pSelectObject.Call(hdc, oldP)
		textRect := rect{r.Left + 4, r.Top + 2, r.Right - 4, r.Bottom - 2}
		drawText(hdc, info.Text, textRect, 9, true, dtCenter|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colText))
		pDeleteObject.Call(brush)
		pDeleteObject.Call(pen)
	}
}

func buttonAt(x, y int) int {
	bestID, bestArea := 0, int(^uint(0)>>1)
	for id, info := range app.Buttons {
		r := info.Bounds
		if int32(x) < r.Left || int32(x) >= r.Right || int32(y) < r.Top || int32(y) >= r.Bottom {
			continue
		}
		area := int(r.Right-r.Left) * int(r.Bottom-r.Top)
		if area < bestArea {
			bestID, bestArea = id, area
		}
	}
	return bestID
}

func invalidateButton(id int) {
	// Button bounds are expressed in the fixed 1320x900 logical canvas.
	// InvalidateRect expects physical client pixels, so passing these raw
	// bounds misses the button after resize/DPI scaling. Repaint the complete
	// buffered surface to keep hover/pressed feedback reliable at every size.
	if _, ok := app.Buttons[id]; ok {
		invalidate()
	}
}

func darkenColor(color uint32, percent int) uint32 {
	factor := 100 - percent
	r := int(color&0xFF) * factor / 100
	g := int((color>>8)&0xFF) * factor / 100
	b := int((color>>16)&0xFF) * factor / 100
	return uint32(r | (g << 8) | (b << 16))
}

func paint(hwnd uintptr) {
	var ps paintStruct
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	var client rect
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&client)))
	w, h := int(client.Right-client.Left), int(client.Bottom-client.Top)
	if w < 1 || h < 1 {
		pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return
	}

	// Paint the parent window to a memory DC, then copy it once to the screen.
	// This removes the full-window flash caused by the periodic metrics timer.
	memDC, _, _ := pCreateCompatibleDC.Call(hdc)
	if memDC == 0 {
		memDC = hdc
	}
	var memBitmap uintptr
	var oldBitmap uintptr
	if memDC != hdc {
		memBitmap, _, _ = pCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
		if memBitmap != 0 {
			oldBitmap, _, _ = pSelectObject.Call(memDC, memBitmap)
		} else {
			pDeleteDC.Call(memDC)
			memDC = hdc
		}
	}
	fill(memDC, rect{0, 0, int32(w), int32(h)}, uint32(colBg))
	setCanvasTransform(memDC, w, h)
	drawMainSurface(memDC, rect{0, 0, 1320, 900})
	// Restore pixel coordinates before the final screen copy.
	pSetMapMode.Call(memDC, 1) // MM_TEXT
	pSetViewportOrgEx.Call(memDC, 0, 0, 0)
	if memDC != hdc && memBitmap != 0 {
		pBitBlt.Call(hdc, 0, 0, uintptr(w), uintptr(h), memDC, 0, 0, srccopy)
		pSelectObject.Call(memDC, oldBitmap)
		pDeleteObject.Call(memBitmap)
	}
	if memDC != hdc {
		pDeleteDC.Call(memDC)
	}
	pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
}

func drawMainSurface(hdc uintptr, client rect) {
	fill(hdc, client, uint32(colBg))
	drawBackgroundArt(hdc, client)
	fill(hdc, rect{0, 0, 230, client.Bottom}, uint32(colSidebar))
	if app.AppIcon != 0 {
		pDrawIconEx.Call(hdc, 22, 22, app.AppIcon, 60, 60, 0, 0, diNormal)
	}
	drawText(hdc, "VOID", rect{92, 25, 215, 55}, 22, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, "OPTIMIZER", rect{92, 53, 218, 81}, 14, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, "VOID OPTIMIZER "+appVersion, rect{20, 104, 210, 128}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
	// A themed title-control strip replaces the white native Windows caption.
	fill(hdc, rect{230, 0, client.Right, 40}, uint32(colBg))
	drawText(hdc, "VOID OPTIMIZER  •  "+appVersion, rect{260, 10, 620, 32}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colMuted))
	// The selected theme has its own artwork banner.
	drawBanner(hdc, rect{client.Right - 440, 42, client.Right - 24, 94})
	drawThemeSignature(hdc, int(client.Right-440), 42)
	drawThemeSidebarAccent(hdc, int(client.Bottom))
	drawText(hdc, pageTitle(), rect{260, 24, client.Right - 470, 65}, 22, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, pageSubtitle(), rect{262, 70, client.Right - 470, 102}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	switch app.Page {
	case "login":
		paintLogin(hdc, client)
	case "clean":
		paintClean(hdc, client)
	case "boost":
		paintBoost(hdc, client)
	case "rust":
		paintRust(hdc, client)
	case "rust_binds":
		paintRustBinds(hdc, client)
	case "colors":
		paintColors(hdc, client)
	case "tweaks":
		paintTweaks(hdc, client)
	case "settings":
		paintSettings(hdc, client)
	case "display":
		paintDisplay(hdc, client)
	case "rust_plus":
		paintRustPlus(hdc, client)
	case "void_radar":
		paintVoidRadar(hdc, client)
	default:
		paintOverview(hdc, client)
	}
	drawCustomButtons(hdc)
	footer := "CPU " + app.CPUPercent + "     RAM " + app.RAMPercent
	drawText(hdc, footer, rect{260, client.Bottom - 32, client.Right - 24, client.Bottom - 10}, 8, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
}

func drawOutlineEllipse(hdc uintptr, x1, y1, x2, y2, width int, color uint32) {
	pen, _, _ := pCreatePen.Call(0, uintptr(width), uintptr(color))
	oldPen, _, _ := pSelectObject.Call(hdc, pen)
	nullBrush, _, _ := pGetStockObject.Call(5) // NULL_BRUSH
	oldBrush, _, _ := pSelectObject.Call(hdc, nullBrush)
	pEllipse.Call(hdc, uintptr(x1), uintptr(y1), uintptr(x2), uintptr(y2))
	pSelectObject.Call(hdc, oldBrush)
	pSelectObject.Call(hdc, oldPen)
	pDeleteObject.Call(pen)
}

func drawAccentLine(hdc uintptr, x1, y1, x2, y2, width int, color uint32) {
	pen, _, _ := pCreatePen.Call(0, uintptr(width), uintptr(color))
	old, _, _ := pSelectObject.Call(hdc, pen)
	pMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	pLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	pSelectObject.Call(hdc, old)
	pDeleteObject.Call(pen)
}

// Purple gets an orbit/energy motif; Arctic Blue gets a radar/grid motif.
func drawThemeSignature(hdc uintptr, left, top int) {
	cx, cy := left+330, top+42
	if app.Theme == "blue" {
		drawOutlineEllipse(hdc, cx-31, cy-31, cx+31, cy+31, 2, uint32(colPurple))
		drawOutlineEllipse(hdc, cx-19, cy-19, cx+19, cy+19, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx-70, cy, cx+70, cy, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx, cy-38, cx, cy+38, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx-47, cy-27, cx+47, cy+27, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx-47, cy+27, cx+47, cy-27, 1, uint32(colPurple2))
		for i := 0; i < 5; i++ {
			drawAccentLine(hdc, left+24, top+18+i*13, left+70, top+18+i*13, 1, uint32(colCardLine))
		}
		return
	}
	// Asymmetric orbital ellipses create a distinctive VOID signature.
	drawOutlineEllipse(hdc, cx-48, cy-24, cx+48, cy+24, 2, uint32(colPurple))
	drawOutlineEllipse(hdc, cx-34, cy-34, cx+34, cy+34, 1, uint32(colPurple2))
	drawOutlineEllipse(hdc, cx-16, cy-16, cx+16, cy+16, 1, uint32(colPurple))
	drawAccentLine(hdc, cx-65, cy+18, cx+65, cy-18, 2, uint32(colPurple2))
	drawAccentLine(hdc, cx-72, cy+31, cx-50, cy+31, 2, uint32(colPurple))
	drawAccentLine(hdc, cx+50, cy-31, cx+72, cy-31, 2, uint32(colPurple))
}

func drawThemeSidebarAccent(hdc uintptr, bottom int) {
	cx, cy := 115, bottom-160
	if app.Theme == "blue" {
		drawOutlineEllipse(hdc, cx-42, cy-42, cx+42, cy+42, 2, uint32(colCardLine))
		drawOutlineEllipse(hdc, cx-26, cy-26, cx+26, cy+26, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx-52, cy, cx+52, cy, 1, uint32(colPurple))
		drawAccentLine(hdc, cx, cy-52, cx, cy+52, 1, uint32(colPurple))
	} else {
		drawOutlineEllipse(hdc, cx-44, cy-25, cx+44, cy+25, 2, uint32(colPurple2))
		drawOutlineEllipse(hdc, cx-28, cy-42, cx+28, cy+42, 1, uint32(colPurple))
		drawOutlineEllipse(hdc, cx-12, cy-12, cx+12, cy+12, 1, uint32(colPurple2))
		drawAccentLine(hdc, cx-53, cy+34, cx+53, cy-34, 1, uint32(colPurple))
	}
	// A short accent rail visually ties the menu to the active color theme.
	fill(hdc, rect{18, int32(bottom - 245), 21, int32(bottom - 210)}, uint32(colPurple))
}

func prepareAssets() {
	root := filepath.Join(appDataRoot(), "VOID Optimizer", "Assets")
	if os.MkdirAll(root, 0755) != nil {
		return
	}
	bannerPath := filepath.Join(root, "void-banner.bmp")
	bannerBluePath := filepath.Join(root, "void-banner-blue.bmp")
	iconPath := filepath.Join(root, "void-icon.ico")
	purpleCursorPath := filepath.Join(root, "void-cursor-purple.cur")
	blueCursorPath := filepath.Join(root, "void-cursor-blue.cur")
	_ = os.WriteFile(bannerPath, embeddedBanner, 0600)
	_ = os.WriteFile(bannerBluePath, embeddedBannerBlue, 0600)
	_ = os.WriteFile(iconPath, embeddedIcon, 0600)
	_ = os.WriteFile(purpleCursorPath, embeddedCursorPurple, 0600)
	_ = os.WriteFile(blueCursorPath, embeddedCursorBlue, 0600)
	bp, _ := syscall.UTF16PtrFromString(bannerPath)
	ip, _ := syscall.UTF16PtrFromString(iconPath)
	if h, _, _ := pLoadImage.Call(0, uintptr(unsafe.Pointer(bp)), imageBitmap, 0, 0, lrLoadFromFile); h != 0 {
		app.BannerBitmap = h
	}
	runtime.KeepAlive(bp)
	bblue, _ := syscall.UTF16PtrFromString(bannerBluePath)
	if h, _, _ := pLoadImage.Call(0, uintptr(unsafe.Pointer(bblue)), imageBitmap, 0, 0, lrLoadFromFile); h != 0 {
		app.BannerBitmapBlue = h
	}
	runtime.KeepAlive(bblue)
	if h, _, _ := pLoadImage.Call(0, uintptr(unsafe.Pointer(ip)), imageIcon, 64, 64, lrLoadFromFile); h != 0 {
		app.AppIcon = h
	}
	runtime.KeepAlive(ip)
	createBackgroundBitmap()
	selectThemeCursor()
}

func selectThemeCursor() {
	// Native 16x16 DIB-backed CUR files; the earlier PNG-in-CUR workaround
	// could make the pointer invisible or render an opaque square.
	root := filepath.Join(appDataRoot(), "VOID Optimizer", "Assets")
	if app.CursorPurple == 0 {
		path, _ := syscall.UTF16PtrFromString(filepath.Join(root, "void-cursor-purple.cur"))
		if h, _, _ := pLoadImage.Call(0, uintptr(unsafe.Pointer(path)), imageCursor, 16, 16, lrLoadFromFile); h != 0 {
			app.CursorPurple = h
		}
		runtime.KeepAlive(path)
	}
	if app.CursorBlue == 0 {
		path, _ := syscall.UTF16PtrFromString(filepath.Join(root, "void-cursor-blue.cur"))
		if h, _, _ := pLoadImage.Call(0, uintptr(unsafe.Pointer(path)), imageCursor, 16, 16, lrLoadFromFile); h != 0 {
			app.CursorBlue = h
		}
		runtime.KeepAlive(path)
	}
	app.ActiveCursor = app.CursorPurple
	if app.Theme == "blue" {
		app.ActiveCursor = app.CursorBlue
	}
	if app.ActiveCursor == 0 {
		app.ActiveCursor, _, _ = pLoadCursor.Call(0, 32512)
	}
	if app.HWND != 0 && app.ActiveCursor != 0 {
		pSetCursor.Call(app.ActiveCursor)
	}
}

func drawBanner(hdc uintptr, r rect) {
	bitmap := app.BannerBitmap
	if app.Theme == "blue" && app.BannerBitmapBlue != 0 {
		bitmap = app.BannerBitmapBlue
	}
	if bitmap == 0 {
		return
	}
	dc, _, _ := pCreateCompatibleDC.Call(hdc)
	if dc == 0 {
		return
	}
	old, _, _ := pSelectObject.Call(dc, bitmap)
	w := int(r.Right - r.Left)
	h := int(r.Bottom - r.Top)
	if w > 0 && h > 0 {
		pStretchBlt.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(w), uintptr(h), dc, 0, 0, 720, 198, srccopy)
	}
	pSelectObject.Call(dc, old)
	pDeleteDC.Call(dc)
}

func invalidateRect(r rect) {
	if app.HWND != 0 {
		pInvalidateRect.Call(app.HWND, uintptr(unsafe.Pointer(&r)), 0)
		runtime.KeepAlive(&r)
	}
}

func invalidateFooter() {
	if app.HWND == 0 {
		return
	}
	var client rect
	pGetClientRect.Call(app.HWND, uintptr(unsafe.Pointer(&client)))
	r := rect{260, client.Bottom - 36, client.Right - 20, client.Bottom - 6}
	pInvalidateRect.Call(app.HWND, uintptr(unsafe.Pointer(&r)), 0)
}

func toggleFullscreen() {
	if app.HWND == 0 {
		return
	}
	if !app.Fullscreen {
		var current rect
		pGetWindowRect.Call(app.HWND, uintptr(unsafe.Pointer(&current)))
		app.WindowedRect = current
		// Fill the primary display without stretching across a multi-monitor desktop.
		x, y := uintptr(0), uintptr(0)
		w, _, _ := pGetSystemMetrics.Call(0) // SM_CXSCREEN
		h, _, _ := pGetSystemMetrics.Call(1) // SM_CYSCREEN
		if w == 0 || h == 0 {
			w, h = 1320, 900
		}
		pSetWindowPos.Call(app.HWND, 0, x, y, w, h, swpNoZOrder|swpNoActivate)
		app.Fullscreen = true
	} else {
		r := app.WindowedRect
		w, h := r.Right-r.Left, r.Bottom-r.Top
		if w < 960 || h < 620 {
			x, y, iw, ih := initialWindowBounds()
			r.Left, r.Top = int32(x), int32(y)
			w, h = int32(iw), int32(ih)
		}
		pSetWindowPos.Call(app.HWND, 0, uintptr(r.Left), uintptr(r.Top), uintptr(w), uintptr(h), swpNoZOrder|swpNoActivate)
		app.Fullscreen = false
	}
	positionWindowChrome()
	refreshButtons()
	invalidate()
}

func pageTitle() string {
	if app.Language == "en" {
		switch app.Page {
		case "clean":
			return "CLEANUP"
		case "boost":
			return "PC OPTIMIZATION"
		case "rust":
			return "RUST OPTIMIZATION"
		case "rust_binds":
			return "RUST BINDS"
		case "colors":
			return "MONITOR COLORS"
		case "tweaks":
			return "WINDOWS TWEAKS"
		case "settings":
			return "SETTINGS"
		case "display":
			return "MONITOR RESOLUTION"
		case "rust_plus":
			return "RUST+ CONTROL CENTER"
		case "void_radar":
			return "VOID RADAR · LIVE SERVER EVENTS"
		default:
			return "OVERVIEW"
		}
	}
	switch app.Page {
	case "clean":
		return "ОЧИСТКА"
	case "boost":
		return "ОПТИМИЗАЦИЯ ПК"
	case "rust":
		return "ОПТИМИЗАЦИЯ RUST"
	case "rust_binds":
		return "БИНДЫ RUST"
	case "colors":
		return "ЦВЕТА МОНИТОРА"
	case "tweaks":
		return "ТВИКИ WINDOWS"
	case "settings":
		return "НАСТРОЙКИ"
	case "display":
		return "РАЗРЕШЕНИЕ МОНИТОРА"
	case "rust_plus":
		return "RUST+"
	case "void_radar":
		return "VOID RADAR"
	default:
		return "ГЛАВНАЯ"
	}
}
func pageSubtitle() string {
	if app.Language == "en" {
		switch app.Page {
		case "clean":
			return "Safely remove temporary files from the current user profile. Game and shader caches stay untouched."
		case "boost":
			return "Apply reversible Windows settings and an AC-aware power profile for overall PC responsiveness."
		case "rust":
			return "Hardware-aware client.cfg profiles with backup and restore. Apply only while Rust is closed."
		case "rust_binds":
			return "Utility binds for movement, inventory, chat and everyday actions. No combat automation."
		case "colors":
			return "Windows display gamma controls without AMD or NVIDIA control panels."
		case "tweaks":
			return "Reversible Windows settings with a backup of every original registry value."
		case "display":
			return "Automatically detect the display and choose a supported or custom resolution."
		case "rust_plus":
			return "Official Rust+ pairing in browser, team/map links and a separate Steam player-hours tracker."
		case "void_radar":
			return "Self-hosted Rust server events, teammate online/death alerts and map-grid coordinates."
		case "settings":
			return "Choose the VOID interface language and color theme."
		default:
			return "PC performance, cleanup and hardware overview."
		}
	}
	switch app.Page {
	case "clean":
		return "Безопасная очистка временных файлов пользователя. Кэш шейдеров и игровые папки не трогаем."
	case "boost":
		return "Одна кнопка применяет обратимые настройки Windows и доступное GPU-предпочтение для Rust."
	case "rust":
		return "Профили графики client.cfg с резервной копией и откатом. Применять только при закрытом Rust."
	case "rust_binds":
		return "Удобные назначения для движения, инвентаря, чата и повседневных действий. Без автоматизации стрельбы."
	case "colors":
		return "Универсальная коррекция через Windows, без AMD Adrenalin и NVIDIA Control Panel."
	case "tweaks":
		return "Популярные, обратимые параметры Windows с резервной копией исходных значений."
	case "display":
		return "Автоопределение дисплея, список поддерживаемых режимов и пользовательское разрешение."
	case "rust_plus":
		return "Официальное подключение Rust+ через браузер, карта и команда. Отдельно — часы и статус Steam-профилей."
	case "void_radar":
		return "Собственный монитор событий Rust: Cargo, Oil Rig, Locked Crate, входы, выходы и координаты смертей."
	case "settings":
		return "Выбери язык интерфейса и цветовую тему VOID. Настройки сохраняются автоматически."
	default:
		return "Профиль ПК: Xeon E5-2690 v4 • Radeon RX 6700 XT • 32 GB DDR4 • 1080×1080."
	}
}

func paintOverview(hdc uintptr, c rect) {
	drawBanner(hdc, rect{260, 125, c.Right - 26, 245})
	drawText(hdc, "VOID RUST OPTIMIZER", rect{286, 155, c.Right - 80, 194}, 24, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, "Настройки производительности для твоего ПК", rect{288, 195, c.Right - 80, 220}, 10, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	hardwareText := "Идёт автоматическое обнаружение CPU, GPU, RAM и накопителей..."
	if app.Language == "en" {
		hardwareText = "Automatically detecting CPU, GPU, RAM and storage..."
	}
	if app.HardwareCh == nil && !app.HardwareReady {
		hardwareText = "Windows не вернула данные о комплектующих. Открой «Настройки» и нажми «Повторно определить ПК»."
		if app.Language == "en" {
			hardwareText = "Windows returned no hardware data. Open Settings and select Rescan PC Components."
		}
	}
	if app.HardwareReady {
		parts := []string{}
		if app.Hardware.CPU != "" {
			parts = append(parts, "CPU: "+app.Hardware.CPU)
		}
		if app.Hardware.GPU != "" {
			parts = append(parts, "GPU: "+app.Hardware.GPU)
		}
		ram := "RAM: обнаружена"
		if app.Hardware.RAMGB > 0 {
			ram = fmt.Sprintf("RAM: %.0f GB %s", app.Hardware.RAMGB, app.Hardware.RAMType)
		}
		parts = append(parts, ram)
		if app.Hardware.Disks != "" {
			diskLabel := "Накопители: "
			if app.Language == "en" {
				diskLabel = "Drives: "
			}
			parts = append(parts, diskLabel+app.Hardware.Disks)
		}
		if app.Hardware.OS != "" {
			parts = append(parts, app.Hardware.OS)
		}
		hardwareText = strings.Join(parts, "\n")
	}
	card(hdc, rect{260, 260, c.Right - 26, 410}, "АВТООПРЕДЕЛЕНИЕ КОМПЛЕКТУЮЩИХ", hardwareText)
	card(hdc, rect{260, 425, c.Right - 26, 535}, "ЧТО ДЕЛАЕТ VOID", "Оптимизирует игровые функции Windows, визуальные эффекты, фоновые параметры и питание. Дополнительные настройки ПК — в «Твики». Очистка затрагивает только безопасные временные файлы пользователя.")
	card(hdc, rect{260, 550, c.Right - 26, 670}, "ВАЖНО ПРО FPS", "FPS зависит от температуры CPU/GPU, нагрузки по ядрам\nи фоновых приложений. Фиксированный прирост не обещается.")
	card(hdc, rect{260, 685, c.Right - 26, 790}, "БЕЗОПАСНОСТЬ", "Defender, обновления и системные службы остаются включены.\nНет разгона, BCD и рискованных таймеров.")
}
func paintClean(hdc uintptr, c rect) {
	ageText := "Показывает список перед удалением. Файлы старше 1 часа удаляются только из TEMP текущего пользователя; занятые и защищённые файлы пропускаются."
	if app.Language == "en" {
		ageText = "Preview files before deletion. Files older than 1 hour are removed only from the current user's TEMP folders; locked and protected files are skipped."
	}
	card(hdc, rect{260, 125, c.Right - 26, 225}, "TEMP CLEANER", ageText)
	card(hdc, rect{260, 305, c.Right - 26, 610}, "РЕЗУЛЬТАТ СКАНИРОВАНИЯ", "")
	drawText(hdc, app.Status, rect{282, 355, c.Right - 52, 398}, 10, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	if len(app.Preview) > 0 {
		lines := make([]string, 0, 9)
		limit := len(app.Preview)
		if limit > 8 {
			limit = 8
		}
		for i := 0; i < limit; i++ {
			f := app.Preview[i]
			lines = append(lines, fmt.Sprintf("%s   •   %s", filepath.Base(f.Path), humanBytesForLanguage(f.Size, app.Language)))
		}
		if len(app.Preview) > limit {
			lines = append(lines, fmt.Sprintf("… и ещё %d файлов", len(app.Preview)-limit))
		}
		drawText(hdc, strings.Join(lines, "\n"), rect{282, 410, c.Right - 52, 595}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	}
	card(hdc, rect{260, 630, c.Right - 26, 790}, "ЧТО МЫ НЕ ТРОГАЕМ", "Папки Rust и Steam, кэш шейдеров, драйверные кэши, Prefetch, Windows Update и личные документы. Корзина не очищается автоматически.")
}
func hardwareValue(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "не определено"
	}
	return s
}

func paintBoost(hdc uintptr, c rect) {
	boostIntro := "Комплексная оптимизация Windows: Game Mode, захват и оверлеи, визуальные эффекты, отзывчивость интерфейса, автозагрузка и выбор GPU для Rust. Дополнительные системные твики доступны отдельно; все изменения сохраняют резервную копию и откатываются."
	if app.Language == "en" {
		boostIntro = "A broader Windows optimization profile: Game Mode, capture and overlays, visual effects, interface responsiveness, startup behavior and Rust GPU preference. Optional system tweaks are available separately; registry changes are backed up and reversible."
	}
	card(hdc, rect{260, 125, c.Right - 26, 215}, "VOID SMART BOOST", boostIntro)
	card(hdc, rect{260, 300, 720, 540}, "СОСТОЯНИЕ ПК", "")
	cpu := "CPU: " + app.CPUPercent
	ram := "RAM: " + app.RAMPercent
	featureStates := []struct {
		id     int
		ru, en string
		onRU   string
		onEN   string
	}{
		{idTweakGame, "Game Mode: не проверен", "Game Mode: not checked", "Game Mode: ВКЛ", "Game Mode: ON"},
		{idTweakDVR, "Game DVR: не проверен", "Game DVR: not checked", "Game DVR: ВЫКЛ", "Game DVR: OFF"},
		{idTweakTrans, "Прозрачность: не проверена", "Transparency: not checked", "Прозрачность: ВЫКЛ", "Transparency: OFF"},
		{idTweakFX, "Визуальные эффекты: не проверены", "Visual effects: not checked", "Визуальные эффекты: быстродействие", "Visual effects: performance"},
		{idTweakAnim, "Анимация окон: не проверена", "Window animations: not checked", "Анимация окон: ВЫКЛ", "Window animations: OFF"},
		{idTweakMenu, "Задержка меню: не проверена", "Menu delay: not checked", "Задержка меню: 0 ms", "Menu delay: 0 ms"},
		{idTweakOverlay, "Game Bar: не проверен", "Game Bar: not checked", "Game Bar: ВЫКЛ", "Game Bar: OFF"},
	}
	featureLines := []string{cpu, ram}
	for _, feature := range featureStates {
		label := feature.ru
		if app.Language == "en" {
			label = feature.en
		}
		if tweakEnabled(feature.id) {
			label = feature.onRU
			if app.Language == "en" {
				label = feature.onEN
			}
		}
		featureLines = append(featureLines, label)
	}
	if app.RustFolder != "" {
		gpuLabel := "GPU-предпочтение Rust: Windows по умолчанию"
		if tweakEnabled(idTweakRustGPU) {
			gpuLabel = "GPU-предпочтение Rust: высокая производительность"
		}
		if app.Language == "en" {
			gpuLabel = "Rust GPU preference: Windows default"
			if tweakEnabled(idTweakRustGPU) {
				gpuLabel = "Rust GPU preference: high performance"
			}
		}
		featureLines = append(featureLines, gpuLabel)
	}
	hardware := "CPU / GPU / RAM / диски: ожидается обнаружение"
	if app.Language == "en" {
		hardware = "CPU / GPU / RAM / drives: detecting"
	}
	if app.HardwareReady {
		hardware = strings.Join([]string{
			"CPU: " + hardwareValue(app.Hardware.CPU),
			"GPU: " + hardwareValue(app.Hardware.GPU),
			fmt.Sprintf("RAM: %.0f GB %s", app.Hardware.RAMGB, hardwareValue(app.Hardware.RAMType)),
			"Накопители: " + hardwareValue(app.Hardware.Disks),
			"OS: " + hardwareValue(app.Hardware.OS),
		}, "\n")
	}
	featureLines = append(featureLines, hardware)
	drawText(hdc, strings.Join(featureLines, "\n"), rect{282, 365, 700, 530}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	card(hdc, rect{740, 300, c.Right - 26, 540}, "ЧТО МЕНЯЕТ ПРОФИЛЬ", "")
	steps := "01  Питание от сети → High Performance; от батареи → без смены схемы\n02  Windows Game Mode → включён\n03  Game DVR и фоновый захват → выключены\n04  Game Bar overlay → выключен\n05  GPU-предпочтение Rust → высокая производительность (если найден)\n06  Прозрачность и эффекты Windows → снижены\n07  Анимация и задержка меню → выключены\n\nКаждый изменённый параметр записывается в резервную копию."
	if app.Language == "en" {
		steps = "01  AC power → High Performance; battery → keep current plan\n02  Windows Game Mode → enabled\n03  Game DVR and background capture → disabled\n04  Game Bar overlay → disabled\n05  Rust GPU preference → high performance (if found)\n06  Windows transparency and effects → reduced\n07  Window animations and menu delay → off\n\nEvery changed value is backed up for rollback."
	}
	drawText(hdc, steps, rect{762, 365, c.Right - 52, 515}, 10, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	card(hdc, rect{260, 560, c.Right - 26, 760}, "РЕЗУЛЬТАТ И ОТКАТ", "")
	drawText(hdc, app.Status, rect{282, 615, c.Right - 52, 675}, 11, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	warning := "High Performance может увеличить нагрев и энергопотребление. Фиксированный прирост FPS не обещается: результат зависит от игры, температуры и фоновой нагрузки."
	if app.Language == "en" {
		warning = "High Performance can increase heat and power use. No fixed FPS gain is promised; results depend on the game, temperatures and background load."
	}
	drawText(hdc, warning, rect{282, 690, c.Right - 52, 740}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
}

func paintRust(hdc uintptr, c rect) {
	folder := app.RustFolder
	if folder == "" {
		folder = "Steam/Rust не найдены. Нажми «Обновить поиск» или выбери RustClient.exe."
		if app.Language == "en" {
			folder = "Steam/Rust not found. Rescan or choose RustClient.exe."
		}
	}
	card(hdc, rect{260, 125, c.Right - 26, 225}, "АВТОМАТИЧЕСКОЕ ОБНАРУЖЕНИЕ RUST", "")
	// Keep detection text in the left column so it never runs beneath the
	// two action buttons on narrower window sizes.
	detectTextRight := c.Right - 550
	if detectTextRight < 500 {
		detectTextRight = 500
	}
	drawText(hdc, folder, rect{280, 177, detectTextRight, 205}, 9, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	state := "RUST НЕ ЗАПУЩЕН"
	if app.Language == "en" {
		state = "RUST IS NOT RUNNING"
	}
	stateColor := uint32(colGreen)
	if app.RustRunning {
		state = "RUST ЗАПУЩЕН — РЕЖИМ НАБЛЮДЕНИЯ"
		if app.Language == "en" {
			state = "RUST RUNNING — READ-ONLY MONITORING"
		}
		stateColor = uint32(colOrange)
	}
	drawText(hdc, state, rect{280, 205, detectTextRight, 220}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, stateColor)

	card(hdc, rect{260, 240, c.Right - 26, 490}, "РАСШИРЕННЫЙ CLIENT.CFG — SAFE APPLY", "")
	profileInfo := "VOID формирует аппаратно-адаптивный профиль из 55+ клиентских графических и performance-параметров: дальность, тени, сглаживание, эффекты, трава, вода, ландшафт, частицы, отражения и управляемый GC buffer."
	safeApplyInfo := "Применение работает ТОЛЬКО при закрытом Rust. VOID сохраняет исходный client.cfg в отдельную резервную копию и меняет только графические параметры из белого списка. keys.cfg, бинды и остальные файлы игры не затрагиваются."
	cfgPathInfo := `Путь: Rust\cfg\client.cfg  •  Для отката используй кнопку «ОТКАТИТЬ CFG».`
	if app.Language == "en" {
		profileInfo = "VOID builds a hardware-adaptive profile from 55+ current client graphics/performance settings: draw distance, shadows, anti-aliasing, effects, grass, water, terrain, particles, reflections and managed GC buffer."
		safeApplyInfo = "Apply ONLY while Rust is closed. VOID backs up the original client.cfg and changes only allow-listed graphics settings. keys.cfg, binds and other game files are not touched."
		cfgPathInfo = `Path: Rust\cfg\client.cfg  •  Use RESTORE CFG to revert.`
	}
	drawText(hdc, profileInfo, rect{280, 290, c.Right - 52, 320}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	drawText(hdc, safeApplyInfo, rect{280, 330, c.Right - 52, 390}, 9, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colGreen))
	drawText(hdc, cfgPathInfo, rect{280, 400, c.Right - 52, 425}, 9, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	vsyncLabel := "OFF"
	if app.VSync {
		vsyncLabel = "ON"
	}
	profileSummary := fmt.Sprintf("Выбранный профиль: %s  •  дальность %d  •  FOV %d  •  V-Sync %s", rustProfileName(app.RustProfileID), app.DrawDistance, app.FOV, vsyncLabel)
	if app.RustProfileID == idRustAuto && app.HardwareReady {
		rec := recommendRustHardware(app.Hardware)
		profileSummary += fmt.Sprintf("  •  %s tier  •  %d CPU threads  •  %.0f GB RAM", rec.Tier, app.Hardware.LogicalCPUs, app.Hardware.RAMGB)
	}
	if app.Language == "en" {
		profileSummary = fmt.Sprintf("Selected profile: %s  •  draw distance %d  •  FOV %d  •  V-Sync %s", rustProfileName(app.RustProfileID), app.DrawDistance, app.FOV, vsyncLabel)
	}
	drawText(hdc, profileSummary, rect{280, 450, c.Right - 52, 475}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))

	card(hdc, rect{260, 505, c.Right - 26, 625}, "ПРОФИЛИ ГРАФИКИ RUST", "")
	card(hdc, rect{260, 640, c.Right - 26, 755}, "ПУБЛИЧНЫЕ ИСТОЧНИКИ CFG", "")
	sourcesInfo := "Меняется более 40 проверенных графических параметров client.cfg. Автопрофиль учитывает RAM, число потоков CPU и модель GPU; неизвестные строки исходного файла сохраняются. Прирост FPS не гарантируется — подбор снижает нагрузку там, где это уместно."
	if app.Language == "en" {
		sourcesInfo = "More than 40 checked client.cfg graphics values are updated. Auto profile considers RAM, CPU threads and GPU model; unknown original lines are preserved. No fixed FPS gain is guaranteed."
	}
	drawText(hdc, sourcesInfo, rect{280, 690, c.Right - 52, 740}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
}

func paintRustBinds(hdc uintptr, c rect) {
	title := "БИНДЫ RUST — НАСТРОЙ СВОИ КЛАВИШИ"
	subtitle := "У каждой команды своя кнопка «Изменить». Нажми её, затем клавишу на клавиатуре или Mouse3/4/5. Esc отменяет назначение."
	if app.Language == "en" {
		title = "RUST BINDS — CUSTOMIZE YOUR KEYS"
		subtitle = "Each command has its own Change button. Click it, then press a keyboard key or Mouse3/4/5. Esc cancels."
	}
	card(hdc, rect{260, 125, c.Right - 26, 190}, title, subtitle)
	saved, _, _ := pSaveDC.Call(hdc)
	pIntersectClipRect.Call(hdc, 252, 198, uintptr(c.Right-18), 822)
	for i, spec := range rustUtilityBindSpecs() {
		y := 205 + i*68 - app.BindScroll
		if y+60 < 198 || y > 822 {
			continue
		}
		key := strings.ToUpper(app.BindKeys[spec.ID])
		if key == "" {
			key = strings.ToUpper(spec.DefaultKey)
		}
		name, desc := spec.TitleRU, spec.DescRU
		if app.Language == "en" {
			name, desc = spec.TitleEN, spec.DescEN
		}
		card(hdc, rect{260, int32(y), c.Right - 26, int32(y + 60)}, "", "")
		drawText(hdc, name+"  —  "+key, rect{276, int32(y + 6), c.Right - 232, int32(y + 27)}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
		descColor := uint32(colMuted)
		if app.CapturingBind == spec.ID {
			if app.Language == "en" {
				desc = "Press a key now (or Mouse3 / Mouse4 / Mouse5). Esc cancels."
			} else {
				desc = "Нажми клавишу или Mouse3 / Mouse4 / Mouse5. Esc отменяет."
			}
			descColor = uint32(colOrange)
		}
		drawText(hdc, desc, rect{276, int32(y + 31), c.Right - 232, int32(y + 52)}, 8, false, dtLeft|dtSingleLine|dtNoPrefix, descColor)
	}
	contentEnd := 205 + len(rustUtilityBindSpecs())*68 - app.BindScroll
	note := "Файл: Rust\\cfg\\keys.cfg. Перед изменением создаётся резервная копия. Клавиши не должны повторяться; назначения, которых нет в списке, сохраняются."
	if app.Language == "en" {
		note = "File: Rust\\cfg\\keys.cfg. A backup is created before changes. Keys must be unique; assignments not managed by VOID are preserved."
	}
	drawText(hdc, note, rect{280, int32(contentEnd + 8), c.Right - 52, int32(contentEnd + 34)}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	status := app.Status
	if status == "" {
		status = "Готово. Измени нужные клавиши и прокрути вниз для установки биндов."
	}
	if app.Language == "en" && status == "Готово. Измени нужные клавиши и прокрути вниз для установки биндов." {
		status = "Ready. Customize the keys and scroll down to apply the binds."
	}
	drawText(hdc, status, rect{280, int32(contentEnd + 38), c.Right - 52, int32(contentEnd + 66)}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colGreen))
	pRestoreDC.Call(hdc, saved)
	drawScrollBar(hdc, int(c.Right)-12, 200, 820, app.BindScroll, bindScrollMax())
}

func paintColors(hdc uintptr, c rect) {
	message := "Windows gamma ramp доступен. Изменения временные и сбрасываются при закрытии VOID."
	if !app.GammaAvailable {
		message = "Этот видеодрайвер не поддерживает чтение gamma ramp. Ползунки не будут менять изображение."
		if app.Language == "en" {
			message = "This display driver does not expose a readable gamma ramp. The sliders cannot change the image."
		}
	} else if app.GammaSetFailed {
		message = "Драйвер отказался применить gamma ramp. Ползунки могут не менять изображение; проверь HDR/драйвер."
		if app.Language == "en" {
			message = "The driver refused the gamma-ramp update. Sliders may have no effect; check HDR/driver settings."
		}
	}
	card(hdc, rect{260, 125, c.Right - 26, 755}, "ЦВЕТОВЫЕ ПРОФИЛИ И РУЧНАЯ КОРРЕКЦИЯ", "")
	drawText(hdc, message, rect{280, 180, c.Right - 48, 210}, 9, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	labels := [6]string{"Яркость", "Контрастность", "Гамма", "Красный канал", "Зелёный канал", "Синий канал"}
	if app.Language == "en" {
		labels = [6]string{"Brightness", "Contrast", "Gamma", "Red channel", "Green channel", "Blue channel"}
	}
	drawText(hdc, fmt.Sprintf("%s: %d", labels[0], app.Brightness), rect{280, 225, 480, 250}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 275, 560, app.Brightness, -20, 20)
	drawText(hdc, fmt.Sprintf("%s: %d%%", labels[1], app.Contrast), rect{280, 305, 480, 330}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 355, 560, app.Contrast, 70, 130)
	drawText(hdc, fmt.Sprintf("%s: %d%%", labels[2], app.Gamma), rect{280, 385, 480, 410}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 435, 560, app.Gamma, 70, 130)
	drawText(hdc, fmt.Sprintf("%s: %d%%", labels[3], app.RedGain), rect{280, 465, 480, 490}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 515, 560, app.RedGain, 70, 130)
	drawText(hdc, fmt.Sprintf("%s: %d%%", labels[4], app.GreenGain), rect{280, 545, 480, 570}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 595, 560, app.GreenGain, 70, 130)
	drawText(hdc, fmt.Sprintf("%s: %d%%", labels[5], app.BlueGain), rect{280, 625, 480, 650}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawSlider(hdc, 280, 675, 560, app.BlueGain, 70, 130)
	profileText := "Профили: ПУСТЫНЯ — тёплый песочный; ЛЕС — нейтрально-зелёный; ЗИМА — холодный; НОЧНАЯ ВИДИМОСТЬ — максимальный уровень яркости gamma ramp (+20) с подъёмом теней; ЗАКАТ — тёплый вечерний тон. Это визуальные пресеты, а не аппаратная калибровка.\n\nНочная видимость не меняет физическую подсветку монитора и может утомлять глаза на максимуме — используй её по необходимости."
	driverText := "Использует стандартный Windows gamma ramp для основного дисплея, без AMD/NVIDIA панелей. HDR и отдельные драйверы/мониторы могут ограничивать функцию."
	if app.Language == "en" {
		profileText = "Profiles: DESERT — warm sand tone; FOREST — neutral green; WINTER — cool whites; NIGHT VISIBILITY — maximum gamma-ramp brightness (+20) with lifted shadows; DUSK — warm evening tone. These are visual presets, not hardware calibration.\n\nNight Visibility does not change the monitor backlight and may cause eye strain at maximum; use it only when needed."
		driverText = "Uses the standard Windows gamma ramp for the primary display, without AMD/NVIDIA control panels. HDR and some drivers/monitors may limit this feature."
	}
	drawText(hdc, profileText, rect{880, 235, c.Right - 50, 405}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	drawText(hdc, driverText, rect{880, 410, c.Right - 50, 535}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
}

type tweakCardInfo struct {
	id       int
	category string
	title    string
	desc     string
	risk     string
}

func tweakCardCatalog() []tweakCardInfo {
	if app.Language == "en" {
		return []tweakCardInfo{
			{idTweakGame, "GAMING", "WINDOWS GAME MODE", "Enables Windows Game Mode.", "SAFE"},
			{idTweakDVR, "GAMING", "BACKGROUND CAPTURE", "Turns off background game recording.", "SAFE"},
			{idTweakRustGPU, "GAMING", "RUST HIGH-PERFORMANCE GPU", "Prefers the high-performance GPU for Rust.", "SAFE"},
			{idTweakOverlay, "GAMING", "GAME BAR OVERLAY", "Turns off the Game Bar overlay.", "SAFE"},
			{idTweakTrans, "VISUALS", "WINDOW TRANSPARENCY", "Turns off desktop transparency.", "SAFE"},
			{idTweakFX, "VISUALS", "WINDOWS VISUAL EFFECTS", "Prioritizes responsiveness over visual effects.", "SAFE"},
			{idTweakAnim, "VISUALS", "WINDOW ANIMATIONS", "Turns off minimize and restore animations.", "SAFE"},
			{idTweakTaskbarAnim, "VISUALS", "TASKBAR ANIMATIONS", "Turns off taskbar animations.", "SAFE"},
			{idTweakAeroPeek, "VISUALS", "AERO PEEK", "Turns off desktop preview on taskbar hover.", "SAFE"},
			{idTweakListAlpha, "VISUALS", "LIST VIEW HIGHLIGHT", "Removes translucent Explorer selection.", "SAFE"},
			{idTweakDragFull, "VISUALS", "WINDOW DRAG CONTENT", "Shows an outline while dragging windows.", "SAFE"},
			{idTweakMenu, "DESKTOP", "MENU OPEN DELAY", "Removes the Windows menu delay.", "SAFE"},
			{idTweakMouseAccel, "INPUT", "MOUSE ACCELERATION", "Disables pointer acceleration system-wide.", "CAUTION"},
			{idTweakExplorerThumbs, "EXPLORER", "EXPLORER ICONS ONLY", "Disables file thumbnails in Explorer.", "CAUTION"},
			{idTweakWidgets, "TASKBAR", "TASKBAR WIDGETS", "Hides the Widgets button; no direct FPS gain.", "SAFE"},
			{idTweakTaskView, "TASKBAR", "TASK VIEW BUTTON", "Hides the Task View button.", "SAFE"},
			{idTweakTaskbarSearch, "TASKBAR", "TASKBAR SEARCH BUTTON", "Hides the Search button.", "SAFE"},
			{idTweakStartRecs, "START MENU", "START MENU SUGGESTIONS", "Turns off suggested content and tips.", "SAFE"},
			{idTweakStartupDelay, "STARTUP", "STARTUP APP DELAY", "Removes the user-session startup delay.", "SAFE"},
			{idTweakRecentFiles, "EXPLORER", "RECENT / FREQUENT FILES", "Hides recent and frequent file lists.", "SAFE"},
			{idTweakBackgroundApps, "BACKGROUND", "BACKGROUND APP ACTIVITY", "Blocks supported Store-app background activity where the Windows version honors the global setting; notifications or sync may stop.", "CAUTION"},
			{idTweakSearchHighlights, "SEARCH", "SEARCH HIGHLIGHTS", "Turns off decorative Search highlights.", "SAFE"},
			{idTweakSearchSuggestions, "SEARCH", "FILE EXPLORER SEARCH HISTORY", "Hides recent-query suggestions in File Explorer search.", "SAFE"},
		}
	}
	return []tweakCardInfo{
		{idTweakGame, "ИГРА", "WINDOWS GAME MODE", "Включает игровой режим Windows.", "БЕЗОПАСНО"},
		{idTweakDVR, "ИГРА", "ФОНОВАЯ ЗАПИСЬ", "Отключает фоновую запись игровых клипов.", "БЕЗОПАСНО"},
		{idTweakRustGPU, "ИГРА", "GPU ВЫСОКОЙ ПРОИЗВОДИТЕЛЬНОСТИ · RUST", "Назначает Rust дискретную GPU, если она есть.", "БЕЗОПАСНО"},
		{idTweakOverlay, "ИГРА", "GAME BAR OVERLAY", "Отключает оверлей Game Bar.", "БЕЗОПАСНО"},
		{idTweakTrans, "ВИЗУАЛЬНО", "ПРОЗРАЧНОСТЬ ОКОН", "Отключает прозрачность рабочего стола.", "БЕЗОПАСНО"},
		{idTweakFX, "ВИЗУАЛЬНО", "ЭФФЕКТЫ WINDOWS", "Ставит быстродействие выше визуальных эффектов.", "БЕЗОПАСНО"},
		{idTweakAnim, "ВИЗУАЛЬНО", "АНИМАЦИИ ОКОН", "Отключает анимацию сворачивания окон.", "БЕЗОПАСНО"},
		{idTweakTaskbarAnim, "ВИЗУАЛЬНО", "АНИМАЦИИ ПАНЕЛИ ЗАДАЧ", "Отключает анимации панели задач.", "БЕЗОПАСНО"},
		{idTweakAeroPeek, "ВИЗУАЛЬНО", "AERO PEEK", "Отключает предпросмотр рабочего стола.", "БЕЗОПАСНО"},
		{idTweakListAlpha, "ВИЗУАЛЬНО", "ПОДСВЕТКА СПИСКА", "Убирает полупрозрачное выделение в Проводнике.", "БЕЗОПАСНО"},
		{idTweakDragFull, "ВИЗУАЛЬНО", "СОДЕРЖИМОЕ ПРИ ПЕРЕТАСКИВАНИИ", "Показывает контур вместо перерисовки окна.", "БЕЗОПАСНО"},
		{idTweakMenu, "РАБОЧИЙ СТОЛ", "ЗАДЕРЖКА МЕНЮ", "Убирает задержку открытия меню Windows.", "БЕЗОПАСНО"},
		{idTweakMouseAccel, "ВВОД", "УСКОРЕНИЕ МЫШИ", "Отключает ускорение мыши во всей Windows.", "С ОСТОРОЖНОСТЬЮ"},
		{idTweakExplorerThumbs, "ПРОВОДНИК", "ТОЛЬКО ЗНАЧКИ", "Отключает миниатюры файлов в Проводнике.", "С ОСТОРОЖНОСТЬЮ"},
		{idTweakWidgets, "ПАНЕЛЬ ЗАДАЧ", "ВИДЖЕТЫ", "Скрывает кнопку виджетов; напрямую FPS не повышает.", "БЕЗОПАСНО"},
		{idTweakTaskView, "ПАНЕЛЬ ЗАДАЧ", "КНОПКА ОБЗОРА ЗАДАЧ", "Скрывает кнопку представления задач.", "БЕЗОПАСНО"},
		{idTweakTaskbarSearch, "ПАНЕЛЬ ЗАДАЧ", "ПОИСК НА ПАНЕЛИ ЗАДАЧ", "Скрывает кнопку поиска.", "БЕЗОПАСНО"},
		{idTweakStartRecs, "МЕНЮ ПУСК", "РЕКОМЕНДАЦИИ И ПОДСКАЗКИ", "Отключает рекомендованный контент и советы.", "БЕЗОПАСНО"},
		{idTweakStartupDelay, "ЗАПУСК", "ЗАДЕРЖКА АВТОЗАПУСКА", "Убирает задержку запуска приложений после входа.", "БЕЗОПАСНО"},
		{idTweakRecentFiles, "ПРОВОДНИК", "НЕДАВНИЕ / ЧАСТЫЕ ФАЙЛЫ", "Скрывает списки недавних и частых файлов.", "БЕЗОПАСНО"},
		{idTweakBackgroundApps, "ФОНОВЫЕ ПРИЛОЖЕНИЯ", "ФОНОВАЯ АКТИВНОСТЬ STORE-ПРИЛОЖЕНИЙ", "Ограничивает фоновые задачи поддерживаемых Store-приложений там, где Windows учитывает глобальный флаг; уведомления и синхронизация могут остановиться.", "С ОСТОРОЖНОСТЬЮ"},
		{idTweakSearchHighlights, "ПОИСК", "ПОДСВЕТКА ПОИСКА", "Отключает декоративные подсказки и highlights в поиске.", "БЕЗОПАСНО"},
		{idTweakSearchSuggestions, "ПРОВОДНИК", "ИСТОРИЯ ПОИСКА ПРОВОДНИКА", "Скрывает подсказки из недавних запросов в строке поиска Проводника.", "БЕЗОПАСНО"},
	}
}

func paintTweaks(hdc uintptr, c rect) {
	header := "ТВИКИ WINDOWS — КАТЕГОРИИ И УРОВЕНЬ РИСКА"
	if app.Language == "en" {
		header = "WINDOWS TWEAKS — CATEGORIES AND RISK"
	}
	drawText(hdc, header, rect{260, 112, c.Right - 30, 137}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colGreen))
	saved, _, _ := pSaveDC.Call(hdc)
	pIntersectClipRect.Call(hdc, 252, 140, uintptr(c.Right-18), 822)
	for i, item := range tweakCardCatalog() {
		y := 150 + i*58 - app.TweakScroll
		if y+52 < 140 || y > 822 {
			continue
		}
		w := int(c.Right) - 286
		if w > 1034 {
			w = 1034
		}
		if w < 650 {
			w = 650
		}
		card(hdc, rect{260, int32(y), int32(260 + w), int32(y + 52)}, "", "")
		riskColor := uint32(colGreen)
		if item.risk == "С ОСТОРОЖНОСТЬЮ" || item.risk == "CAUTION" {
			riskColor = uint32(colOrange)
		}
		drawText(hdc, item.title, rect{276, int32(y + 5), int32(260 + w - 195), int32(y + 22)}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
		drawText(hdc, item.category, rect{276, int32(y + 27), 405, int32(y + 43)}, 7, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
		drawText(hdc, item.risk, rect{410, int32(y + 27), 565, int32(y + 43)}, 7, true, dtLeft|dtSingleLine|dtNoPrefix, riskColor)
		drawText(hdc, item.desc, rect{575, int32(y + 26), int32(260 + w - 210), int32(y + 43)}, 7, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	}
	warningY := 150 + len(tweakCardCatalog())*58 + 8 - app.TweakScroll
	warningTitle := "РИСКОВАННЫЕ ТВИКИ ЗАБЛОКИРОВАНЫ"
	warning := "VOID не отключает Defender, Firewall, Windows Update, UAC, VBS/HVCI, системные службы, файл подкачки, Secure Boot, драйверы и сетевой стек."
	if app.Language == "en" {
		warningTitle = "RISKY TWEAKS ARE BLOCKED"
		warning = "VOID will not disable Defender, Firewall, Windows Update, UAC, VBS/HVCI, core services, pagefile, Secure Boot, drivers or the network stack."
	}
	card(hdc, rect{260, int32(warningY), c.Right - 26, int32(warningY + 72)}, warningTitle, "")
	drawText(hdc, warning, rect{280, int32(warningY + 32), c.Right - 50, int32(warningY + 66)}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colOrange))
	status := app.Status
	if status == "" {
		status = "Настройки разбиты на категории. Зелёная метка — безопасно, оранжевая — с осторожностью. Прокрути вниз для отката и DNS-кэша."
	}
	drawText(hdc, status, rect{280, int32(warningY + 76), c.Right - 52, int32(warningY + 116)}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	pRestoreDC.Call(hdc, saved)
	drawScrollBar(hdc, int(c.Right)-12, 140, 822, app.TweakScroll, tweakScrollMax())
}

func paintRustPlus(hdc uintptr, c rect) {
	card(hdc, rect{260, 125, c.Right - 26, 250}, "ОФИЦИАЛЬНЫЙ RUST+ · ПОДКЛЮЧЕНИЕ", "")
	drawText(hdc, "Войди через Steam в официальном Rust+ Web, затем привяжи сервер через меню Rust+ внутри игры.", rect{282, 170, 820, 205}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	drawText(hdc, "Пароль и подтверждение Steam вводятся только на сайте Facepunch. VOID не читает браузерную сессию.", rect{282, 210, 820, 235}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))

	card(hdc, rect{260, 265, 790, 620}, "STEAM PLAYER TRACKER · ЧАСЫ В RUST", "")
	drawText(hdc, "Steam Web API Key нужен только для часов и статуса Steam — это НЕ ключ Rust+.", rect{282, 310, 765, 336}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	drawText(hdc, "API KEY", rect{282, 340, 390, 361}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, "STEAMID64 · до 7 профилей, по одному на строку", rect{282, 406, 765, 428}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	if app.RustMonitorBusy {
		drawText(hdc, "● ЗАПРОС К STEAM…", rect{282, 553, 765, 573}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colOrange))
	} else if app.RustMonitorError != "" {
		drawText(hdc, "ОШИБКА: "+app.RustMonitorError, rect{282, 550, 765, 598}, 7, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colOrange))
	} else if !app.RustMonitorLastUpdate.IsZero() {
		drawText(hdc, "Обновлено: "+app.RustMonitorLastUpdate.Format("02.01.2006 15:04:05"), rect{282, 553, 765, 573}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colGreen))
	} else {
		drawText(hdc, "Добавь SteamID64 и нажми «Сохранить и начать». API Key хранится только в памяти VOID.", rect{282, 550, 765, 598}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	}

	card(hdc, rect{810, 265, c.Right - 26, 620}, "ОТСЛЕЖИВАЕМЫЕ ИГРОКИ · СТАТУС И ЧАСЫ", "")
	if len(app.RustMonitorPlayers) == 0 {
		drawText(hdc, "После первого обновления здесь появятся ник, Rust-статус, общее время и часы за 2 недели.", rect{835, 325, c.Right - 55, 390}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	} else {
		for i, player := range app.RustMonitorPlayers {
			if i >= 5 {
				break
			}
			y := 315 + i*55
			card(hdc, rect{828, int32(y), c.Right - 45, int32(y + 49)}, "", "")
			name := strings.TrimSpace(player.PersonaName)
			if name == "" {
				name = player.SteamID64
			}
			if len([]rune(name)) > 19 {
				name = string([]rune(name)[:18]) + "…"
			}
			drawText(hdc, name, rect{842, int32(y + 4), 1000, int32(y + 23)}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
			drawText(hdc, player.SteamID64, rect{842, int32(y + 25), 1000, int32(y + 42)}, 7, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
			presenceColor := uint32(colMuted)
			if player.GameStatusKnown && player.RustPlaying {
				presenceColor = uint32(colGreen)
			}
			if player.GameStatusKnown && !player.RustPlaying {
				presenceColor = uint32(colOrange)
			}
			presence := rustPresenceLabel(player)
			if len([]rune(presence)) > 22 {
				presence = string([]rune(presence)[:21]) + "…"
			}
			drawText(hdc, presence, rect{1010, int32(y + 4), c.Right - 190, int32(y + 21)}, 7, true, dtLeft|dtSingleLine|dtNoPrefix, presenceColor)
			hours := "Часы скрыты"
			hours2 := "2 нед.: —"
			if player.HoursKnown {
				hours = fmt.Sprintf("Всего: %.1f ч", player.RustHours)
				hours2 = fmt.Sprintf("2 нед.: %.1f ч", player.RustHours2Weeks)
			}
			drawText(hdc, hours, rect{1010, int32(y + 22), c.Right - 48, int32(y + 36)}, 7, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
			drawText(hdc, hours2, rect{1010, int32(y + 36), c.Right - 48, int32(y + 47)}, 6, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
		}
		if len(app.RustMonitorPlayers) > 5 {
			drawText(hdc, fmt.Sprintf("Показано 5 из %d профилей", len(app.RustMonitorPlayers)), rect{835, 590, c.Right - 48, 606}, 7, false, dtRight|dtSingleLine|dtNoPrefix, uint32(colMuted))
		}
	}

	card(hdc, rect{260, 635, c.Right - 26, 820}, "СОБЫТИЯ СЕРВЕРА И МЕТКИ СМЕРТИ", "")
	drawText(hdc, "ОФИЦИАЛЬНЫЙ RUST+", rect{282, 678, 750, 698}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colGreen))
	drawText(hdc, "Rust+ даёт команде статусы, позиции и Team Chat. VOID Radar использует этот канал, чтобы автоматически отправлять уведомления о смертях и доступных событиях.", rect{282, 704, 750, 752}, 8, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	drawText(hdc, "ЧТО НУЖНО ДЛЯ СОБЫТИЙ", rect{780, 678, c.Right - 48, 698}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colOrange))
	drawText(hdc, "Набор доступных маркеров зависит от того, какие события Rust+ отдаёт конкретному серверу. Серверный плагин не требуется.", rect{780, 704, c.Right - 48, 758}, 7, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	if len(app.RustMonitorEvents) > 0 {
		events := app.RustMonitorEvents
		if len(events) > 2 {
			events = events[:2]
		}
		drawText(hdc, "ПОСЛЕДНИЕ ИЗМЕНЕНИЯ: "+strings.Join(events, "  •  "), rect{282, 750, 760, 764}, 6, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
	}
}

func paintVoidRadar(hdc uintptr, c rect) {
	card(hdc, rect{260, 125, c.Right - 26, 405}, "VOID RADAR · ПОДКЛЮЧЕНИЕ ЧЕРЕЗ RUST+", "")
	status := "● НЕ ПОДКЛЮЧЁН · Введи данные Pairing из Rust+"
	statusColor := uint32(colOrange)
	if app.RustRadarConnected {
		status = "● RUST+ ПОДКЛЮЧЁН · СООБЩЕНИЯ ОТПРАВЛЯЮТСЯ В ЧАТ КОМАНДЫ"
		statusColor = uint32(colGreen)
	}
	drawText(hdc, status, rect{282, 165, c.Right - 52, 190}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, statusColor)
	drawText(hdc, "Сначала открой Rust+ → Pair with Server в игре, затем перенеси сюда ip / port / playerId / playerToken.", rect{282, 188, c.Right - 52, 204}, 7, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	drawText(hdc, "АДРЕС СЕРВЕРА", rect{282, 205, 720, 226}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, "RUST+ APP PORT", rect{750, 205, 950, 226}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, "STEAMID64 / PLAYER ID", rect{282, 270, 720, 291}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, "PLAYER TOKEN · СЕКРЕТНЫЙ", rect{750, 270, 1060, 291}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, "Используй именно Rust+ порт из Pairing, не игровой порт подключения. Токен сохраняется локально в папке профиля VOID и не показывается в журнале.", rect{282, 398, c.Right - 52, 423}, 7, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))

	card(hdc, rect{260, 435, c.Right - 26, 820}, "LIVE FEED · СОБЫТИЯ, КОТОРЫЕ VOID ОТПРАВИЛ В TEAM CHAT", "")
	if len(app.RadarEvents) == 0 {
		drawText(hdc, "Пока событий нет. После подключения VOID будет отслеживать смерти тиммейтов, вход/выход из сервера и доступные Rust+ маркеры Cargo, CH-47, Heli и Locked Crate.", rect{282, 495, c.Right - 52, 560}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	} else {
		for i, event := range app.RadarEvents {
			if i >= 8 {
				break
			}
			y := 485 + i*35
			line := event.Timestamp.Local().Format("15:04:05") + "  " + event.Title
			if event.Grid != "" {
				line += " · " + event.Grid
			}
			color := uint32(colText)
			if event.Type == "teammate_death" {
				color = uint32(colOrange)
			}
			if event.Type == "world_event" {
				color = uint32(colGreen)
			}
			if event.Type == "connection_error" || event.Type == "disconnected" {
				color = uint32(colOrange)
			}
			drawText(hdc, line, rect{282, int32(y), c.Right - 52, int32(y + 27)}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, color)
		}
	}
	if death := latestVoidRadarDeath(app.RadarEvents); death != nil {
		fill(hdc, rect{282, 775, 338, 815}, uint32(colCardLine))
		grid := death.Grid
		if grid == "" {
			grid = "?"
		}
		drawText(hdc, grid, rect{282, 777, 338, 813}, 12, true, dtCenter|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colOrange))
		drawText(hdc, "ПОСЛЕДНЯЯ СМЕРТЬ · "+death.Player, rect{352, 782, c.Right - 52, 808}, 8, true, dtLeft|dtVCenter|dtSingleLine|dtNoPrefix, uint32(colOrange))
	} else {
		drawText(hdc, "Смерть тиммейта появится здесь с его ником и квадратом карты.", rect{282, 790, c.Right - 52, 810}, 8, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	}
}

func latestVoidRadarDeath(events []VoidRadarEvent) *VoidRadarEvent {
	for i := range events {
		if events[i].Type == "teammate_death" {
			return &events[i]
		}
	}
	return nil
}

func toUTF16Array(dst []uint16, value string) {
	encoded, _ := syscall.UTF16FromString(value)
	if len(encoded) > len(dst) {
		encoded = encoded[:len(dst)]
	}
	copy(dst, encoded)
}

func showVoidRadarNotification(event VoidRadarEvent) {
	if app.HWND == 0 {
		return
	}
	pMessageBeep.Call(0x00000040)
	pFlashWindow.Call(app.HWND, 1)
	var data notifyIconData
	data.CbSize = uint32(unsafe.Sizeof(data))
	data.HWnd = app.HWND
	data.UID = 1
	data.HIcon = app.AppIcon
	data.InfoFlags = 1 // NIIF_INFO
	toUTF16Array(data.Tip[:], "VOID RADAR")
	toUTF16Array(data.InfoTitle[:], event.Title)
	body := event.Message
	if event.Player != "" {
		body = event.Player + " · " + body
	}
	if event.Grid != "" {
		body += " · " + event.Grid
	}
	toUTF16Array(data.Info[:], body)
	if !app.RadarTrayAdded {
		data.UFlags = 0x00000002 | 0x00000004                    // NIF_ICON | NIF_TIP
		pShellNotifyIcon.Call(0, uintptr(unsafe.Pointer(&data))) // NIM_ADD
		app.RadarTrayAdded = true
	}
	data.UFlags = 0x00000010                                 // NIF_INFO
	pShellNotifyIcon.Call(1, uintptr(unsafe.Pointer(&data))) // NIM_MODIFY
	runtime.KeepAlive(&data)
}

func removeVoidRadarTrayIcon() {
	var data notifyIconData
	data.CbSize = uint32(unsafe.Sizeof(data))
	data.HWnd = app.HWND
	data.UID = 1
	pShellNotifyIcon.Call(2, uintptr(unsafe.Pointer(&data))) // NIM_DELETE
	runtime.KeepAlive(&data)
	app.RadarTrayAdded = false
}

func paintSettings(hdc uintptr, c rect) {
	card(hdc, rect{260, 125, c.Right - 26, 230}, "ЯЗЫК ИНТЕРФЕЙСА", "")
	card(hdc, rect{260, 245, c.Right - 26, 390}, "ЦВЕТОВАЯ ТЕМА", "")
	card(hdc, rect{260, 405, c.Right - 26, 540}, "АККАУНТ И АВТОЗАПУСК", "")
	card(hdc, rect{260, 555, c.Right - 26, 720}, "ОБНОВЛЕНИЯ ВНУТРИ VOID", "")
	card(hdc, rect{260, 735, c.Right - 26, 830}, "ОБНАРУЖЕНИЕ КОМПЛЕКТУЮЩИХ", "")

	currentLang := "Сейчас выбрано: Русский."
	currentTheme := "Текущая тема: VOID Purple — ночной купол и орбитальная сетка."
	startupStatus := "Автозапуск выключен."
	feedHint := "HTTPS-ссылка на update.json. Ссылка сохраняется в настройках этого ПК."
	feedState := "Сервер обновлений не задан. Вставь адрес ниже."
	hwStatus := "Автоопределение при запуске: CPU, GPU, RAM, накопители и версия Windows."

	if app.Language == "en" {
		currentLang = "Selected language: English."
		feedHint = "HTTPS URL of update.json. The address is stored in this PC's settings."
		feedState = "No update server is configured. Paste the address below."
		hwStatus = "Detection on launch: CPU, GPU, RAM, drives and Windows version."
	}
	if app.Theme == "blue" {
		if app.Language == "en" {
			currentTheme = "Current theme: Arctic Blue — snowy Rust-inspired landscape and radar accents."
		} else {
			currentTheme = "Текущая тема: Arctic Blue — снежный игровой пейзаж и радарные акценты."
		}
	} else if app.Language == "en" {
		currentTheme = "Current theme: VOID Purple — night dome and orbital grid."
	}
	if app.Autostart {
		startupStatus = "Автозапуск включён — VOID стартует при входе в Windows."
	}
	if app.Language == "en" && app.Autostart {
		startupStatus = "Autostart enabled — VOID starts when you sign in."
	}
	if strings.TrimSpace(app.UpdateFeedURL) != "" {
		feedState = "Адрес обновлений сохранён в настройках этого ПК."
		if app.Language == "en" {
			feedState = "Update server URL is saved in this PC's settings."
		}
	}
	if app.UpdateStatus != "" {
		feedState = app.UpdateStatus
	}
	if app.UpdateAvailable {
		if app.Language == "en" {
			feedState = "New version available: " + app.UpdateVersion + " — use UPDATE in the top bar."
		} else {
			feedState = "Доступна версия " + app.UpdateVersion + " — нажми ОБНОВИТЬ сверху."
		}
	}
	if app.HardwareReady {
		hwStatus = "Комплектующие обнаружены и показаны на главной странице."
		if app.Language == "en" {
			hwStatus = "PC components detected and shown on the overview page."
		}
	} else if app.HardwareCh == nil {
		hwStatus = "Данные пока не получены. Повторный поиск можно запустить справа."
		if app.Language == "en" {
			hwStatus = "No data yet. Run detection again using the button on the right."
		}
	}

	// Left-side descriptions and right-side controls occupy separate columns.
	drawText(hdc, currentLang, rect{282, 180, c.Right - 530, 208}, 10, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	drawText(hdc, currentTheme, rect{282, 305, c.Right - 530, 350}, 9, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	drawText(hdc, startupStatus, rect{282, 464, c.Right - 430, 515}, 10, true, dtLeft|dtWordBreak|dtNoPrefix, uint32(colText))
	loginLabel := "Текущий логин: " + strings.TrimSpace(app.Login) + " (хранится локально на этом ПК)"
	if app.Language == "en" {
		loginLabel = "Current login: " + strings.TrimSpace(app.Login) + " (stored locally on this PC)"
	}
	drawText(hdc, loginLabel, rect{282, 515, c.Right - 430, 535}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, feedHint, rect{282, 610, c.Right - 250, 634}, 9, false, dtLeft|dtSingleLine|dtNoPrefix, uint32(colMuted))
	drawText(hdc, feedState, rect{282, 635, c.Right - 250, 655}, 8, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
	drawText(hdc, hwStatus, rect{282, 785, c.Right - 430, 818}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
}

func paintLogin(hdc uintptr, c rect) {
	card(hdc, rect{330, 210, c.Right - 80, 610}, "ПЕРВЫЙ ЗАПУСК VOID", "")
	title := "КАК К ТЕБЕ ОБРАЩАТЬСЯ?"
	desc := "Введи только логин. Пароль и регистрация не нужны. Логин хранится локально на этом ПК."
	if app.Language == "en" {
		title = "WHAT SHOULD WE CALL YOU?"
		desc = "Enter a login only. No password or registration required. Your login is stored locally on this PC."
	}
	drawText(hdc, title, rect{370, 290, c.Right - 120, 345}, 20, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	drawText(hdc, desc, rect{372, 350, c.Right - 120, 410}, 11, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	drawText(hdc, "ЛОГИН / LOGIN", rect{470, 455, 850, 485}, 9, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colPurple))
	status := app.Status
	if status == "" || status == "Готов к работе." {
		status = "После сохранения этот вопрос больше не появится."
	}
	if app.Language == "en" {
		if status == "После сохранения этот вопрос больше не появится." {
			status = "This prompt will not appear again after saving."
		}
	}
	drawText(hdc, status, rect{372, 565, c.Right - 120, 595}, 9, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
}

func card(hdc uintptr, r rect, title, body string) {
	pen, _, _ := pCreatePen.Call(0, 1, uintptr(uint32(colCardLine)))
	oldP, _, _ := pSelectObject.Call(hdc, pen)
	if drawCardFill(hdc, r) {
		// The translucent fill is rectangular; a no-fill rounded outline keeps
		// the card shape while allowing the art to remain visible underneath.
		nullBrush, _, _ := pGetStockObject.Call(5) // NULL_BRUSH
		oldB, _, _ := pSelectObject.Call(hdc, nullBrush)
		pRoundRect.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), 14, 14)
		pSelectObject.Call(hdc, oldB)
	} else {
		brush, _, _ := pCreateSolidBrush.Call(uintptr(uint32(colCard)))
		oldB, _, _ := pSelectObject.Call(hdc, brush)
		pRoundRect.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), 14, 14)
		pSelectObject.Call(hdc, oldB)
		pDeleteObject.Call(brush)
	}
	pSelectObject.Call(hdc, oldP)
	pDeleteObject.Call(pen)
	drawText(hdc, tx(title), rect{r.Left + 22, r.Top + 14, r.Right - 18, r.Top + 42}, 11, true, dtLeft|dtSingleLine|dtNoPrefix, uint32(colText))
	if body != "" && r.Bottom-r.Top > 78 {
		bodySize := 10
		if r.Bottom-r.Top < 115 {
			bodySize = 9
		}
		drawText(hdc, body, rect{r.Left + 22, r.Top + 54, r.Right - 18, r.Bottom - 12}, bodySize, false, dtLeft|dtWordBreak|dtNoPrefix, uint32(colMuted))
	}
}

func drawSlider(hdc uintptr, x, y, width, value, min, max int) {
	if max <= min {
		return
	}
	track := rect{int32(x), int32(y), int32(x + width), int32(y + 6)}
	fill(hdc, track, uint32(0x49385A))
	pos := x + int(float64(width)*float64(value-min)/float64(max-min))
	fill(hdc, rect{int32(x), int32(y), int32(pos), int32(y + 6)}, uint32(colPurple))
	brush, _, _ := pCreateSolidBrush.Call(uintptr(uint32(colText)))
	pen, _, _ := pCreatePen.Call(0, 1, uintptr(uint32(colPurple)))
	oldB, _, _ := pSelectObject.Call(hdc, brush)
	oldP, _, _ := pSelectObject.Call(hdc, pen)
	pRoundRect.Call(hdc, uintptr(pos-7), uintptr(y-6), uintptr(pos+7), uintptr(y+13), 7, 7)
	pSelectObject.Call(hdc, oldB)
	pSelectObject.Call(hdc, oldP)
	pDeleteObject.Call(brush)
	pDeleteObject.Call(pen)
}
func drawText(hdc uintptr, text string, r rect, size int, bold bool, flags uint32, color uint32) {
	text = tx(text)
	pSetBkMode.Call(hdc, 1)
	pSetTextColor.Call(hdc, uintptr(color))
	weight := uintptr(400)
	if bold {
		weight = 700
	}
	face, _ := syscall.UTF16PtrFromString("Segoe UI")
	font, _, _ := pCreateFont.Call(uintptr(-size), 0, 0, 0, weight, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(face)))
	old, _, _ := pSelectObject.Call(hdc, font)
	str, _ := syscall.UTF16PtrFromString(text)
	textLen := len(utf16Len(text))
	pDrawText.Call(hdc, uintptr(unsafe.Pointer(str)), uintptr(textLen), uintptr(unsafe.Pointer(&r)), uintptr(flags))
	runtime.KeepAlive(str)
	runtime.KeepAlive(face)
	runtime.KeepAlive(&r)
	pSelectObject.Call(hdc, old)
	pDeleteObject.Call(font)
}
func utf16Len(s string) []uint16 {
	p, _ := syscall.UTF16FromString(s)
	if len(p) > 0 {
		return p[:len(p)-1]
	}
	return p
}
func fill(hdc uintptr, r rect, color uint32) {
	brush, _, _ := pCreateSolidBrush.Call(uintptr(color))
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), brush)
	runtime.KeepAlive(&r)
	pDeleteObject.Call(brush)
}
func invalidate() {
	if app.HWND != 0 {
		pInvalidateRect.Call(app.HWND, 0, 0)
	}
}

func openExternalURL(target string) error {
	if !strings.HasPrefix(target, "https://") {
		return fmt.Errorf("разрешены только HTTPS-ссылки")
	}
	verb, err := syscall.UTF16PtrFromString("open")
	if err != nil {
		return err
	}
	urlPtr, err := syscall.UTF16PtrFromString(target)
	if err != nil {
		return err
	}
	r, _, callErr := pShellExecute.Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(urlPtr)), 0, 0, uintptr(swShow))
	runtime.KeepAlive(verb)
	runtime.KeepAlive(urlPtr)
	if r <= 32 {
		if callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("Windows ShellExecuteW вернул код %d", r)
	}
	return nil
}

func handleCommand(id int) {
	oldPage := app.Page
	switch id {
	case idWindowMinimize:
		pShowWindow.Call(app.HWND, swMinimize)
		return
	case idWindowMaximize:
		toggleFullscreen()
		return
	case idWindowClose:
		pPostMessage.Call(app.HWND, wmAppQuit, 0, 0)
		return
	case idLoginContinue:
		if app.LoginEdit != 0 {
			buf := make([]uint16, 96)
			pGetWindowText.Call(app.LoginEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			login := strings.TrimSpace(syscall.UTF16ToString(buf))
			if login == "" {
				app.Status = "Введи логин, чтобы продолжить."
				if app.Language == "en" {
					app.Status = "Enter a login to continue."
				}
			} else {
				runes := []rune(login)
				if len(runes) > 32 {
					login = string(runes[:32])
				}
				app.Login = login
				if err := savePrefs(); err != nil {
					app.Status = "Не удалось сохранить логин в " + prefsPath() + ": " + err.Error()
					if app.Language == "en" {
						app.Status = "Could not save the login to " + prefsPath() + ": " + err.Error()
					}
				} else {
					app.Page = "overview"
					app.Status = "Привет, " + login + "! Логин сохранён на этом ПК."
					if app.Language == "en" {
						app.Status = "Welcome, " + login + "! Login saved on this PC."
					}
				}
			}
		}
	case idHomeOptimize:
		app.Page = "boost"
		applyBoost()
	case idOverview:
		app.Page = "overview"
	case idClean:
		app.Page = "clean"
	case idBoost:
		app.Page = "boost"
	case idRust:
		app.Page = "rust"
		app.RustRunning = rustRunning()
	case idRustBinds:
		app.Page = "rust_binds"
		app.RustRunning = rustRunning()
	case idSaveCustomBind:
		if app.BindKeyEdit == 0 {
			app.Status = "Поле пользовательской клавиши не создано."
			break
		}
		buf := make([]uint16, 32)
		pGetWindowText.Call(app.BindKeyEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		key := strings.ToLower(strings.TrimSpace(syscall.UTF16ToString(buf)))
		if !validRustCustomKey(key) {
			app.Status = "Недопустимая клавиша. Используй одну клавишу: Q, E, F1–F12, Mouse4, LeftAlt и т.п."
			break
		}
		previous := app.CustomLootKey
		app.CustomLootKey = key
		if err := savePrefs(); err != nil {
			app.CustomLootKey = previous
			app.Status = "Не удалось сохранить пользовательскую клавишу: " + err.Error()
		} else {
			app.Status = "Клавиша быстрого лута сохранена: " + strings.ToUpper(key) + ". Нажми «Установить бинды», чтобы записать её в keys.cfg."
		}
	case idSaveViewmodelBind:
		if app.ViewmodelBindKeyEdit == 0 {
			app.Status = "Поле клавиши масштаба рук не создано."
			break
		}
		buf := make([]uint16, 32)
		pGetWindowText.Call(app.ViewmodelBindKeyEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		key := strings.ToLower(strings.TrimSpace(syscall.UTF16ToString(buf)))
		if !validRustCustomKey(key) {
			app.Status = "Недопустимая клавиша. Используй одну клавишу: F3, V, E, Mouse4, LeftAlt и т.п."
			break
		}
		if key == strings.ToLower(strings.TrimSpace(app.CustomLootKey)) {
			app.Status = "Клавиша масштаба рук должна отличаться от клавиши быстрого лута."
			break
		}
		reserved := map[string]bool{"q": true, "z": true, "n": true, "mouse5": true, "f2": true, "b": true, "h": true, "l": true}
		if reserved[key] {
			app.Status = "Эта клавиша уже используется другим встроенным биндом VOID. Выбери другую."
			break
		}
		previous := app.ViewmodelKey
		app.ViewmodelKey = key
		if err := savePrefs(); err != nil {
			app.ViewmodelKey = previous
			app.Status = "Не удалось сохранить клавишу масштаба рук: " + err.Error()
		} else {
			app.Status = "Клавиша масштаба рук сохранена: " + strings.ToUpper(key) + ". Нажми «Установить бинды», чтобы записать её в keys.cfg."
		}
	case idBindAssignBase, idBindAssignBase + 1, idBindAssignBase + 2, idBindAssignBase + 3, idBindAssignBase + 4, idBindAssignBase + 5, idBindAssignBase + 6, idBindAssignBase + 7, idBindAssignBase + 8, idBindAssignBase + 9:
		idx := id - idBindAssignBase
		if idx >= 0 && idx < len(rustUtilityBindSpecs()) {
			app.CapturingBind = rustUtilityBindSpecs()[idx].ID
			app.Status = "Нажми новую клавишу для «" + rustUtilityBindSpecs()[idx].TitleRU + "». Esc — отмена."
			if app.Language == "en" {
				app.Status = "Press a new key for “" + rustUtilityBindSpecs()[idx].TitleEN + "”. Esc cancels."
			}
			pSetFocus.Call(app.HWND)
		}
	case idApplyBinds:
		applyRustUtilityBinds()
	case idRestoreBinds:
		restoreRustUtilityBinds()
	case idColors:
		app.Page = "colors"
	case idDisplay:
		app.Page = "display"
		refreshDisplayModes()
	case idRustPlus:
		app.Page = "rust_plus"
		if validSteamAPIKey(app.RustSteamAPIKey) && len(app.RustTrackedIDs) > 0 {
			startRustMonitor()
		}
	case idVoidRadar:
		app.Page = "void_radar"
	case idRustAPIHelp:
		if err := openExternalURL("https://steamcommunity.com/dev/apikey"); err != nil {
			app.Status = "Не удалось открыть страницу Steam Web API: " + err.Error()
		} else {
			app.Status = "Открыта официальная страница Steam Web API. Войди в Steam в браузере; пароль и подтверждения вводи только на steamcommunity.com."
		}
	case idRustPlusConnect:
		if err := openExternalURL("https://companion-rust.facepunch.com/login"); err != nil {
			app.Status = "Не удалось открыть официальный вход Rust+: " + err.Error()
		} else {
			app.Status = "Открыт официальный Rust+ в браузере. Войди через Steam и привяжи сервер из меню Rust+. VOID не получает пароль или токен сессии."
		}
	case idRustPlusMap:
		if err := openExternalURL("https://companion-rust.facepunch.com/"); err != nil {
			app.Status = "Не удалось открыть Rust+ Web: " + err.Error()
		} else {
			app.Status = "Открыт Rust+ Web. Карта, команда и устройства работают в официальной вкладке браузера."
		}
	case idRustPlusEventMonitor, idRustPlusOpenRadar:
		app.Page = "void_radar"
		app.Status = "Открыт VOID Radar. Получи Rust+ Pairing через VOID-RUSTPLUS-PAIR.bat, затем вставь данные сервера."
	case idRustPlusChangelog:
		if err := openExternalURL("https://rust.facepunch.com/news/power-trip"); err != nil {
			app.Status = "Не удалось открыть изменения Facepunch: " + err.Error()
		} else {
			app.Status = "Открыты официальные изменения Rust+ от Facepunch."
		}
	case idRustRadarConnect:
		readEdit := func(hwnd uintptr, cap int) string {
			if hwnd == 0 {
				return ""
			}
			buf := make([]uint16, cap)
			pGetWindowText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			return strings.TrimSpace(syscall.UTF16ToString(buf))
		}
		port, _ := strconv.Atoi(readEdit(app.RustRadarPortEdit, 64))
		pairing := RustPlusPairing{Server: readEdit(app.RustRadarServerEdit, 256), Port: port, PlayerID: readEdit(app.RustRadarPlayerIDEdit, 128), PlayerToken: readEdit(app.RustRadarTokenEdit, 128)}
		if err := pairing.Validate(); err != nil {
			app.Status = err.Error()
			break
		}
		if app.RustRadarClient != nil {
			app.RustRadarClient.Stop()
			app.RustRadarClient = nil
		}
		if err := saveRustPlusPairing(pairing); err != nil {
			app.Status = "Не удалось сохранить Rust+ pairing: " + err.Error()
			break
		}
		client, err := StartRustPlusRadar(pairing, app.RadarEventCh)
		if err != nil {
			app.Status = "Не удалось запустить VOID Radar: " + err.Error()
			break
		}
		app.RustRadarPairing = pairing
		app.RustRadarClient = client
		app.RustRadarConnected = false
		app.RadarEvents = nil
		app.Status = "VOID Radar запущен. Подключаюсь к Rust+ и проверяю Team Info…"
	case idRustRadarDisconnect:
		if app.RustRadarClient != nil {
			app.RustRadarClient.Stop()
			app.RustRadarClient = nil
		}
		app.RustRadarConnected = false
		app.Status = "VOID Radar отключён от Rust+."
	case idRustPlusSave, idRustPlusRefresh:
		if app.RustAPIKeyEdit != 0 {
			buf := make([]uint16, 256)
			pGetWindowText.Call(app.RustAPIKeyEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			app.RustSteamAPIKey = strings.TrimSpace(syscall.UTF16ToString(buf))
		}
		if app.RustIDsEdit != 0 {
			buf := make([]uint16, 4096)
			pGetWindowText.Call(app.RustIDsEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
			ids, err := parseSteamIDs(syscall.UTF16ToString(buf))
			if err != nil {
				app.Status = err.Error()
				break
			}
			app.RustTrackedIDs = ids
		}
		if !validSteamAPIKey(app.RustSteamAPIKey) {
			app.RustMonitorError = "Нужен Steam Web API Key из 32 шестнадцатеричных символов."
			app.Status = "Введи корректный Steam Web API Key. Ключ остаётся только в памяти VOID."
			break
		}
		if len(app.RustTrackedIDs) == 0 {
			app.RustMonitorError = "Добавь хотя бы один SteamID64 (17 цифр)."
			app.Status = app.RustMonitorError
			break
		}
		if id == idRustPlusSave {
			if err := savePrefs(); err != nil {
				app.Status = "Не удалось сохранить список игроков: " + err.Error()
				break
			}
		}
		startRustMonitor()
	case idTweaks:
		app.Page = "tweaks"
	case idSettings:
		app.Page = "settings"
	case idScan:
		scanTemp()
	case idCleanNow:
		cleanTemp()
	case idApply:
		applyBoost()
	case idRestore:
		restoreBoost()
	case idDetect:
		app.RustFolder = findRust()
		app.RustRunning = rustRunning()
		if app.RustFolder == "" {
			app.Status = "Steam/Rust не найдены. Выбери RustClient.exe вручную."
		} else {
			app.Status = "Rust найден. CFG можно применять при закрытой игре; исходный файл будет сохранён."
		}
	case idBrowse:
		browseRust()
	case idOpenRust:
		if app.RustFolder != "" {
			if err := exec.Command(systemCommandPath("explorer.exe"), app.RustFolder).Start(); err != nil {
				app.Status = "Не удалось открыть папку Rust: " + err.Error()
			} else {
				app.Status = "Открыта папка Rust. VOID не изменяет её содержимое."
			}
		} else {
			app.Status = "Папка Rust пока не найдена."
		}
	case idLow:
		selectRustPreset(idLow, "Максимальный FPS", 0, 1500, 90, false)
	case idPvp:
		selectRustPreset(idPvp, "PvP", 0, 2000, 90, false)
	case idSurvival:
		selectRustPreset(idSurvival, "Выживание / баланс", 1, 1800, 90, false)
	case idQuality:
		selectRustPreset(idQuality, "Дальность 2000", 1, 2000, 90, false)
	case idRustAuto:
		if selectRustHardwareProfile() {
			applyRustCFG()
		}
	case idApplyRustCFG:
		applyRustCFG()
	case idRestoreRustCFG:
		restoreRustCFG()
	case idColorWarm:
		// Desert: warmer highlights with a restrained blue channel.
		app.Brightness, app.Contrast, app.Gamma = 2, 104, 103
		app.RedGain, app.GreenGain, app.BlueGain = 112, 101, 88
		setGamma()
		app.Status = "Профиль «Пустыня» применён. Это визуальный пресет, не калибровка конкретной панели."
		app.Page = "colors"
	case idColorNeutral:
		// Forest: slightly cooler greens with neutral luminance.
		app.Brightness, app.Contrast, app.Gamma = 0, 102, 100
		app.RedGain, app.GreenGain, app.BlueGain = 96, 108, 98
		setGamma()
		app.Status = "Профиль «Лес» применён. Это визуальный пресет, не калибровка конкретной панели."
		app.Page = "colors"
	case idColorCool:
		// Winter: cool whites and a subtly blue balance.
		app.Brightness, app.Contrast, app.Gamma = 1, 103, 102
		app.RedGain, app.GreenGain, app.BlueGain = 89, 100, 116
		setGamma()
		app.Status = "Профиль «Зима» применён. Это визуальный пресет, не калибровка конкретной панели."
		app.Page = "colors"
	case idColorNightVision:
		// High visibility preset: maximum app gamma-brightness slider and a restrained green lift.
		app.Brightness, app.Contrast, app.Gamma = 20, 108, 125
		app.RedGain, app.GreenGain, app.BlueGain = 88, 118, 90
		setGamma()
		app.Status = "Ночная видимость применена: яркость gamma ramp на максимуме (+20). Это не меняет подсветку монитора; при дискомфорте снизь яркость."
		app.Page = "colors"
	case idColorDusk:
		app.Brightness, app.Contrast, app.Gamma = 5, 104, 108
		app.RedGain, app.GreenGain, app.BlueGain = 115, 103, 90
		setGamma()
		app.Status = "Профиль «Закат» применён. Это художественный тёплый пресет."
		app.Page = "colors"
	case idColorReset:
		app.Brightness, app.Contrast, app.Gamma = 0, 100, 100
		app.RedGain, app.GreenGain, app.BlueGain = 100, 100, 100
		resetGamma()
		app.Status = "Исходная gamma ramp восстановлена."
		app.Page = "colors"
	case idTweakGame, idTweakDVR, idTweakTrans, idTweakFX, idTweakAnim, idTweakMenu, idTweakOverlay, idTweakRustGPU, idTweakMouseAccel,
		idTweakTaskbarAnim, idTweakAeroPeek, idTweakListAlpha, idTweakDragFull, idTweakExplorerThumbs,
		idTweakWidgets, idTweakTaskView, idTweakTaskbarSearch, idTweakStartRecs, idTweakStartupDelay, idTweakRecentFiles, idTweakBackgroundApps, idTweakSearchHighlights, idTweakSearchSuggestions:
		toggleTweak(id)
	case idTweakRestore:
		restoreAllTweaks()
	case idMonitorRefresh:
		refreshDisplayModes()
		app.Status = "Список режимов монитора обновлён автоматически."
	case idMonitorPrev:
		if len(app.MonitorModes) > 0 {
			app.MonitorIndex = (app.MonitorIndex - 1 + len(app.MonitorModes)) % len(app.MonitorModes)
		}
	case idMonitorNext:
		if len(app.MonitorModes) > 0 {
			app.MonitorIndex = (app.MonitorIndex + 1) % len(app.MonitorModes)
		}
	case idMonitorApply:
		if len(app.MonitorModes) > 0 && app.MonitorIndex >= 0 && app.MonitorIndex < len(app.MonitorModes) {
			applyDisplayMode(app.MonitorModes[app.MonitorIndex])
		}
	case idMonitorCustom:
		applyCustomDisplayMode()
	case idMonitorRestore:
		if app.HasPreviousDisplayMode {
			applyDisplayMode(app.PreviousDisplayMode)
			app.HasPreviousDisplayMode = false
		} else {
			app.Status = "Предыдущего режима пока нет."
		}
	case idDNSFlush:
		out, err := runHidden("ipconfig.exe", "/flushdns")
		if err != nil {
			app.Status = "Не удалось очистить DNS-кэш: " + strings.TrimSpace(out)
		} else {
			app.Status = "DNS-кэш очищен. Это не повышает FPS и не гарантирует меньший ping."
		}
	case idLangRU, idLangEN:
		if id == idLangRU {
			app.Language = "ru"
		} else {
			app.Language = "en"
		}
		if err := savePrefs(); err != nil {
			app.Status = "Язык изменён до закрытия приложения, но не сохранён: " + err.Error()
		} else if app.Language == "ru" {
			app.Status = "Язык интерфейса: русский."
		} else {
			app.Status = "Interface language: English."
		}
		app.Page = "settings"
	case idThemePurple, idThemeBlue:
		if id == idThemePurple {
			app.Theme = "purple"
		} else {
			app.Theme = "blue"
		}
		applyTheme()
		if err := savePrefs(); err != nil {
			app.Status = "Тема изменена до закрытия приложения, но не сохранена: " + err.Error()
		} else if app.Language == "ru" {
			app.Status = "Цветовая тема изменена."
		} else {
			app.Status = "Color theme changed."
		}
		app.Page = "settings"
	case idSaveUpdateURL:
		if app.UpdateURLEdit == 0 {
			app.Status = "Поле адреса обновлений не создано."
			break
		}
		buf := make([]uint16, 2048)
		pGetWindowText.Call(app.UpdateURLEdit, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		newURL := strings.TrimSpace(syscall.UTF16ToString(buf))
		validated, err := validateUpdateFeedURL(newURL)
		if err != nil {
			app.Status = "Нужен корректный HTTPS URL update.json: " + err.Error()
		} else {
			previous := app.UpdateFeedURL
			app.UpdateFeedURL = validated
			if err := savePrefs(); err != nil {
				app.UpdateFeedURL = previous
				app.Status = "Не удалось сохранить адрес обновлений: " + err.Error()
			} else if app.Language == "en" {
				app.Status = "Update server URL saved. Use Check for Updates in the top bar."
			} else {
				app.Status = "Адрес сервера обновлений сохранён. Нажми «Проверить обновления» сверху."
			}
		}
		invalidate()
	case idUpdate:
		startUpdateInstall()
	case idCheckUpdates:
		startUpdateCheck()
		if app.Language == "en" {
			app.UpdateStatus = "Checking for updates in the background..."
		} else {
			app.UpdateStatus = "Проверяем обновления в фоновом режиме..."
		}
	case idAutostart:
		if app.Autostart {
			if err := setAutostart(false); err != nil {
				app.Status = "Не удалось отключить автозапуск: " + err.Error()
			} else {
				app.Autostart = false
				app.Status = "Автозапуск VOID отключён."
			}
		} else {
			if err := setAutostart(true); err != nil {
				app.Status = "Не удалось включить автозапуск: " + err.Error()
			} else {
				app.Autostart = true
				app.Status = "VOID будет запускаться при входе в Windows."
			}
		}
	case idRescanHardware:
		app.HardwareReady = false
		app.HardwareCh = make(chan hardwareInfo, 1)
		ch := app.HardwareCh
		go func() { ch <- detectHardware() }()
		app.Status = "Повторно определяем комплектующие ПК..."
		app.Page = "overview"
	}
	rebuild := app.Page != oldPage
	if rebuild && oldPage == "rust_binds" {
		app.CapturingBind = ""
	}
	refresh := false
	switch id {
	case idTweakGame, idTweakDVR, idTweakTrans, idTweakFX, idTweakAnim, idTweakMenu, idTweakOverlay, idTweakRustGPU, idTweakMouseAccel,
		idTweakRestore, idLangRU, idLangEN, idThemePurple, idThemeBlue, idAutostart, idCheckUpdates, idSaveUpdateURL:
		refresh = true
	}
	if id >= idBindAssignBase && id < idBindAssignBase+len(rustUtilityBindSpecs()) {
		rebuild = true
	}
	if rebuild {
		showButtons()
	} else if refresh {
		refreshButtons()
	} else {
		refreshButtons()
	}
}

func selectedRustCFGEntries() []rustCFGEntry {
	return buildRustCFGEntriesWithDisplay(app.Quality, app.DrawDistance, app.FOV, app.VSync)
}

func rustCFGPaths() (cfg, backup, absent string, err error) {
	if app.RustFolder == "" {
		app.RustFolder = findRust()
	}
	if app.RustFolder == "" {
		return "", "", "", fmt.Errorf("папка Rust не найдена — выбери RustClient.exe")
	}
	if _, e := os.Stat(filepath.Join(app.RustFolder, "RustClient.exe")); e != nil {
		return "", "", "", fmt.Errorf("в выбранной папке не найден RustClient.exe")
	}
	dir := filepath.Join(app.RustFolder, "cfg")
	if e := os.MkdirAll(dir, 0755); e != nil {
		return "", "", "", fmt.Errorf("не удалось открыть папку cfg: %w", e)
	}
	cfg = filepath.Join(dir, "client.cfg")
	backup = cfg + ".void-backup"
	absent = cfg + ".void-no-original"
	return cfg, backup, absent, nil
}

func atomicWriteFile(path string, data []byte) error {
	tmp := path + ".void-tmp"
	if err := os.WriteFile(tmp, data, 0644); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func applyRustCFG() {
	// Refuse to touch the config if Rust is open; the game may overwrite client.cfg on exit.
	if rustRunning() {
		app.Status = "Закрой Rust полностью перед применением CFG. Файл не изменён."
		if app.Language == "en" {
			app.Status = "Close Rust completely before applying CFG. No file was changed."
		}
		return
	}
	if app.RustProfileID == 0 {
		app.RustProfileID = idPvp
		app.FOV = 90
		app.DrawDistance = 1500
	}
	cfg, backup, absent, err := rustCFGPaths()
	if err != nil {
		app.Status = err.Error()
		return
	}
	original, readErr := os.ReadFile(cfg)
	if readErr != nil && !os.IsNotExist(readErr) {
		app.Status = "Не удалось прочитать client.cfg: " + readErr.Error()
		return
	}
	// Preserve the first pre-VOID version until the user explicitly restores it.
	_, backupErr := os.Stat(backup)
	_, absentErr := os.Stat(absent)
	if backupErr != nil && !os.IsNotExist(backupErr) {
		app.Status = "Не удалось проверить резервную копию: " + backupErr.Error()
		return
	}
	if absentErr != nil && !os.IsNotExist(absentErr) {
		app.Status = "Не удалось проверить маркер исходного CFG: " + absentErr.Error()
		return
	}
	if os.IsNotExist(backupErr) && os.IsNotExist(absentErr) {
		if readErr == nil {
			if err := os.WriteFile(backup, original, 0644); err != nil {
				app.Status = "Не удалось создать резервную копию: " + err.Error()
				return
			}
		} else {
			if err := os.WriteFile(absent, []byte("client.cfg did not exist before VOID applied a profile\r\n"), 0644); err != nil {
				app.Status = "Не удалось записать маркер отката: " + err.Error()
				return
			}
		}
	}
	if readErr != nil {
		original = nil
	}
	updated := mergeRustCFG(string(original), selectedRustCFGEntries())
	if err := atomicWriteFile(cfg, []byte(updated)); err != nil {
		app.Status = "Не удалось записать client.cfg: " + err.Error()
		return
	}
	app.RustBackupReady = true
	if app.Language == "en" {
		app.Status = "Applied " + rustProfileName(app.RustProfileID) + " to client.cfg. Original file backed up. Start Rust to load it."
	} else {
		app.Status = "CFG применён: " + rustProfileName(app.RustProfileID) + ". Исходный файл сохранён. Запусти Rust, чтобы загрузить настройки."
	}
	app.Page = "rust"
}

func restoreRustCFG() {
	if rustRunning() {
		app.Status = "Закрой Rust полностью перед откатом CFG. Файл не изменён."
		if app.Language == "en" {
			app.Status = "Close Rust completely before restoring CFG. No file was changed."
		}
		return
	}
	cfg, backup, absent, err := rustCFGPaths()
	if err != nil {
		app.Status = err.Error()
		return
	}
	backupData, backupErr := os.ReadFile(backup)
	if backupErr == nil {
		if err := atomicWriteFile(cfg, backupData); err != nil {
			app.Status = "Не удалось восстановить резервную копию: " + err.Error()
			return
		}
		if err := os.Remove(backup); err != nil {
			app.Status = "Файл восстановлен, но копию не удалось удалить: " + err.Error()
			return
		}
		_ = os.Remove(absent)
	} else if os.IsNotExist(backupErr) {
		if _, markerErr := os.Stat(absent); markerErr == nil {
			if err := os.Remove(cfg); err != nil && !os.IsNotExist(err) {
				app.Status = "Не удалось удалить созданный VOID client.cfg: " + err.Error()
				return
			}
			if err := os.Remove(absent); err != nil {
				app.Status = "Файл удалён, но маркер отката не удалён: " + err.Error()
				return
			}
		} else {
			app.Status = "Резервная копия VOID не найдена — откатывать нечего."
			if app.Language == "en" {
				app.Status = "VOID backup not found — nothing to restore."
			}
			return
		}
	} else {
		app.Status = "Не удалось прочитать резервную копию: " + backupErr.Error()
		return
	}
	app.RustBackupReady = false
	if app.Language == "en" {
		app.Status = "Original client.cfg restored."
	} else {
		app.Status = "Исходный client.cfg восстановлен из резервной копии."
	}
	app.Page = "rust"
}

func rustKeysPaths() (keys, backup, absent string, err error) {
	if app.RustFolder == "" {
		app.RustFolder = findRust()
	}
	if app.RustFolder == "" {
		return "", "", "", fmt.Errorf("папка Rust не найдена — сначала выбери RustClient.exe")
	}
	if _, e := os.Stat(filepath.Join(app.RustFolder, "RustClient.exe")); e != nil {
		return "", "", "", fmt.Errorf("в выбранной папке не найден RustClient.exe")
	}
	// Rust installs commonly keep keys.cfg under cfg\, while the Facepunch
	// wiki also documents the install-root location. Prefer an existing cfg file,
	// then an existing root file; create the cfg location only when neither exists.
	cfgDir := filepath.Join(app.RustFolder, "cfg")
	cfgKeys := filepath.Join(cfgDir, "keys.cfg")
	rootKeys := filepath.Join(app.RustFolder, "keys.cfg")
	if _, e := os.Stat(cfgKeys); e == nil {
		keys = cfgKeys
	} else if !os.IsNotExist(e) {
		return "", "", "", e
	} else if _, e := os.Stat(rootKeys); e == nil {
		keys = rootKeys
	} else if !os.IsNotExist(e) {
		return "", "", "", e
	} else {
		if e := os.MkdirAll(cfgDir, 0755); e != nil {
			return "", "", "", e
		}
		keys = cfgKeys
	}
	return keys, keys + ".void-backup", keys + ".void-no-original", nil
}

func applyRustUtilityBinds() {
	if rustRunning() {
		app.Status = "Закрой Rust полностью перед установкой биндов. keys.cfg не изменён."
		return
	}
	keys, backup, absent, err := rustKeysPaths()
	if err != nil {
		app.Status = err.Error()
		return
	}
	original, readErr := os.ReadFile(keys)
	if readErr != nil && !os.IsNotExist(readErr) {
		app.Status = "Не удалось прочитать keys.cfg: " + readErr.Error()
		return
	}
	_, backupErr := os.Stat(backup)
	_, absentErr := os.Stat(absent)
	if backupErr != nil && !os.IsNotExist(backupErr) {
		app.Status = "Не удалось проверить резервную копию keys.cfg: " + backupErr.Error()
		return
	}
	if absentErr != nil && !os.IsNotExist(absentErr) {
		app.Status = "Не удалось проверить маркер keys.cfg: " + absentErr.Error()
		return
	}
	if os.IsNotExist(backupErr) && os.IsNotExist(absentErr) {
		if readErr == nil {
			if err := os.WriteFile(backup, original, 0600); err != nil {
				app.Status = "Не удалось создать резервную копию keys.cfg: " + err.Error()
				return
			}
		} else if err := os.WriteFile(absent, []byte("keys.cfg did not exist before VOID applied utility binds\r\n"), 0600); err != nil {
			app.Status = "Не удалось создать маркер отката: " + err.Error()
			return
		}
	}
	if readErr != nil {
		original = nil
	}
	keysMap := normalizedRustBindKeys(app.BindKeys)
	if err := validateRustBindKeys(keysMap); err != nil {
		app.Status = "Не удалось установить бинды: " + err.Error()
		return
	}
	managedDefaults := map[string]bool{}
	for _, spec := range rustUtilityBindSpecs() {
		managedDefaults[spec.DefaultKey] = true
	}
	assigned := map[string]bool{}
	for _, key := range keysMap {
		assigned[key] = true
	}
	for _, line := range strings.Split(string(original), "\n") {
		key := rustBindKey(line)
		if key == "" || managedDefaults[key] || (key == "mouse4" && (strings.Contains(strings.ToLower(line), "hoverloot") || strings.Contains(strings.ToLower(line), "oldloot"))) {
			continue
		}
		if assigned[key] {
			app.Status = "Клавиша " + strings.ToUpper(key) + " уже занята в keys.cfg. Выбери другую — существующий бинд сохранён."
			return
		}
	}
	if err := atomicWriteFile(keys, []byte(mergeRustUtilityBindsWithMap(string(original), keysMap))); err != nil {
		app.Status = "Не удалось записать keys.cfg: " + err.Error()
		return
	}
	app.BindKeys = keysMap
	app.CustomLootKey = keysMap["loot"]
	app.ViewmodelKey = keysMap["viewmodel"]
	if err := savePrefs(); err != nil {
		app.Status = "Бинды записаны, но настройки клавиш не удалось сохранить: " + err.Error()
		return
	}
	app.RustBindsBackupReady = true
	app.Page = "rust_binds"
	app.Status = fmt.Sprintf("Установлено %d настраиваемых QoL-биндов. Исходный keys.cfg сохранён; перезапусти Rust.", len(rustUtilityBindSpecs()))
	if app.Language == "en" {
		app.Status = fmt.Sprintf("%d customizable QoL binds applied. Original keys.cfg backed up; restart Rust.", len(rustUtilityBindSpecs()))
	}
}

func restoreRustUtilityBinds() {
	if rustRunning() {
		app.Status = "Закрой Rust полностью перед откатом биндов. keys.cfg не изменён."
		return
	}
	keys, backup, absent, err := rustKeysPaths()
	if err != nil {
		app.Status = err.Error()
		return
	}
	data, backupErr := os.ReadFile(backup)
	if backupErr == nil {
		if err := atomicWriteFile(keys, data); err != nil {
			app.Status = "Не удалось восстановить keys.cfg: " + err.Error()
			return
		}
		if err := os.Remove(backup); err != nil {
			app.Status = "Файл восстановлен, но резервная копия не удалена: " + err.Error()
			return
		}
		_ = os.Remove(absent)
	} else if os.IsNotExist(backupErr) {
		if _, markerErr := os.Stat(absent); markerErr == nil {
			if err := os.Remove(keys); err != nil && !os.IsNotExist(err) {
				app.Status = "Не удалось удалить созданный VOID keys.cfg: " + err.Error()
				return
			}
			if err := os.Remove(absent); err != nil {
				app.Status = "Файл удалён, но маркер не удалён: " + err.Error()
				return
			}
		} else {
			app.Status = "Резервная копия keys.cfg не найдена — откатывать нечего."
			return
		}
	} else {
		app.Status = "Не удалось прочитать резервную копию keys.cfg: " + backupErr.Error()
		return
	}
	app.RustBindsBackupReady = false
	app.Page = "rust_binds"
	app.Status = "Исходный keys.cfg восстановлен."
	if app.Language == "en" {
		app.Status = "Original keys.cfg restored."
	}
}

func selectRustHardwareProfile() bool {
	if !app.HardwareReady {
		app.Status = "Сначала дождись определения CPU, GPU и RAM или запусти повторное обнаружение на главной."
		if app.Language == "en" {
			app.Status = "Wait for CPU, GPU and RAM detection, or rescan hardware on Home first."
		}
		app.Page = "rust"
		return false
	}
	rec := recommendRustHardware(app.Hardware)
	app.RustProfileID = idRustAuto
	app.Quality = rec.Quality
	app.DrawDistance = rec.DrawDistance
	app.FOV = 90
	app.VSync = false
	if app.Language == "en" {
		app.Status = "Hardware profile " + rec.Tier + " selected: " + rec.Reason + " VOID will write client.cfg only while Rust is closed."
	} else {
		app.Status = "Автопрофиль " + rec.Tier + " подобран по железу: " + rec.Reason + " Сейчас VOID попробует сохранить профиль в client.cfg (только если Rust закрыт)."
	}
	app.Page = "rust"
	return true
}

func selectRustPreset(id int, name string, q, dist, fov int, vsync bool) {
	app.RustProfileID = id
	app.Quality, app.DrawDistance, app.FOV, app.VSync = q, dist, fov, vsync
	if app.Language == "en" {
		app.Status = "Selected " + name + " community-based profile. Press APPLY CFG to write it while Rust is closed."
	} else {
		app.Status = "Выбран профиль «" + name + "». Нажми «ПРИМЕНИТЬ CFG» при закрытом Rust, чтобы записать его с резервной копией."
	}
	app.Page = "rust"
}

func rustProfileName(id int) string {
	if id == idRustAuto {
		if app.Language == "en" {
			return "SMART HARDWARE PROFILE"
		}
		return "АВТОПРОФИЛЬ ПОД ЖЕЛЕЗО"
	}
	switch id {
	case idLow:
		if app.Language == "en" {
			return "MAX FPS"
		}
		return "МАКС. FPS"
	case idPvp:
		return "PVP"
	case idSurvival:
		if app.Language == "en" {
			return "BALANCED"
		}
		return "БАЛАНС"
	case idQuality:
		if app.Language == "en" {
			return "DRAW DISTANCE 2000"
		}
		return "ДАЛЬНОСТЬ 2000"
	default:
		if app.Language == "en" {
			return "PVP BASELINE"
		}
		return "БАЗОВЫЙ PVP"
	}
}

func handleMouse(x, y int, down bool) {
	if app.Page == "colors" {
		const left, right = 280, 840
		switch {
		case y >= 264 && y <= 288 && x >= left && x <= right:
			app.Dragging = "brightness"
			app.Brightness = mapSlider(x, left, right, -20, 20)
		case y >= 344 && y <= 368 && x >= left && x <= right:
			app.Dragging = "contrast"
			app.Contrast = mapSlider(x, left, right, 70, 130)
		case y >= 424 && y <= 448 && x >= left && x <= right:
			app.Dragging = "gamma"
			app.Gamma = mapSlider(x, left, right, 70, 130)
		case y >= 504 && y <= 528 && x >= left && x <= right:
			app.Dragging = "red"
			app.RedGain = mapSlider(x, left, right, 70, 130)
		case y >= 584 && y <= 608 && x >= left && x <= right:
			app.Dragging = "green"
			app.GreenGain = mapSlider(x, left, right, 70, 130)
		case y >= 664 && y <= 688 && x >= left && x <= right:
			app.Dragging = "blue"
			app.BlueGain = mapSlider(x, left, right, 70, 130)
		}
	}
	if app.Dragging != "" {
		const left, right = 280, 840
		switch app.Dragging {
		case "brightness":
			app.Brightness = mapSlider(x, left, right, -20, 20)
		case "contrast":
			app.Contrast = mapSlider(x, left, right, 70, 130)
		case "gamma":
			app.Gamma = mapSlider(x, left, right, 70, 130)
		case "red":
			app.RedGain = mapSlider(x, left, right, 70, 130)
		case "green":
			app.GreenGain = mapSlider(x, left, right, 70, 130)
		case "blue":
			app.BlueGain = mapSlider(x, left, right, 70, 130)
		}
		setGamma()
		invalidate()
	}
}

func mapSlider(x, x1, x2, min, max int) int {
	if x < x1 {
		x = x1
	}
	if x > x2 {
		x = x2
	}
	return min + int(math.Round(float64(x-x1)/float64(x2-x1)*float64(max-min)))
}
func vsyncText() string {
	if app.VSync {
		return "V-SYNC: ON"
	}
	return "V-SYNC: OFF"
}

func scanTemp() {
	language := app.Language
	if app.Busy {
		app.Status = "Подожди завершения текущей операции."
		if language == "en" {
			app.Status = "Please wait for the current operation to finish."
		}
		invalidate()
		return
	}
	app.Busy = true
	app.Scanned = false
	app.Preview = nil
	app.Status = "Сканирование временных папок выполняется в фоне..."
	if language == "en" {
		app.Status = "Scanning temporary folders in the background..."
	}
	ch := make(chan scanResult, 1)
	app.ScanCh = ch
	go func() {
		files := scanTempWorker()
		var bytes int64
		for _, f := range files {
			bytes += f.Size
		}
		status := fmt.Sprintf("Найдено файлов: %d • доступно к удалению около %s. Фильтр: старше 1 часа.", len(files), humanBytesForLanguage(bytes, language))
		if language == "en" {
			status = fmt.Sprintf("Found %d files • about %s can be freed. Filter: files older than 1 hour.", len(files), humanBytesForLanguage(bytes, language))
		}
		ch <- scanResult{Files: files, Status: status}
	}()
	invalidate()
}

// isReparsePoint fails closed: if Windows cannot inspect a path, cleanup skips it.
// This prevents traversal into junctions/mount points inside a Temp directory.
func isReparsePoint(path string) bool {
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return true
	}
	attrs, _, _ := pGetFileAttributes.Call(uintptr(unsafe.Pointer(p)))
	runtime.KeepAlive(p)
	if uint32(attrs) == 0xFFFFFFFF { // INVALID_FILE_ATTRIBUTES
		return true
	}
	const fileAttributeReparsePoint = 0x0400
	return uint32(attrs)&fileAttributeReparsePoint != 0
}

func scanTempWorker() []cleanupFile {
	files := []cleanupFile{}
	seen := map[string]bool{}
	roots := tempRoots()
	cutoff := time.Now().Add(-time.Hour)
	for _, root := range roots {
		rootInfo, err := os.Lstat(root)
		if err != nil || !rootInfo.IsDir() || rootInfo.Mode()&os.ModeSymlink != 0 || isReparsePoint(root) {
			continue
		}
		_ = filepath.WalkDir(root, func(path string, d os.DirEntry, walkErr error) error {
			if walkErr != nil {
				return nil
			}
			if d.IsDir() {
				if path != root && (d.Type()&os.ModeSymlink != 0 || isReparsePoint(path)) {
					return filepath.SkipDir
				}
				return nil
			}
			if d.Type()&os.ModeSymlink != 0 || isReparsePoint(path) || seen[strings.ToLower(path)] || !withinTempRoots(path, roots) {
				return nil
			}
			info, e := d.Info()
			if e == nil && info.Mode().IsRegular() && info.ModTime().Before(cutoff) {
				seen[strings.ToLower(path)] = true
				files = append(files, cleanupFile{path, info.Size()})
			}
			return nil
		})
	}
	return files
}

func tempRoots() []string {
	roots := []string{os.TempDir(), os.Getenv("TEMP"), os.Getenv("TMP")}
	if local := os.Getenv("LOCALAPPDATA"); local != "" {
		roots = append(roots, filepath.Join(local, "Temp"))
	}
	unique := make([]string, 0, len(roots))
	seen := map[string]bool{}
	for _, root := range roots {
		if root == "" {
			continue
		}
		abs, err := filepath.Abs(root)
		if err != nil {
			continue
		}
		abs = filepath.Clean(abs)
		key := strings.ToLower(abs)
		if !seen[key] {
			seen[key] = true
			unique = append(unique, abs)
		}
	}
	return unique
}

func withinTempRoots(path string, roots []string) bool {
	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	abs = filepath.Clean(abs)
	for _, root := range roots {
		r := strings.TrimRight(filepath.Clean(root), `\/`)
		if strings.EqualFold(abs, r) {
			return false
		}
		if strings.HasPrefix(strings.ToLower(abs), strings.ToLower(r+string(os.PathSeparator))) {
			return true
		}
	}
	return false
}

func safeTempFilePath(path string, roots []string) bool {
	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	abs = filepath.Clean(abs)
	for _, root := range roots {
		rootAbs, err := filepath.Abs(root)
		if err != nil {
			continue
		}
		rootAbs = filepath.Clean(rootAbs)
		rel, err := filepath.Rel(rootAbs, abs)
		if err != nil || rel == "." || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) || filepath.IsAbs(rel) {
			continue
		}
		current := rootAbs
		if isReparsePoint(current) {
			return false
		}
		parts := strings.Split(rel, string(os.PathSeparator))
		for i, part := range parts {
			if part == "" || part == "." || part == ".." {
				return false
			}
			current = filepath.Join(current, part)
			if isReparsePoint(current) {
				return false
			}
			if i < len(parts)-1 {
				info, statErr := os.Lstat(current)
				if statErr != nil || !info.IsDir() || info.Mode()&os.ModeSymlink != 0 {
					return false
				}
			}
		}
		return true
	}
	return false
}

func cleanTemp() {
	language := app.Language
	if app.Busy {
		app.Status = "Подожди завершения текущей операции."
		if language == "en" {
			app.Status = "Please wait for the current operation to finish."
		}
		invalidate()
		return
	}
	if !app.Scanned {
		app.Status = "Сначала нажми «Сканировать», чтобы увидеть список временных файлов."
		if language == "en" {
			app.Status = "Scan first to review the list of temporary files."
		}
		invalidate()
		return
	}
	if len(app.Preview) == 0 {
		app.Status = "Сканирование завершено: старых временных файлов для удаления не найдено."
		if language == "en" {
			app.Status = "Scan complete: no old temporary files were found."
		}
		invalidate()
		return
	}
	files := append([]cleanupFile(nil), app.Preview...)
	ch := make(chan cleanResult, 1)
	app.CleanCh = ch
	app.Busy = true
	app.Status = "Удаление найденных временных файлов выполняется в фоне..."
	if language == "en" {
		app.Status = "Deleting selected temporary files in the background..."
	}
	go func() {
		var bytes int64
		count, skipped, failed := 0, 0, 0
		cutoff := time.Now().Add(-time.Hour)
		roots := tempRoots()
		for _, f := range files {
			if !safeTempFilePath(f.Path, roots) {
				skipped++
				continue
			}
			info, err := os.Lstat(f.Path)
			if err != nil || !info.Mode().IsRegular() || info.Mode()&os.ModeSymlink != 0 || !info.ModTime().Before(cutoff) {
				skipped++
				continue
			}
			if err := os.Remove(f.Path); err == nil {
				count++
				bytes += info.Size()
			} else {
				failed++
			}
		}
		status := fmt.Sprintf("Готово: удалено %d файлов • освобождено %s • пропущено %d • ошибок доступа %d.", count, humanBytesForLanguage(bytes, language), skipped, failed)
		if language == "en" {
			status = fmt.Sprintf("Done: deleted %d files • freed %s • skipped %d • access errors %d.", count, humanBytesForLanguage(bytes, language), skipped, failed)
		}
		ch <- cleanResult{Count: count, Bytes: bytes, Skipped: skipped, Failed: failed, Status: status}
	}()
	invalidate()
}

func humanBytes(v int64) string {
	return humanBytesForLanguage(v, "ru")
}

func humanBytesForLanguage(v int64, language string) string {
	units := []string{"Б", "КБ", "МБ", "ГБ"}
	if language == "en" {
		units = []string{"B", "KB", "MB", "GB"}
	}
	x := float64(v)
	i := 0
	for x >= 1024 && i < len(units)-1 {
		x /= 1024
		i++
	}
	return fmt.Sprintf("%.1f %s", x, units[i])
}

func writeFileAtomic(path string, data []byte, perm os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".void-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)
	if err = tmp.Chmod(perm); err != nil {
		tmp.Close()
		return err
	}
	if _, err = tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err = tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err = tmp.Close(); err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		src, e1 := syscall.UTF16PtrFromString(tmpName)
		dst, e2 := syscall.UTF16PtrFromString(path)
		if e1 != nil {
			return e1
		}
		if e2 != nil {
			return e2
		}
		r, _, callErr := pMoveFileEx.Call(uintptr(unsafe.Pointer(src)), uintptr(unsafe.Pointer(dst)), 0x1|0x8) // REPLACE_EXISTING | WRITE_THROUGH
		runtime.KeepAlive(src)
		runtime.KeepAlive(dst)
		if r == 0 {
			if callErr != syscall.Errno(0) {
				return callErr
			}
			return fmt.Errorf("MoveFileExW failed replacing %s", path)
		}
		return nil
	}
	return os.Rename(tmpName, path)
}

func quickOptimizationTweaks() []int {
	return []int{idTweakGame, idTweakDVR, idTweakTrans, idTweakFX, idTweakAnim, idTweakMenu, idTweakOverlay, idTweakRustGPU, idTweakTaskbarAnim, idTweakAeroPeek, idTweakListAlpha, idTweakDragFull}
}

func containsTweakID(ids []int, target int) bool {
	for _, id := range ids {
		if id == target {
			return true
		}
	}
	return false
}

func validQuickOptimizationTweaks(ids []int) bool {
	allowed := map[int]bool{}
	for _, id := range quickOptimizationTweaks() {
		allowed[id] = true
	}
	seen := map[int]bool{}
	for _, id := range ids {
		if !allowed[id] || seen[id] {
			return false
		}
		seen[id] = true
	}
	return true
}

func saveOptimizerState(path string, state optimizerState) error {
	data, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	return writeFileAtomic(path, data, 0600)
}

func runningOnACPower() (onAC, known bool) {
	var status systemPowerStatus
	result, _, _ := pGetSystemPowerStatus.Call(uintptr(unsafe.Pointer(&status)))
	runtime.KeepAlive(&status)
	if result == 0 || status.ACLineStatus == 255 {
		return false, false
	}
	return status.ACLineStatus == 1, true
}

func applyBoost() {
	if app.TweaksBackupError != "" {
		app.Status = app.TweaksBackupError + " Сначала исправь файл backup; схема питания не изменена."
		if app.Language == "en" {
			app.Status = app.TweaksBackupError + " Fix the backup file first; the power plan was not changed."
		}
		return
	}

	statePath := restoreStatePath()
	st := optimizerState{BoostTweaks: []int{}}
	data, statErr := os.ReadFile(statePath)
	if statErr == nil {
		if json.Unmarshal(data, &st) != nil || st.PreviousPowerPlan == "" || !regexp.MustCompile(`(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`).MatchString(st.PreviousPowerPlan) {
			app.Status = "Файл резервной копии схемы питания повреждён. Ничего не изменено; проверь backup вручную."
			return
		}
		// Older releases did not store the exact list. Preserve their previous
		// rollback behaviour for Game Mode and Game DVR only.
		if st.BoostTweaks == nil {
			st.BoostTweaks = []int{}
			for _, id := range []int{idTweakGame, idTweakDVR} {
				for _, change := range changesForTweak(id) {
					if _, ok := app.TweaksBackup[changeKey(change)]; ok {
						st.BoostTweaks = append(st.BoostTweaks, id)
						break
					}
				}
			}
		}
		if !validQuickOptimizationTweaks(st.BoostTweaks) {
			app.Status = "Список твиков в backup повреждён. Ничего не изменено."
			return
		}
	} else if !os.IsNotExist(statErr) {
		app.Status = "Не удалось прочитать backup схемы питания: " + statErr.Error()
		return
	} else {
		out, err := runHidden("powercfg.exe", "/getactivescheme")
		if err != nil {
			app.Status = "Не удалось прочитать текущую схему питания: " + strings.TrimSpace(out)
			return
		}
		re := regexp.MustCompile(`(?i)([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})`)
		if m := re.FindStringSubmatch(out); len(m) > 1 {
			st.PreviousPowerPlan = m[1]
		}
		if st.PreviousPowerPlan == "" {
			app.Status = "Не удалось определить текущую схему питания — ничего не изменено."
			return
		}
	}

	// Save a valid recovery record before touching power settings or registry values.
	if err := saveOptimizerState(statePath, st); err != nil {
		app.Status = "Не удалось сохранить backup — параметры не изменены: " + err.Error()
		return
	}
	// Avoid forcing a high-power plan while a laptop is running from battery.
	// If a previous VOID run had already switched plans, put the saved user plan
	// back before continuing; the rollback journal remains intact.
	onAC, powerStatusKnown := runningOnACPower()
	powerPlanNote := "схема питания не изменялась (состояние питания неизвестно)"
	if powerStatusKnown && onAC {
		powerOut, powerErr := runHidden("powercfg.exe", "/setactive", "SCHEME_MIN")
		if powerErr != nil {
			app.Status = "Схему High Performance включить не удалось: " + strings.TrimSpace(powerOut)
			return
		}
		powerPlanNote = "High Performance включена от сети"
	} else {
		if _, powerErr := runHidden("powercfg.exe", "/setactive", st.PreviousPowerPlan); powerErr != nil {
			app.Status = "Не удалось сохранить исходную схему питания: " + powerErr.Error()
			return
		}
		if powerStatusKnown {
			powerPlanNote = "работа от батареи — исходная схема питания сохранена"
		}
	}

	applied := 0
	skipped := 0
	for _, tweakID := range quickOptimizationTweaks() {
		changes := changesForTweak(tweakID)
		if len(changes) == 0 {
			skipped++
			continue
		} // Rust GPU preference is optional when no install is found.
		if tweakEnabled(tweakID) {
			continue
		} // Never claim or journal a value that was already set before VOID.
		if !containsTweakID(st.BoostTweaks, tweakID) {
			st.BoostTweaks = append(st.BoostTweaks, tweakID)
			if err := saveOptimizerState(statePath, st); err != nil {
				app.Status = "Не удалось обновить журнал отката: " + err.Error()
				if app.Language == "en" {
					app.Status = "Could not update the rollback journal: " + err.Error()
				}
				return
			}
		}
		if err := applyTweak(tweakID); err != nil {
			app.Status = "Оптимизация остановлена на одном из твиков: " + err.Error() + ". Остальные изменения не скрыты; используй откат при необходимости."
			if app.Language == "en" {
				app.Status = "Optimization stopped on a tweak: " + err.Error() + ". Any completed changes remain backed up for rollback."
			}
			return
		}
		applied++
	}
	msg := fmt.Sprintf("Готово: %s; применено %d твиков. Rust GPU-настройка пропущена, если игра не найдена. Перезапусти Rust для применения GPU-предпочтения. Для возврата нажми «Откатить настройки». Необязательных шагов пропущено: %d.", powerPlanNote, applied, skipped)
	if app.Language == "en" {
		msg = fmt.Sprintf("Done: %s; %d tweaks applied. Rust GPU preference is skipped if the game is not found. Restart Rust for the GPU preference to take effect. Press Restore Settings to roll back. Optional steps skipped: %d.", powerPlanNote, applied, skipped)
	}
	app.Status = msg
}

func restoreBoost() {
	statePath := restoreStatePath()
	data, err := os.ReadFile(statePath)
	if os.IsNotExist(err) {
		app.Status = "Backup схемы питания не найден — VOID ещё не менял её."
		if app.Language == "en" {
			app.Status = "Power-plan backup not found; VOID has not changed it."
		}
		return
	}
	if err != nil {
		app.Status = "Не удалось прочитать backup схемы питания: " + err.Error()
		return
	}
	var st optimizerState
	guidPattern := regexp.MustCompile(`(?i)^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)
	if json.Unmarshal(data, &st) != nil || !guidPattern.MatchString(st.PreviousPowerPlan) {
		app.Status = "Не удалось прочитать backup схемы питания: GUID схемы повреждён."
		return
	}

	// Legacy backup compatibility: releases before 1.7.0 tracked Game Mode and DVR
	// implicitly. New backup files always include the explicit list.
	if st.BoostTweaks == nil {
		st.BoostTweaks = []int{}
		for _, id := range []int{idTweakGame, idTweakDVR} {
			for _, change := range changesForTweak(id) {
				if _, ok := app.TweaksBackup[changeKey(change)]; ok {
					st.BoostTweaks = append(st.BoostTweaks, id)
					break
				}
			}
		}
	}
	if !validQuickOptimizationTweaks(st.BoostTweaks) {
		app.Status = "Список твиков в backup повреждён. Откат заблокирован."
		return
	}
	if _, err := runHidden("powercfg.exe", "/setactive", st.PreviousPowerPlan); err != nil {
		app.Status = "Не удалось восстановить прежнюю схему питания."
		return
	}

	failedTweaks := 0
	for _, tweakID := range st.BoostTweaks {
		changes := changesForTweak(tweakID)
		if len(changes) == 0 {
			failedTweaks++
			continue
		}
		snapshots := make([]regSnapshot, len(changes))
		completeBackup := true
		hasAnyBackup := false
		for i, change := range changes {
			snapshot, ok := app.TweaksBackup[changeKey(change)]
			if !ok {
				completeBackup = false
				continue
			}
			hasAnyBackup = true
			snapshots[i] = snapshot
		}
		if !hasAnyBackup && !tweakEnabled(tweakID) {
			continue // An earlier restore attempt already completed this tweak.
		}
		if !completeBackup || !hasAnyBackup {
			failedTweaks++
			continue
		}
		restoreFailed := false
		for i, change := range changes {
			if err := restoreReg(change.Key, change.Name, snapshots[i]); err != nil {
				restoreFailed = true
				break
			}
		}
		if restoreFailed {
			failedTweaks++
			continue
		}
		next := cloneTweaksBackup(app.TweaksBackup)
		for _, change := range changes {
			delete(next, changeKey(change))
		}
		if err := saveTweaksBackupMap(next); err != nil {
			failedTweaks++
			continue
		}
		app.TweaksBackup = next
	}
	if failedTweaks > 0 {
		app.Status = fmt.Sprintf("Схема питания восстановлена, но %d твик(ов) не удалось вернуть. Backup сохранён для повтора.", failedTweaks)
		if app.Language == "en" {
			app.Status = fmt.Sprintf("Power plan restored, but %d tweak(s) could not be restored. Backups remain for retry.", failedTweaks)
		}
		return
	}
	if err := os.Remove(statePath); err != nil && !os.IsNotExist(err) {
		app.Status = "Параметры восстановлены, но файл состояния не удалось удалить: " + err.Error()
		return
	}
	app.Status = "Прежняя схема питания и параметры быстрой оптимизации восстановлены."
	if app.Language == "en" {
		app.Status = "Previous power plan and quick-optimization settings have been restored."
	}
}

func appDataRoot() string {
	if root := os.Getenv("LOCALAPPDATA"); root != "" {
		return root
	}
	if root, err := os.UserConfigDir(); err == nil && root != "" {
		return root
	}
	return os.TempDir()
}
func restoreStatePath() string {
	return filepath.Join(appDataRoot(), "VOID Optimizer", "restore-state.json")
}
func queryDword(name string) (bool, int) {
	out, err := runHidden("reg.exe", "query", `HKCU\Software\Microsoft\GameBar`, "/v", name)
	if err != nil {
		return false, 0
	}
	re := regexp.MustCompile(`(?i)REG_DWORD\s+0x([0-9a-f]+)`)
	m := re.FindStringSubmatch(out)
	if len(m) < 2 {
		return false, 0
	}
	v, _ := strconv.ParseInt(m[1], 16, 32)
	return true, int(v)
}

func findRust() string {
	roots := map[string]bool{}
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles(x86)"), "Steam"), filepath.Join(os.Getenv("ProgramFiles"), "Steam")} {
		if p != "" {
			roots[p] = true
		}
	}
	for _, item := range []struct {
		key   string
		value string
	}{{`HKCU\Software\Valve\Steam`, "SteamPath"}, {`HKLM\SOFTWARE\WOW6432Node\Valve\Steam`, "InstallPath"}, {`HKLM\SOFTWARE\Valve\Steam`, "InstallPath"}} {
		out, err := runHidden("reg.exe", "query", item.key, "/v", item.value)
		if err == nil {
			lines := strings.Split(out, "\n")
			for _, line := range lines {
				if strings.Contains(line, item.value) {
					f := strings.Fields(line)
					if len(f) >= 3 {
						roots[strings.TrimSpace(strings.Join(f[2:], " "))] = true
					}
				}
			}
		}
	}
	all := map[string]bool{}
	for r := range roots {
		all[r] = true
		b, e := os.ReadFile(filepath.Join(r, "steamapps", "libraryfolders.vdf"))
		if e == nil {
			re := regexp.MustCompile(`"path"\s+"([^"]+)"`)
			for _, m := range re.FindAllStringSubmatch(string(b), -1) {
				if len(m) > 1 {
					all[strings.ReplaceAll(m[1], `\\`, `\`)] = true
				}
			}
		}
	}
	for r := range all {
		candidate := filepath.Join(r, "steamapps", "common", "Rust")
		if _, e := os.Stat(filepath.Join(candidate, "RustClient.exe")); e == nil {
			return candidate
		}
	}
	return ""
}
func rustRunning() bool {
	h, _, _ := pCreateToolhelpSnap.Call(th32csSnap, 0)
	if h == uintptr(^uintptr(0)) {
		return true // fail closed: show read-only/running state if process enumeration fails
	}
	defer pCloseHandle.Call(h)
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	r, _, _ := pProcess32First.Call(h, uintptr(unsafe.Pointer(&pe)))
	if r == 0 {
		return true
	}
	for r != 0 {
		name := strings.ToLower(syscall.UTF16ToString(pe.ExeFile[:]))
		if name == "rustclient.exe" || name == "rust.exe" {
			return true
		}
		r, _, _ = pProcess32Next.Call(h, uintptr(unsafe.Pointer(&pe)))
	}
	return false
}
func browseRust() {
	buf := make([]uint16, 32768)
	filterWords := utf16.Encode([]rune("Rust client executable\x00RustClient.exe\x00\x00"))
	filter := &filterWords[0]
	title, _ := syscall.UTF16PtrFromString("Выбери RustClient.exe")
	of := openFileName{Size: uint32(unsafe.Sizeof(openFileName{})), Owner: app.HWND, Filter: filter, FilterIndex: 1, File: &buf[0], MaxFile: uint32(len(buf)), Title: title, Flags: ofFileMust | ofPathMust | ofNoChangeDir}
	r, _, _ := pGetOpenFileName.Call(uintptr(unsafe.Pointer(&of)))
	runtime.KeepAlive(&of)
	runtime.KeepAlive(title)
	runtime.KeepAlive(filterWords)
	runtime.KeepAlive(buf)
	if r != 0 {
		selected := syscall.UTF16ToString(buf)
		if strings.EqualFold(filepath.Base(selected), "RustClient.exe") {
			app.RustFolder = filepath.Dir(selected)
			app.Status = "Rust выбран: " + app.RustFolder
		} else {
			app.Status = "Выбери именно RustClient.exe."
		}
	}
}

func captureGamma() {
	dc, _, _ := pGetDC.Call(0)
	if dc == 0 {
		return
	}
	defer pReleaseDC.Call(0, dc)
	r, _, _ := pGetDeviceGammaRamp.Call(dc, uintptr(unsafe.Pointer(&app.GammaOriginal[0])))
	runtime.KeepAlive(&app.GammaOriginal)
	app.GammaAvailable = r != 0
}
func setGamma() {
	if !app.GammaAvailable {
		return
	}
	var ramp [768]uint16
	contrast := float64(app.Contrast) / 100.0
	gamma := float64(app.Gamma) / 100.0
	brightness := float64(app.Brightness) / 100.0
	gains := []float64{float64(app.RedGain) / 100.0, float64(app.GreenGain) / 100.0, float64(app.BlueGain) / 100.0}
	for ch := 0; ch < 3; ch++ {
		for i := 0; i < 256; i++ {
			x := float64(app.GammaOriginal[ch*256+i]) / 65535.0
			x = (x-0.5)*contrast + 0.5 + brightness*0.35
			if x < 0 {
				x = 0
			}
			if x > 1 {
				x = 1
			}
			x = math.Pow(x, 1.0/gamma)
			x *= gains[ch]
			if x < 0 {
				x = 0
			}
			if x > 1 {
				x = 1
			}
			v := int(math.Round(x * 65535))
			if v < 0 {
				v = 0
			}
			if v > 65535 {
				v = 65535
			}
			ramp[ch*256+i] = uint16(v)
		}
	}
	dc, _, _ := pGetDC.Call(0)
	if dc == 0 {
		return
	}
	r, _, _ := pSetDeviceGammaRamp.Call(dc, uintptr(unsafe.Pointer(&ramp[0])))
	app.GammaSetFailed = r == 0
	runtime.KeepAlive(&ramp)
	pReleaseDC.Call(0, dc)
}

func resetGamma() {
	if !app.GammaAvailable {
		return
	}
	dc, _, _ := pGetDC.Call(0)
	if dc == 0 {
		return
	}
	r, _, _ := pSetDeviceGammaRamp.Call(dc, uintptr(unsafe.Pointer(&app.GammaOriginal[0])))
	app.GammaSetFailed = r == 0
	runtime.KeepAlive(&app.GammaOriginal)
	pReleaseDC.Call(0, dc)
}
func restoreGamma() { resetGamma() }

func autostartButtonLabel() string {
	if app.Language == "en" {
		if app.Autostart {
			return "DISABLE AUTOSTART"
		}
		return "ENABLE AUTOSTART"
	}
	if app.Autostart {
		return "ОТКЛЮЧИТЬ АВТОЗАПУСК"
	}
	return "ВКЛЮЧИТЬ АВТОЗАПУСК"
}
func rescanButtonLabel() string {
	if app.Language == "en" {
		return "RESCAN PC COMPONENTS"
	}
	return "ПОВТОРНО ОПРЕДЕЛИТЬ ПК"
}

func autostartEnabled() bool {
	out, err := runHidden("reg.exe", "query", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "VOIDOptimizer")
	return err == nil && strings.Contains(strings.ToLower(out), "voidoptimizer")
}

func setAutostart(enable bool) error {
	const key = `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`
	if enable {
		exe, err := os.Executable()
		if err != nil {
			return err
		}
		exe, err = filepath.Abs(exe)
		if err != nil {
			return err
		}
		_, err = runHidden("reg.exe", "add", key, "/v", "VOIDOptimizer", "/t", "REG_SZ", "/d", `"`+exe+`"`, "/f")
		return err
	}
	_, err := runHidden("reg.exe", "delete", key, "/v", "VOIDOptimizer", "/f")
	if err != nil && !autostartEnabled() {
		return nil
	}
	return err
}

func detectHardware() hardwareInfo {
	ps := `$ErrorActionPreference='SilentlyContinue'; [Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $cpus=@(Get-CimInstance Win32_Processor); $cpu=($cpus | Select-Object -First 1 -ExpandProperty Name); $threads=0; foreach($p in $cpus){$threads += [int]$p.NumberOfLogicalProcessors}; $gpus=@(Get-CimInstance Win32_VideoController | Where-Object {$_.Name}); $gpu=(($gpus | Select-Object -ExpandProperty Name) -join ' / '); $vram=0.0; foreach($g in $gpus){if($g.AdapterRAM -and ([double]$g.AdapterRAM/1GB) -gt $vram){$vram=[double]$g.AdapterRAM/1GB}}; $mods=@(Get-CimInstance Win32_PhysicalMemory); $bytes=0.0; foreach($m in $mods){$bytes += [double]$m.Capacity}; $types=@($mods | ForEach-Object {switch ([int]$_.SMBIOSMemoryType) {24 {'DDR3'} 26 {'DDR4'} 34 {'DDR5'} default {'RAM'}}} | Select-Object -Unique); $disk=((Get-CimInstance Win32_DiskDrive | Select-Object -ExpandProperty Model) -join ' / '); $os=(Get-CimInstance Win32_OperatingSystem).Caption; [pscustomobject]@{CPU=$cpu;GPU=$gpu;RAMGB=[math]::Round($bytes/1GB,0);RAMType=($types -join '/');Disks=$disk;OS=$os;LogicalCPUs=$threads;GPUMemoryGB=[math]::Round($vram,1)} | ConvertTo-Json -Compress`
	out, err := runHidden("powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps)
	if err != nil {
		return hardwareInfo{}
	}
	var info hardwareInfo
	if json.Unmarshal([]byte(strings.TrimSpace(out)), &info) != nil {
		return hardwareInfo{}
	}
	return info
}

func readUpdateFeedURL() (string, error) {
	return effectiveUpdateFeedURL(app.UpdateFeedURL, publisherUpdateFeedURL)
}

func httpsOnlyRedirect(req *http.Request, via []*http.Request) error {
	if req.URL == nil || req.URL.Scheme != "https" || req.URL.Host == "" || req.URL.User != nil {
		return fmt.Errorf("update redirects must remain on HTTPS")
	}
	if len(via) >= 5 {
		return fmt.Errorf("too many update redirects")
	}
	return nil
}

func fetchUpdateManifest(feed string) (updateManifest, error) {
	client := &http.Client{Timeout: 12 * time.Second, CheckRedirect: httpsOnlyRedirect}
	req, err := http.NewRequest(http.MethodGet, feed, nil)
	if err != nil {
		return updateManifest{}, err
	}
	req.Header.Set("User-Agent", "VOID-Optimizer/"+appVersion)
	resp, err := client.Do(req)
	if err != nil {
		return updateManifest{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return updateManifest{}, fmt.Errorf("update server returned HTTP %d", resp.StatusCode)
	}
	if resp.ContentLength > 64*1024 {
		return updateManifest{}, fmt.Errorf("update manifest is too large")
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 64*1024+1))
	if len(body) > 64*1024 {
		return updateManifest{}, fmt.Errorf("update manifest is too large")
	}
	if err != nil {
		return updateManifest{}, err
	}
	var manifest updateManifest
	if err := json.Unmarshal(body, &manifest); err != nil {
		return updateManifest{}, fmt.Errorf("invalid update manifest: %w", err)
	}
	if _, ok := versionParts(manifest.Version); !ok {
		return updateManifest{}, fmt.Errorf("manifest version must use x.y.z format")
	}
	download, err := url.Parse(manifest.DownloadURL)
	if err != nil || download.Scheme != "https" || download.Host == "" || download.User != nil {
		return updateManifest{}, fmt.Errorf("download URL must be HTTPS")
	}
	if len(manifest.SHA256) != 64 {
		return updateManifest{}, fmt.Errorf("manifest SHA-256 must contain 64 hexadecimal characters")
	}
	if _, err := hex.DecodeString(manifest.SHA256); err != nil {
		return updateManifest{}, fmt.Errorf("manifest SHA-256 is invalid")
	}
	if len(manifest.Notes) > 2000 {
		manifest.Notes = manifest.Notes[:2000]
	}
	return manifest, nil
}

func startUpdateCheck() {
	if app.UpdateCh != nil {
		return
	}
	app.NextUpdateCheck = time.Now().Add(24 * time.Hour)
	language := app.Language
	app.UpdateStatus = "Автообновление: проверка версии..."
	if app.Language == "en" {
		app.UpdateStatus = "Auto-update: checking version..."
	}
	ch := make(chan updateResult, 1)
	app.UpdateCh = ch
	go func() {
		feed, err := readUpdateFeedURL()
		if err != nil {
			msg := "Автообновление не настроено: добавь HTTPS-ссылку на update.json в разделе «Настройки»."
			if language == "en" {
				msg = "Auto-update is not configured: add an HTTPS update.json URL in Settings."
			}
			ch <- updateResult{Status: msg}
			return
		}
		manifest, err := fetchUpdateManifest(feed)
		if err != nil {
			msg := "Не удалось проверить обновления: " + err.Error()
			if language == "en" {
				msg = "Update check failed: " + err.Error()
			}
			ch <- updateResult{Status: msg}
			return
		}
		if isNewerVersion(manifest.Version, appVersion) {
			msg := "Найдена новая версия " + manifest.Version + ". Начинаем автоматическое обновление."
			if language == "en" {
				msg = "Version " + manifest.Version + " found. Starting automatic update."
			}
			ch <- updateResult{Available: true, Manifest: manifest, Status: msg}
			return
		}
		msg := "Установлена последняя версия " + appVersion + "."
		if language == "en" {
			msg = "You have the latest version " + appVersion + "."
		}
		ch <- updateResult{Status: msg}
	}()
}

func startUpdateInstall() {
	if app.UpdateInstalling || app.UpdateURL == "" || app.UpdateSHA256 == "" {
		app.UpdateStatus = "Сейчас обновление недоступно или уже выполняется."
		invalidate()
		return
	}
	app.UpdateInstalling = true
	msg := "Скачивание и проверка обновления..."
	if app.Language == "en" {
		msg = "Downloading and verifying update..."
	}
	app.UpdateStatus = msg
	ch := make(chan updateResult, 1)
	app.UpdateCh = ch
	manifest := updateManifest{Version: app.UpdateVersion, DownloadURL: app.UpdateURL, SHA256: app.UpdateSHA256, Notes: app.UpdateNotes}
	language := app.Language
	go func() {
		result := downloadAndStageUpdate(manifest, language)
		ch <- result
	}()
	invalidate()
}

func downloadAndStageUpdate(manifest updateManifest, language string) updateResult {
	client := &http.Client{Timeout: 2 * time.Minute, CheckRedirect: httpsOnlyRedirect}
	req, err := http.NewRequest(http.MethodGet, manifest.DownloadURL, nil)
	if err != nil {
		return updateResult{Status: "Update download failed: " + err.Error()}
	}
	req.Header.Set("User-Agent", "VOID-Optimizer-Updater/"+appVersion)
	resp, err := client.Do(req)
	if err != nil {
		return updateResult{Status: "Update download failed: " + err.Error()}
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return updateResult{Status: fmt.Sprintf("Update server returned HTTP %d", resp.StatusCode)}
	}
	if resp.ContentLength > 120*1024*1024 {
		return updateResult{Status: "Update file exceeds the 120 MB safety limit."}
	}
	target, err := os.Executable()
	if err != nil {
		return updateResult{Status: "Cannot locate current EXE: " + err.Error()}
	}
	target, err = filepath.Abs(target)
	if err != nil {
		return updateResult{Status: "Cannot resolve current EXE path: " + err.Error()}
	}
	tmp, err := os.CreateTemp(filepath.Dir(target), ".void-update-*.exe")
	if err != nil {
		return updateResult{Status: "Cannot create update file beside the EXE: " + err.Error()}
	}
	tmpPath := tmp.Name()
	cleanup := func() { _ = tmp.Close(); _ = os.Remove(tmpPath) }
	h := sha256.New()
	n, copyErr := io.Copy(io.MultiWriter(tmp, h), io.LimitReader(resp.Body, 120*1024*1024+1))
	if copyErr != nil {
		cleanup()
		return updateResult{Status: "Update download failed: " + copyErr.Error()}
	}
	if n < 2 || n > 120*1024*1024 {
		cleanup()
		return updateResult{Status: "Update file size is invalid or exceeds 120 MB."}
	}
	if err := tmp.Sync(); err != nil {
		cleanup()
		return updateResult{Status: "Cannot flush downloaded update: " + err.Error()}
	}
	if err := tmp.Close(); err != nil {
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot close downloaded update: " + err.Error()}
	}
	if !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), manifest.SHA256) {
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Update SHA-256 verification failed. The current app was not changed."}
	}
	f, err := os.Open(tmpPath)
	if err != nil {
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot verify update executable: " + err.Error()}
	}
	var signature [2]byte
	_, err = f.Read(signature[:])
	_ = f.Close()
	if err != nil || signature != [2]byte{'M', 'Z'} {
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Downloaded file is not a Windows executable."}
	}
	backup := target + ".previous.exe"
	script, err := os.CreateTemp(os.TempDir(), "void-update-*.ps1")
	if err != nil {
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot create updater script: " + err.Error()}
	}
	psLiteral := func(value string) string { return "'" + strings.ReplaceAll(value, "'", "''") + "'" }
	body := fmt.Sprintf(`$ErrorActionPreference = 'Stop'
$waitForPid = %d
$target = %s
$newFile = %s
$backup = %s
$deadline = [DateTime]::UtcNow.AddSeconds(120)
$updated = $false
try {
    while (Get-Process -Id $waitForPid -ErrorAction SilentlyContinue) {
        if ([DateTime]::UtcNow -ge $deadline) { throw 'Timed out waiting for the app to close.' }
        Start-Sleep -Seconds 1
    }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Current executable was not found.' }
    Copy-Item -LiteralPath $target -Destination $backup -Force
    try {
        Copy-Item -LiteralPath $newFile -Destination $target -Force
        Start-Process -FilePath $target
        $updated = $true
    } catch {
        Copy-Item -LiteralPath $backup -Destination $target -Force
        throw
    }
} catch {
    if (-not $updated -and (Test-Path -LiteralPath $backup -PathType Leaf)) {
        Copy-Item -LiteralPath $backup -Destination $target -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $target -PathType Leaf) { Start-Process -FilePath $target }
    }
} finally {
    Remove-Item -LiteralPath $newFile -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
}
`, os.Getpid(), psLiteral(target), psLiteral(tmpPath), psLiteral(backup))
	if _, err := script.WriteString(body); err != nil {
		_ = script.Close()
		_ = os.Remove(script.Name())
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot write updater script: " + err.Error()}
	}
	scriptPath := script.Name()
	if err := script.Close(); err != nil {
		_ = os.Remove(scriptPath)
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot finish updater script: " + err.Error()}
	}
	cmd := exec.Command(systemCommandPath("powershell.exe"), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", scriptPath)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if err := cmd.Start(); err != nil {
		_ = os.Remove(scriptPath)
		_ = os.Remove(tmpPath)
		return updateResult{Status: "Cannot launch updater: " + err.Error()}
	}
	msg := "Обновление проверено по SHA-256. VOID закроется, установщик заменит EXE и запустит новую версию. Резервная копия сохранится рядом."
	if language == "en" {
		msg = "SHA-256 verified. VOID will close, replace the EXE and launch the new version. A backup will be kept beside it."
	}
	return updateResult{Status: msg, InstallReady: true}
}

func clampInt(value, minValue, maxValue int) int {
	if value < minValue {
		return minValue
	}
	if value > maxValue {
		return maxValue
	}
	return value
}

func tweakScrollMax() int {
	// Single-column readable list + warning, status and rollback controls.
	contentBottom := 150 + len(tweakCardCatalog())*58 + 184 + 42
	return maxInt(0, contentBottom-822)
}

func bindScrollMax() int {
	contentBottom := 205 + len(rustUtilityBindSpecs())*68 + 112
	return maxInt(0, contentBottom-822)
}

func drawScrollBar(hdc uintptr, x, top, bottom, offset, maxOffset int) {
	if maxOffset <= 0 {
		return
	}
	fill(hdc, rect{int32(x), int32(top), int32(x + 3), int32(bottom)}, uint32(colCardLine))
	track := bottom - top
	thumbHeight := track * track / (track + maxOffset)
	if thumbHeight < 36 {
		thumbHeight = 36
	}
	thumbTop := top + (track-thumbHeight)*offset/maxOffset
	fill(hdc, rect{int32(x - 1), int32(thumbTop), int32(x + 4), int32(thumbTop + thumbHeight)}, uint32(colPurple))
}

func rustKeyFromVirtualKey(vk uint32) string {
	switch {
	case vk >= 'A' && vk <= 'Z':
		return strings.ToLower(string(rune(vk)))
	case vk >= '0' && vk <= '9':
		return string(rune(vk))
	case vk >= 0x70 && vk <= 0x7B:
		return fmt.Sprintf("f%d", vk-0x6F)
	}
	switch vk {
	case 0x20:
		return "space"
	case 0x09:
		return "tab"
	case 0x14:
		return "capslock"
	case 0x12:
		return "leftalt"
	case 0x10:
		return "leftshift"
	case 0x11:
		return "leftctrl"
	case 0xA4:
		return "leftalt"
	case 0xA5:
		return "rightalt"
	case 0xA0:
		return "leftshift"
	case 0xA1:
		return "rightshift"
	case 0xA2:
		return "leftctrl"
	case 0xA3:
		return "rightctrl"
	case 0x24:
		return "home"
	case 0x23:
		return "end"
	case 0x2D:
		return "insert"
	case 0x2E:
		return "delete"
	}
	return ""
}

func assignRustBindKey(id, key string) {
	key = strings.ToLower(strings.TrimSpace(key))
	candidate := normalizedRustBindKeys(app.BindKeys)
	if _, exists := candidate[id]; !exists {
		app.CapturingBind = ""
		return
	}
	for otherID, otherKey := range candidate {
		if otherID != id && strings.EqualFold(otherKey, key) {
			app.Status = "Клавиша " + strings.ToUpper(key) + " уже назначена для «" + otherID + ". Выбери другую."
			app.CapturingBind = ""
			showButtons()
			return
		}
	}
	previous := candidate[id]
	candidate[id] = key
	app.CapturingBind = ""
	app.BindKeys = candidate
	app.CustomLootKey = candidate["loot"]
	app.ViewmodelKey = candidate["viewmodel"]
	if err := savePrefs(); err != nil {
		app.BindKeys[id] = previous
		app.CustomLootKey = app.BindKeys["loot"]
		app.ViewmodelKey = app.BindKeys["viewmodel"]
		app.Status = "Не удалось сохранить клавишу: " + err.Error()
	} else {
		app.Status = "Сохранено: " + strings.ToUpper(key) + ". Нажми «Установить бинды» после настройки всех клавиш."
		if app.Language == "en" {
			app.Status = "Saved: " + strings.ToUpper(key) + ". Press Apply Binds when all keys are configured."
		}
	}
	showButtons()
}

func prefsPath() string {
	return filepath.Join(appDataRoot(), "VOID Optimizer", "settings.json")
}
func tweaksBackupPath() string {
	return filepath.Join(appDataRoot(), "VOID Optimizer", "tweaks-backup.json")
}
func loadPrefs() {
	b, err := os.ReadFile(prefsPath())
	if err != nil {
		return
	}
	var p prefsState
	if json.Unmarshal(b, &p) != nil {
		return
	}
	if p.Language == "ru" || p.Language == "en" {
		app.Language = p.Language
	}
	if p.Theme == "purple" || p.Theme == "blue" {
		app.Theme = p.Theme
	}
	app.Login = strings.TrimSpace(p.Login)
	app.UpdateFeedURL = strings.TrimSpace(p.UpdateFeedURL)
	app.RustTrackedIDs = normalizeSteamIDs(p.RustTrackedIDs)
	app.BindKeys = normalizedRustBindKeys(p.BindKeys)
	// Migrate key customizations saved by releases before the per-bind editor.
	if p.BindKeys == nil {
		if validRustCustomKey(p.CustomLootKey) {
			app.BindKeys["loot"] = strings.ToLower(p.CustomLootKey)
		}
		if validRustCustomKey(p.ViewmodelKey) {
			app.BindKeys["viewmodel"] = strings.ToLower(p.ViewmodelKey)
		}
	}
	app.CustomLootKey = app.BindKeys["loot"]
	app.ViewmodelKey = app.BindKeys["viewmodel"]
}
func savePrefs() error {
	keys := normalizedRustBindKeys(app.BindKeys)
	b, err := json.MarshalIndent(prefsState{Language: app.Language, Theme: app.Theme, Login: strings.TrimSpace(app.Login), UpdateFeedURL: strings.TrimSpace(app.UpdateFeedURL), CustomLootKey: strings.ToLower(strings.TrimSpace(keys["loot"])), ViewmodelKey: strings.ToLower(strings.TrimSpace(keys["viewmodel"])), BindKeys: keys, RustTrackedIDs: normalizeSteamIDs(app.RustTrackedIDs)}, "", "  ")
	if err != nil {
		return err
	}
	if err := writeFileAtomic(prefsPath(), b, 0600); err != nil {
		return err
	}
	// Verify that the persisted identity can be read back before dismissing first-run.
	check, err := os.ReadFile(prefsPath())
	if err != nil {
		return err
	}
	var saved prefsState
	if err := json.Unmarshal(check, &saved); err != nil {
		return err
	}
	if strings.TrimSpace(saved.Login) != strings.TrimSpace(app.Login) {
		return fmt.Errorf("saved login did not verify")
	}
	if strings.ToLower(strings.TrimSpace(saved.ViewmodelKey)) != strings.ToLower(strings.TrimSpace(app.ViewmodelKey)) {
		return fmt.Errorf("saved viewmodel key did not verify")
	}
	for id, key := range keys {
		if strings.ToLower(strings.TrimSpace(saved.BindKeys[id])) != key {
			return fmt.Errorf("saved bind key %s did not verify", id)
		}
	}
	return nil
}
func applyTheme() {
	if app.Theme == "blue" {
		colBg, colSidebar, colCard, colCardLine = 0x21110A, 0x2B160D, 0x302018, 0x8A5735
		colPurple, colPurple2 = 0xFFB36A, 0xD98A42 // COLORREF BGR: vivid arctic blue
		colText, colMuted = 0xF3F7FF, 0xAAB8D2
		colGreen, colOrange = 0x75D6A0, 0x55A9FF
	} else {
		colBg, colSidebar, colCard, colCardLine = 0x180A12, 0x24101B, 0x2D1725, 0x694078
		colPurple, colPurple2 = 0xFF5B9D, 0xBE3666
		colText, colMuted = 0xFAEDF1, 0xB99AA4
		colGreen, colOrange = 0x75D6A0, 0x55A9FF
	}
	selectThemeCursor()
}
func languageButtonLabel() string {
	if app.Language == "ru" {
		return "ЯЗЫК: РУССКИЙ → ENGLISH"
	}
	return "LANGUAGE: ENGLISH → RUSSIAN"
}
func themeButtonLabel() string {
	if app.Language == "en" {
		if app.Theme == "purple" {
			return "THEME: VOID PURPLE → ARCTIC BLUE"
		}
		return "THEME: ARCTIC BLUE → VOID PURPLE"
	}
	if app.Theme == "purple" {
		return "ТЕМА: VOID PURPLE → ARCTIC BLUE"
	}
	return "ТЕМА: ARCTIC BLUE → VOID PURPLE"
}

func tx(in string) string {
	if app.Language != "en" {
		return in
	}
	translations := map[string]string{
		"РАЗРЕШЕНИЕ ЭКРАНА": "SCREEN RESOLUTION", "ПРОВЕРИТЬ ОБНОВЛЕНИЯ": "CHECK FOR UPDATES", "СОХРАНИТЬ URL": "SAVE URL", "ОБНОВЛЕНИЯ ВНУТРИ VOID": "UPDATES INSIDE VOID", "ПРОДОЛЖИТЬ": "CONTINUE", "ВКЛЮЧИТЬ АВТОЗАПУСК": "ENABLE AUTOSTART", "ОТКЛЮЧИТЬ АВТОЗАПУСК": "DISABLE AUTOSTART", "ПЕРВЫЙ ЗАПУСК VOID": "VOID FIRST RUN", "АВТОЗАПУСК С WINDOWS": "WINDOWS STARTUP", "ПРОВЕРКА ОБНОВЛЕНИЙ": "UPDATE CHECK", "ОБЗОР": "OVERVIEW", "ОЧИСТКА": "CLEANUP", "ОПТИМИЗАЦИЯ ПК": "PC OPTIMIZATION", "ОПТИМИЗАЦИЯ RUST": "RUST OPTIMIZATION", "ЦВЕТА МОНИТОРА": "MONITOR COLORS", "ТВИКИ": "TWEAKS", "НАСТРОЙКИ": "SETTINGS",
		"БИНДЫ RUST": "RUST BINDS", "БИНДЫ RUST — УДОБСТВО УПРАВЛЕНИЯ": "RUST BINDS — QUALITY OF LIFE", "Утилитарные клавиши управления. Без боевых макросов и автоматизации атак.": "Utility movement controls. No combat macros or attack automation.", "СКАНИРОВАТЬ": "SCAN", "УДАЛИТЬ НАЙДЕННОЕ": "DELETE FOUND", "ПРИМЕНИТЬ BOOST": "APPLY BOOST", "ВЕРНУТЬ КАК БЫЛО": "RESTORE", "ОБНОВИТЬ ПОИСК": "RESCAN RUST", "ВЫБРАТЬ RUSTCLIENT.EXE": "BROWSE RUSTCLIENT.EXE", "ОТКРЫТЬ ПАПКУ ИГРЫ": "OPEN GAME FOLDER", "МАКС. FPS": "MAX FPS", "ВЫЖИВАНИЕ": "SURVIVAL", "ДАЛЬНОСТЬ 2000": "DRAW DISTANCE 2000", "ПРИМЕНИТЬ CFG": "APPLY CFG", "ОТКАТИТЬ CFG": "RESTORE CFG", "ПУСТЫНЯ": "DESERT", "ЛЕС": "FOREST", "ЗИМА": "WINTER", "СБРОС": "RESET", "ОТКАТИТЬ ВСЕ ТВИКИ": "RESTORE ALL TWEAKS", "ОЧИСТИТЬ DNS-КЭШ": "FLUSH DNS CACHE",
		"СИСТЕМА": "SYSTEM", "ТВИКИ WINDOWS": "WINDOWS TWEAKS", "RUST PERFORMANCE": "RUST PERFORMANCE", "WINDOWS 11  •  X64": "WINDOWS 11  •  X64",
		"Безопасная очистка временных файлов пользователя. Кэш шейдеров и игровые папки не трогаем.":        "Safely cleans user temporary files. Shader caches and game folders are left untouched.",
		"Одна кнопка применяет обратимые настройки Windows и доступное GPU-предпочтение для Rust.":          "Reversible Windows settings instead of dubious FPS tweaks.",
		"Графические профили client.cfg с резервной копией и откатом. Применение только при закрытом Rust.": "Graphics client.cfg profiles with backup and restore. Apply only while Rust is closed.",
		"Универсальная коррекция через Windows, без AMD Adrenalin и NVIDIA Control Panel.":                  "Vendor-neutral Windows color correction. No AMD Adrenalin or NVIDIA Control Panel required.",
		"Популярные, обратимые параметры Windows с резервной копией исходных значений.":                     "Popular reversible Windows tweaks with backups of original values.",
		"Выбери язык интерфейса и цветовую тему VOID. Настройки сохраняются автоматически.":                 "Choose the interface language and VOID color theme. Preferences are saved automatically.",
		"АВТОМАТИЧЕСКОЕ ОБНАРУЖЕНИЕ RUST": "AUTOMATIC RUST DETECTION", "БЕЗОПАСНЫЙ РЕЖИМ RUST": "RUST SAFE MODE", "ОПТИМИЗАЦИЯ CLIENT.CFG — SAFE APPLY": "ОПТИМИЗАЦИЯ CLIENT.CFG — SAFE APPLY", "ПУБЛИЧНЫЕ ИСТОЧНИКИ CFG": "PUBLIC CFG SOURCES",
		"ИГРОВОЙ РЕЖИМ WINDOWS": "WINDOWS GAME MODE", "ОТКЛЮЧИТЬ ФОНОВУЮ ЗАПИСЬ (GAME DVR)": "DISABLE GAME DVR", "ОТКЛЮЧИТЬ ПРОЗРАЧНОСТЬ": "DISABLE TRANSPARENCY", "ВИЗУАЛЬНЫЕ ЭФФЕКТЫ: БЫСТРОДЕЙСТВИЕ": "VISUAL EFFECTS: PERFORMANCE", "СЕТЕВАЯ УТИЛИТА": "NETWORK UTILITY", "БЕЗОПАСНОСТЬ": "SAFETY",
		"ЯЗЫК ИНТЕРФЕЙСА": "INTERFACE LANGUAGE", "ЦВЕТОВАЯ ТЕМА": "COLOR THEME", "О ПРОГРАММЕ": "ABOUT", "ТВОЯ СБОРКА": "YOUR PC", "ЧТО ДЕЛАЕТ VOID": "WHAT VOID DOES", "ВАЖНО ПРО FPS": "FPS NOTES", "АВТООПРЕДЕЛЕНИЕ КОМПЛЕКТУЮЩИХ": "AUTOMATIC HARDWARE DETECTION", "АВТОЗАПУСК WINDOWS": "WINDOWS STARTUP", "О ПРОГРАММЕ И ОБНАРУЖЕНИЕ ПК": "ABOUT & HARDWARE DETECTION", "Компоненты ПК обнаружены автоматически.": "PC components detected automatically.", "Повторно определяем комплектующие ПК...": "Detecting PC components again...", "Комплектующие обнаружены и показаны на главной странице": "Hardware detected and shown on the overview page", "Автоопределение комплектующих: проверка при каждом запуске": "Hardware is detected at every app launch", "Автозапуск выключен": "Autostart disabled", "Автозапуск включён — VOID запустится при входе в Windows": "Autostart enabled — VOID starts when you sign in to Windows",
		"РЕЗУЛЬТАТ СКАНИРОВАНИЯ": "SCAN RESULTS", "ЧТО МЫ НЕ ТРОГАЕМ": "WHAT WE LEAVE ALONE", "СТАТУС": "STATUS", "ПОЧЕМУ БЕЗ АГРЕССИВНЫХ ТВИКОВ": "WHY NO AGGRESSIVE TWEAKS",
		"ЦВЕТОВЫЕ ПРОФИЛИ И РУЧНАЯ КОРРЕКЦИЯ": "UNIVERSAL MONITOR COLORS", "ПАПКА ИГРЫ": "GAME FOLDER", "ГРАФИКА RUST": "RUST GRAPHICS REFERENCE",
		"ЯЗЫК: РУССКИЙ → ENGLISH": "LANGUAGE: RUSSIAN → ENGLISH", "АВТОЗАПУСК: ВКЛЮЧЁН — ВЫКЛЮЧИТЬ": "AUTOSTART: ENABLED — TURN OFF", "АВТОЗАПУСК: ВЫКЛЮЧЕН — ВКЛЮЧИТЬ": "AUTOSTART: DISABLED — TURN ON", "ПОВТОРНО ОПРЕДЕЛИТЬ ПК": "RESCAN PC COMPONENTS", "ТЕМА: VOID PURPLE → ARCTIC BLUE": "THEME: VOID PURPLE → ARCTIC BLUE", "ТЕМА: ARCTIC BLUE → VOID PURPLE": "THEME: ARCTIC BLUE → VOID PURPLE",
		"Rust найден. CFG можно применять при закрытой игре; исходный файл будет сохранён.": "Rust detected. CFG can be applied while the game is closed; the original file will be backed up.",
		"Rust обнаружен: игра запущена. VOID работает только в режиме наблюдения.":          "Rust detected: game is running. VOID is in read-only monitoring mode.",
		"Rust закрыт. Можно безопасно применить или откатить CFG.":                          "Rust is closed. CFG can now be applied or restored.",
		"Яркость": "Brightness", "Контрастность": "Contrast", "Гамма": "Gamma", "Красный канал": "Red channel", "Зелёный канал": "Green channel", "Синий канал": "Blue channel",
		"Текущий язык: Русский": "Current language: Russian", "Текущий язык: English": "Current language: English", "Текущая тема: VOID Purple": "Current theme: VOID Purple", "Текущая тема: Arctic Blue": "Current theme: Arctic Blue",
		"ПРИМЕНИТЬ": "APPLY", "ВЫКЛЮЧИТЬ": "DISABLE", "ВКЛЮЧИТЬ": "ENABLE", "УЖЕ ВКЛЮЧЕНО": "ALREADY ON",
		"Готов к работе.": "Ready.", "Настройки производительности для твоего ПК": "Performance settings for your PC",
		"Не удалось получить сведения о комплектующих через Windows.":                              "Windows could not return hardware information.",
		"Steam/Rust не найдены. Выбери RustClient.exe вручную.":                                    "Steam/Rust not found. Select RustClient.exe manually.",
		"Открыта папка Rust. VOID не изменяет её содержимое.":                                      "Rust folder opened. VOID does not modify its contents.",
		"Папка Rust пока не найдена.":                                                              "Rust folder has not been detected yet.",
		"Выбрана тёплая цветовая температура.":                                                     "Warm color temperature selected.",
		"Выбрана нейтральная цветовая температура.":                                                "Neutral color temperature selected.",
		"Выбрана холодная цветовая температура.":                                                   "Cool color temperature selected.",
		"Исходная gamma ramp восстановлена.":                                                       "Original gamma ramp restored.",
		"Автозапуск VOID отключён.":                                                                "VOID autostart disabled.",
		"VOID будет запускаться при входе в Windows.":                                              "VOID will start when you sign in to Windows.",
		"Сначала нажми «Сканировать», чтобы увидеть список временных файлов.":                      "Scan first to review the list of temporary files.",
		"Сканирование завершено: старых временных файлов для удаления не найдено.":                 "Scan complete: no old temporary files were found.",
		"Сканирование временных папок выполняется в фоне...":                                       "Scanning temporary folders in the background...",
		"Удаление найденных временных файлов выполняется в фоне...":                                "Deleting selected temporary files in the background...",
		"Подожди завершения текущей операции.":                                                     "Please wait for the current operation to finish.",
		"Нет сохранённых твиков для отката.":                                                       "There are no saved tweaks to restore.",
		"Все твики VOID восстановлены.":                                                            "All VOID tweaks have been restored.",
		"Файл резервных копий твиков повреждён. Изменение реестра заблокировано для безопасности.": "The tweaks backup file is corrupted. Registry changes are blocked for safety.",
		"В backup найден неизвестный параметр реестра. Изменение реестра заблокировано.":           "The backup contains an unknown registry key. Registry changes are blocked.",
		"В backup найден неподдерживаемый тип реестра. Изменение реестра заблокировано.":           "The backup contains an unsupported registry type. Registry changes are blocked.",
		"В backup найдено некорректное значение реестра. Изменение реестра заблокировано.":         "The backup contains an invalid registry value. Registry changes are blocked.",
		"Твик отключён. Исходные значения восстановлены.":                                          "Tweak disabled. Original values restored.",
		"Твик включён. Исходные значения сохранены для отката.":                                    "Tweak enabled. Original values have been backed up.",
		"Очищает старые временные файлы, включает Windows Game Mode и предлагает обратимые параметры питания. Rust обнаруживается автоматически; профили только показывают советы и не меняют файлы игры.":                                     "Cleans old temporary files and offers reversible Windows power settings. Rust is detected automatically; profiles are informational and never modify game files.",
		"Очищает только старые TEMP-файлы.\nТвики Windows и Rust-настройки отдельные и обратимые.":                                                                                                                                             "Cleans only old TEMP files.\nWindows tweaks and Rust settings are separate and reversible.",
		"FPS зависит от температуры CPU/GPU, нагрузки по ядрам\nи фоновых приложений. Фиксированный прирост не обещается.":                                                                                                                     "FPS depends on CPU/GPU temperatures, per-core load\nand background apps. No fixed increase is promised.",
		"Defender, обновления и системные службы остаются включены.\nНет разгона, BCD и рискованных таймеров.":                                                                                                                                 "Defender, updates and essential services stay enabled.\nNo overclocking, BCD edits or risky timer tweaks.",
		"Если Rust держится около 40 FPS, причиной может быть нагрузка на отдельные ядра Xeon, перегрев, лимит питания, фоновые процессы или настройки сервера. VOID помогает проверить часть факторов, но не обещает выдуманный прирост FPS.": "If Rust runs near 40 FPS, possible causes include per-core Xeon limits, heat, power limits, background processes or server conditions. VOID can inspect some factors but cannot promise a fixed FPS gain.",
		"Не отключает Defender, обновления и важные службы Windows. Не меняет напряжения, BCD и таймеры. VOID не записывает данные в папку Rust, не внедряется в процесс и не читает память игры.":                                             "Does not disable Defender, updates or essential Windows services. Does not change voltages, boot settings or timers. VOID never writes to the Rust folder, injects into the process or reads game memory.",
		"Сканирует временные папки текущего пользователя. Файлы младше 1 часа и занятые системой файлы пропускаются.":                                                                                                                          "Scans the current user's temporary folders. Files newer than 1 hour and files in use are skipped.",
		"Выбирает схему питания High Performance. Windows Game Mode включается отдельно в разделе «Твики». Исходная схема сохраняется для отката.":                                                                                             "Selects the High Performance power plan. Windows Game Mode is configured separately in Tweaks. The previous plan is backed up for rollback.",
		"Не отключаем Defender, обновления, системные службы, сеть и защиту ядра. Не меняем BCD/HPET и не выставляем приоритеты всем процессам. High Performance может повысить нагрев и энергопотребление — наблюдай за температурой Xeon.":   "We do not disable Defender, updates, system services, networking or kernel protection. No BCD/HPET or global process-priority tweaks. High Performance can increase heat and power use; monitor CPU temperatures.",
		"Steam/Rust не найдены. Нажми «Обновить поиск» или выбери RustClient.exe вручную.":                                                                                                                                                     "Steam/Rust not found. Rescan or select RustClient.exe manually.",
		"VOID только проверяет наличие RustClient.exe и состояние процесса RustClient.exe.":                                                                                                                                                    "VOID only checks for RustClient.exe and whether the RustClient.exe process is running.",
		"НЕ ИЗМЕНЯЕТ client.cfg, игровые файлы или параметры запуска. Не внедряется в игру, не читает память и не взаимодействует с античитом.":                                                                                                "Does NOT modify client.cfg, game files or launch options. It does not inject into the game, read memory or interact with anti-cheat.",
		"Выбирай профиль, чтобы увидеть рекомендуемые параметры. Для изменения графики используй только настройки самой Rust.":                                                                                                                 "Choose a profile to view suggested values. Change graphics only through Rust's own settings.",
		"Цветовая температура задаётся балансом RGB. Отдельный ползунок насыщенности не заявлен: стандартный Windows gamma ramp не умеет корректировать digital vibrance.":                                                                     "Color temperature is adjusted through RGB balance. There is no saturation slider: the standard Windows gamma ramp cannot adjust digital vibrance.",
		"Использует стандартный Windows gamma ramp для основного дисплея, без AMD/NVIDIA панелей. HDR и отдельные драйверы/мониторы могут ограничивать функцию.":                                                                               "Uses the standard Windows gamma ramp for the primary display, without AMD/NVIDIA control panels. HDR and some drivers or monitors may limit it.",
		"Включает игровой режим Windows для управления фоновыми задачами.":                                                                                                                                                                     "Enables Windows Game Mode to help manage background activity.",
		"Отключает фоновую запись и захват клипов Windows. Не отключает Xbox/Steam целиком.":                                                                                                                                                   "Disables background Windows recording and clip capture. It does not disable Xbox or Steam entirely.",
		"Убирает прозрачность интерфейса Windows. Небольшая косметическая экономия ресурсов.":                                                                                                                                                  "Turns off Windows interface transparency. This is a small visual-effects change, not a guaranteed FPS boost.",
		"Устанавливает системный режим визуальных эффектов на приоритет производительности.":                                                                                                                                                   "Sets Windows visual effects to prioritize performance.",
		"Очистка DNS-кэша помогает только при проблемах с устаревшими DNS-записями. Она не повышает FPS и не гарантирует снижение ping.":                                                                                                       "Flushing DNS cache only helps with stale DNS records. It does not increase FPS or guarantee lower ping.",
		"Каждый твик сохраняет исходное значение реестра. «Откатить все» возвращает прежние значения. Защитник, обновления, службы и античит не отключаются.":                                                                                  "Each tweak backs up the original registry value. Restore All puts previous values back. Defender, updates, services and anti-cheat are not disabled.",
		"VOID Optimizer не разгоняет CPU/GPU и не обещает фиксированный прирост FPS. Все системные твики обратимы; игровые файлы Rust не изменяются.":                                                                                          "VOID Optimizer does not overclock the CPU/GPU or promise a fixed FPS gain. System tweaks are reversible; Rust game files are never modified.",
		"БЫСТРАЯ ОПТИМИЗАЦИЯ": "QUICK OPTIMIZATION", "ОТКАТИТЬ НАСТРОЙКИ": "RESTORE SETTINGS",
		"РУССКИЙ": "RUSSIAN", "ENGLISH": "ENGLISH", "VOID PURPLE": "VOID PURPLE", "ARCTIC BLUE": "ARCTIC BLUE",
		"АНИМАЦИЯ ОКОН": "WINDOW ANIMATIONS", "СКОРОСТЬ МЕНЮ": "MENU RESPONSE",
		"ФОНОВАЯ ЗАПИСЬ GAME DVR": "GAME DVR BACKGROUND CAPTURE", "ПРОЗРАЧНОСТЬ WINDOWS": "WINDOWS TRANSPARENCY",
		"СОСТОЯНИЕ ПК": "PC STATUS", "ЧТО МЕНЯЕТ ПРОФИЛЬ": "PROFILE CHANGES", "РЕЗУЛЬТАТ И ОТКАТ": "RESULT & RESTORE",
		"GAME BAR OVERLAY": "GAME BAR OVERLAY", "GPU ДЛЯ RUST": "GPU PREFERENCE FOR RUST", "RUST НЕ НАЙДЕН": "RUST NOT FOUND",
		"Включает Game Mode, чтобы Windows корректнее распределяла фоновые ресурсы во время игры.":                                              "Enables Game Mode so Windows can better manage background resources while gaming.",
		"Отключает фоновые клипы и захват. Обычная запись вручную может быть недоступна.":                                                       "Disables background clips and capture. Manual recording may no longer be available.",
		"Отключает визуальную прозрачность интерфейса. Небольшое снижение нагрузки на композицию рабочего стола.":                               "Turns off interface transparency. This may slightly reduce desktop-composition overhead.",
		"Переключает эффекты Windows на приоритет быстродействия.":                                                                              "Sets Windows visual effects to prioritize performance.",
		"Отключает анимацию сворачивания и разворачивания окон.":                                                                                "Turns off minimize and restore animations.",
		"Убирает задержку открытия меню Windows. Не влияет напрямую на FPS в игре.":                                                             "Removes Windows menu-opening delay. It does not directly increase in-game FPS.",
		"Отключает запуск Xbox Game Bar overlay и стартовую панель. Можно вернуть одним нажатием.":                                              "Disables the Xbox Game Bar overlay and startup panel. It can be restored with one click.",
		"Назначает RustClient.exe режим Windows «Высокая производительность». Нужна повторная загрузка игры; эффект зависит от нескольких GPU.": "Sets RustClient.exe to Windows High performance graphics preference. Restart the game; this matters most on systems with multiple GPUs.",
		"СТАТУС И БЕЗОПАСНОСТЬ":                                          "STATUS & SAFETY",
		"Убирает задержку открытия меню Windows. Не меняет FPS в играх.": "Removes the Windows menu opening delay. It does not change in-game FPS.",
		"Включает Game Mode, чтобы Windows отдавала игре приоритет.":     "Enables Game Mode so Windows can prioritize games.",
		"Отключает фоновый захват клипов, когда запись не нужна.":        "Disables background clip capture when recording is not needed.",
		"Убирает прозрачность интерфейса. Эффект в основном визуальный.": "Turns off interface transparency. The effect is mainly visual.",
		"Ставит системные эффекты на приоритет быстродействия.":          "Sets Windows visual effects to prioritize responsiveness.",
		"Комплексная оптимизация Windows: Game Mode, захват и оверлеи, визуальные эффекты, отзывчивость интерфейса, автозагрузка и выбор GPU для Rust. Дополнительные системные твики доступны отдельно; все изменения сохраняют резервную копию и откатываются.": "A broader Windows optimization profile: Game Mode, capture and overlays, visual effects, interface responsiveness, startup behavior and Rust GPU preference. Optional system tweaks are available separately; registry changes are backed up and reversible.",
		"Сейчас выбрано: Русский. Нажми отдельную кнопку для смены языка.": "Selected: Russian. Use the separate buttons to change language.",
		"Язык интерфейса: русский.":                                        "Interface language: Russian.", "Цветовая тема изменена.": "Color theme changed.",
		"Все двадцать три твика сохраняют исходные значения. «Откатить все» возвращает их. Защитник, обновления и системные службы не отключаются.":       "All twenty-three tweaks save their original values. Restore All reverts them. Defender, updates and system services stay enabled.",
		"DNS-кэш очищается только при проблемах с устаревшими DNS-записями; прирост FPS или снижение ping не гарантируются.":                              "DNS cache flush only helps with stale DNS entries; no FPS increase or lower ping is guaranteed.",
		"Показывает список перед удалением. Файлы старше 1 часа удаляются только из TEMP текущего пользователя; занятые и защищённые файлы пропускаются.": "Previews files before deletion. Files older than 1 hour are removed only from the current user's TEMP folders; locked and protected files are skipped.",
		"РАЗРЕШЕНИЕ":                          "DISPLAY",
		"РАЗРЕШЕНИЕ МОНИТОРА":                 "MONITOR RESOLUTION",
		"ТЕКУЩИЙ РЕЖИМ И СПИСОК":              "CURRENT MODE AND AVAILABLE MODES",
		"АВТОМАТИЧЕСКОЕ ОБНАРУЖЕНИЕ МОНИТОРА": "AUTOMATIC DISPLAY DETECTION",
		"СВОЁ РАЗРЕШЕНИЕ":                     "CUSTOM RESOLUTION",
		"ПИТАНИЕ":                             "POWER",
		"ФОНОВЫЕ ПРИЛОЖЕНИЯ":                  "BACKGROUND APPS",
		"ПОИСК":                               "SEARCH",
		"ФОНОВАЯ АКТИВНОСТЬ STORE-ПРИЛОЖЕНИЙ": "STORE APP BACKGROUND ACTIVITY",
		"ПОДСВЕТКА ПОИСКА":                    "SEARCH HIGHLIGHTS",
		"ИСТОРИЯ ПОИСКА ПРОВОДНИКА":           "FILE EXPLORER SEARCH HISTORY",
		"Ограничивает фоновые задачи поддерживаемых Store-приложений там, где Windows учитывает глобальный флаг; уведомления и синхронизация могут остановиться.": "Limits supported Store-app background activity where Windows honors the global setting; notifications or sync may stop.",
		"Отключает декоративные подсказки и highlights в поиске.": "Turns off decorative Search highlights.",
	}
	if v, ok := translations[in]; ok {
		return v
	}
	return in
}

func changeKey(c regChange) string { return c.Key + "|" + c.Name }
func changesForTweak(id int) []regChange {
	switch id {
	case idTweakGame:
		return []regChange{{`HKCU\Software\Microsoft\GameBar`, "AutoGameModeEnabled", "1"}, {`HKCU\Software\Microsoft\GameBar`, "AllowAutoGameMode", "1"}}
	case idTweakDVR:
		return []regChange{{`HKCU\System\GameConfigStore`, "GameDVR_Enabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR`, "AppCaptureEnabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR`, "AudioCaptureEnabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR`, "CursorCaptureEnabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR`, "HistoricalCaptureEnabled", "0"}}
	case idTweakTrans:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`, "EnableTransparency", "0"}}
	case idTweakFX:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects`, "VisualFXSetting", "2"}}
	case idTweakAnim:
		return []regChange{{`HKCU\Control Panel\Desktop\WindowMetrics`, "MinAnimate", "0"}}
	case idTweakMenu:
		return []regChange{{`HKCU\Control Panel\Desktop`, "MenuShowDelay", "0"}}
	case idTweakOverlay:
		return []regChange{{`HKCU\Software\Microsoft\GameBar`, "GameBarEnabled", "0"}, {`HKCU\Software\Microsoft\GameBar`, "ShowStartupPanel", "0"}}
	case idTweakRustGPU:
		return rustGPUPreferenceChanges()
	case idTweakMouseAccel:
		return []regChange{{`HKCU\Control Panel\Mouse`, "MouseSpeed", "0"}, {`HKCU\Control Panel\Mouse`, "MouseThreshold1", "0"}, {`HKCU\Control Panel\Mouse`, "MouseThreshold2", "0"}}
	case idTweakTaskbarAnim:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "TaskbarAnimations", "0"}}
	case idTweakAeroPeek:
		return []regChange{{`HKCU\Software\Microsoft\Windows\DWM`, "EnableAeroPeek", "0"}}
	case idTweakListAlpha:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "ListviewAlphaSelect", "0"}}
	case idTweakDragFull:
		return []regChange{{`HKCU\Control Panel\Desktop`, "DragFullWindows", "0"}}
	case idTweakExplorerThumbs:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "IconsOnly", "1"}}
	case idTweakWidgets:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "TaskbarDa", "0"}}
	case idTweakTaskView:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "ShowTaskViewButton", "0"}}
	case idTweakTaskbarSearch:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "SearchboxTaskbarMode", "0"}}
	case idTweakStartRecs:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager`, "SystemPaneSuggestionsEnabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager`, "SubscribedContent-338388Enabled", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager`, "SubscribedContent-338389Enabled", "0"}}
	case idTweakStartupDelay:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize`, "StartupDelayInMSec", "0"}}
	case idTweakRecentFiles:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "ShowRecent", "0"}, {`HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "ShowFrequent", "0"}}
	case idTweakBackgroundApps:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications`, "GlobalUserDisabled", "1"}}
	case idTweakSearchHighlights:
		return []regChange{{`HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings`, "IsDynamicSearchBoxEnabled", "0"}}
	case idTweakSearchSuggestions:
		return []regChange{{`HKCU\Software\Policies\Microsoft\Windows\Explorer`, "DisableSearchBoxSuggestions", "1"}}
	}
	return nil
}
func rustGPUPreferenceChanges() []regChange {
	const key = `HKCU\Software\Microsoft\DirectX\UserGpuPreferences`
	// Prefer the path stored in the rollback journal. Steam libraries can move;
	// restoring the exact old registry value is more important than current discovery.
	prefix := strings.ToUpper(key + "|")
	for savedKey := range app.TweaksBackup {
		if strings.HasPrefix(strings.ToUpper(savedKey), prefix) {
			parts := strings.SplitN(savedKey, "|", 2)
			if len(parts) == 2 && strings.EqualFold(filepath.Base(parts[1]), "RustClient.exe") {
				return []regChange{{key, parts[1], "GpuPreference=2;"}}
			}
		}
	}
	folder := strings.TrimSpace(app.RustFolder)
	if folder == "" {
		folder = findRust()
		app.RustFolder = folder
	}
	if folder != "" {
		exe := filepath.Join(folder, "RustClient.exe")
		if _, err := os.Stat(exe); err == nil {
			return []regChange{{key, exe, "GpuPreference=2;"}}
		}
	}
	return nil
}

func regValueStrict(key, name string) (regSnapshot, error) {
	// All current VOID tweaks are under HKCU. Restrict the reader to this hive
	// instead of parsing locale-dependent `reg.exe` text output.
	const prefix = `HKCU\`
	if !strings.HasPrefix(strings.ToUpper(key), prefix) {
		return regSnapshot{}, fmt.Errorf("unsupported registry hive: %s", key)
	}
	subkey := key[len(prefix):]
	if subkey == "" {
		return regSnapshot{}, fmt.Errorf("empty registry subkey")
	}
	subkeyPtr, err := syscall.UTF16PtrFromString(subkey)
	if err != nil {
		return regSnapshot{}, err
	}
	var h syscall.Handle
	openErr := syscall.RegOpenKeyEx(syscall.Handle(syscall.HKEY_CURRENT_USER), subkeyPtr, 0, syscall.KEY_QUERY_VALUE, &h)
	runtime.KeepAlive(subkeyPtr)
	if err := openErr; err != nil {
		if err == syscall.ERROR_FILE_NOT_FOUND {
			return regSnapshot{}, nil
		}
		return regSnapshot{}, fmt.Errorf("open registry key %s: %w", key, err)
	}
	defer syscall.RegCloseKey(h)

	valuePtr, err := syscall.UTF16PtrFromString(name)
	if err != nil {
		return regSnapshot{}, err
	}
	var valueType uint32
	var size uint32
	queryErr := syscall.RegQueryValueEx(h, valuePtr, nil, &valueType, nil, &size)
	runtime.KeepAlive(valuePtr)
	if err := queryErr; err != nil {
		if err == syscall.ERROR_FILE_NOT_FOUND {
			return regSnapshot{}, nil
		}
		if err != syscall.ERROR_MORE_DATA {
			return regSnapshot{}, fmt.Errorf("query registry value %s: %w", name, err)
		}
	}
	var data []byte
	for attempt := 0; attempt < 3; attempt++ {
		data = make([]byte, size)
		var dataPtr *byte
		if len(data) > 0 {
			dataPtr = &data[0]
		}
		err = syscall.RegQueryValueEx(h, valuePtr, nil, &valueType, dataPtr, &size)
		runtime.KeepAlive(valuePtr)
		runtime.KeepAlive(data)
		if err == nil {
			data = data[:size]
			break
		}
		if err != syscall.ERROR_MORE_DATA {
			if err == syscall.ERROR_FILE_NOT_FOUND {
				return regSnapshot{}, nil
			}
			return regSnapshot{}, fmt.Errorf("read registry value %s: %w", name, err)
		}
		if attempt == 2 {
			return regSnapshot{}, fmt.Errorf("registry value %s kept changing while it was read", name)
		}
	}

	value := ""
	switch valueType {
	case syscall.REG_DWORD:
		if len(data) != 4 {
			return regSnapshot{}, fmt.Errorf("registry DWORD %s has invalid size %d", name, len(data))
		}
		value = strconv.FormatUint(uint64(binary.LittleEndian.Uint32(data)), 10)
	case syscall.REG_QWORD:
		if len(data) != 8 {
			return regSnapshot{}, fmt.Errorf("registry QWORD %s has invalid size %d", name, len(data))
		}
		value = strconv.FormatUint(binary.LittleEndian.Uint64(data), 10)
	case syscall.REG_SZ, syscall.REG_EXPAND_SZ:
		if len(data)%2 != 0 {
			return regSnapshot{}, fmt.Errorf("registry string %s has invalid UTF-16 size", name)
		}
		words := make([]uint16, len(data)/2)
		for i := range words {
			words[i] = binary.LittleEndian.Uint16(data[i*2 : i*2+2])
		}
		value = syscall.UTF16ToString(words)
	case syscall.REG_BINARY:
		return regSnapshot{Exists: true, Type: "REG_BINARY"}, nil
	default:
		return regSnapshot{Exists: true, Type: fmt.Sprintf("REG_TYPE_%d", valueType)}, nil
	}
	return regSnapshot{Exists: true, Type: registryTypeName(valueType), Value: value}, nil
}

func registryTypeName(t uint32) string {
	switch t {
	case syscall.REG_DWORD:
		return "REG_DWORD"
	case syscall.REG_QWORD:
		return "REG_QWORD"
	case syscall.REG_SZ:
		return "REG_SZ"
	case syscall.REG_EXPAND_SZ:
		return "REG_EXPAND_SZ"
	default:
		return fmt.Sprintf("REG_TYPE_%d", t)
	}
}

func regValue(key, name string) regSnapshot {
	value, err := regValueStrict(key, name)
	if err != nil {
		return regSnapshot{}
	}
	return value
}
func regMatches(c regChange) bool {
	r := regValue(c.Key, c.Name)
	wantType := "REG_DWORD"
	if c.Name == "MinAnimate" || c.Name == "MenuShowDelay" || c.Name == "MouseSpeed" || c.Name == "MouseThreshold1" || c.Name == "MouseThreshold2" || c.Name == "DragFullWindows" || strings.EqualFold(filepath.Base(c.Name), "RustClient.exe") {
		wantType = "REG_SZ"
	}
	if !r.Exists || !strings.EqualFold(r.Type, wantType) {
		return false
	}
	return r.Value == c.Desired
}
func tweakEnabled(id int) bool {
	changes := changesForTweak(id)
	if len(changes) == 0 {
		return false
	}
	for _, c := range changes {
		if !regMatches(c) {
			return false
		}
	}
	return true
}
func tweakButtonLabel(id int) string {
	if id == idTweakRustGPU && len(changesForTweak(id)) == 0 {
		if app.Language == "en" {
			return "RUST NOT FOUND"
		}
		return "RUST НЕ НАЙДЕН"
	}
	if tweakEnabled(id) {
		hasBackup := true
		for _, c := range changesForTweak(id) {
			if _, ok := app.TweaksBackup[changeKey(c)]; !ok {
				hasBackup = false
			}
		}
		if app.Language == "en" {
			if hasBackup {
				return "RESTORE"
			}
			return "ALREADY ON"
		}
		if hasBackup {
			return "ОТКАТИТЬ"
		}
		return "УЖЕ ВКЛЮЧЕНО"
	}
	if app.Language == "en" {
		return "ENABLE"
	}
	return "ВКЛЮЧИТЬ"
}
func validRegistrySnapshot(snap regSnapshot) bool {
	if !snap.Exists {
		return true
	}
	switch strings.ToUpper(snap.Type) {
	case "REG_DWORD":
		_, err := strconv.ParseUint(snap.Value, 10, 32)
		return err == nil
	case "REG_QWORD":
		_, err := strconv.ParseUint(snap.Value, 10, 64)
		return err == nil
	case "REG_SZ", "REG_EXPAND_SZ":
		return len(snap.Value) <= 4096 && !strings.ContainsRune(snap.Value, '\x00')
	default:
		return false
	}
}

func loadTweaksBackup() {
	app.TweaksBackup = map[string]regSnapshot{}
	app.TweaksBackupError = ""
	b, err := os.ReadFile(tweaksBackupPath())
	if os.IsNotExist(err) {
		return
	}
	if err != nil {
		app.TweaksBackupError = "Не удалось прочитать файл резервных копий твиков: " + err.Error()
		return
	}
	var values map[string]regSnapshot
	if err := json.Unmarshal(b, &values); err != nil || values == nil {
		app.TweaksBackupError = "Файл резервных копий твиков повреждён. Изменение реестра заблокировано для безопасности."
		return
	}
	for key, snap := range values {
		if !allowedTweaksBackupKey(key) {
			app.TweaksBackupError = "В backup найден неизвестный параметр реестра. Изменение реестра заблокировано."
			return
		}
		if !validRegistrySnapshot(snap) {
			app.TweaksBackupError = "В backup найден неподдерживаемый или некорректный тип/значение реестра. Изменение реестра заблокировано."
			return
		}
	}
	app.TweaksBackup = values
}
func allowedTweaksBackupKey(key string) bool {
	for _, id := range []int{idTweakGame, idTweakDVR, idTweakTrans, idTweakFX, idTweakAnim, idTweakMenu, idTweakOverlay, idTweakMouseAccel, idTweakTaskbarAnim, idTweakAeroPeek, idTweakListAlpha, idTweakDragFull, idTweakExplorerThumbs, idTweakWidgets, idTweakTaskView, idTweakTaskbarSearch, idTweakStartRecs, idTweakStartupDelay, idTweakRecentFiles, idTweakBackgroundApps, idTweakSearchHighlights, idTweakSearchSuggestions} {
		for _, change := range changesForTweak(id) {
			if strings.EqualFold(key, changeKey(change)) {
				return true
			}
		}
	}
	const gpuPrefix = `HKCU\Software\Microsoft\DirectX\UserGpuPreferences|`
	if strings.HasPrefix(strings.ToUpper(key), strings.ToUpper(gpuPrefix)) {
		parts := strings.SplitN(key, "|", 2)
		return len(parts) == 2 && strings.EqualFold(filepath.Base(parts[1]), "RustClient.exe")
	}
	return false
}
func saveTweaksBackupMap(values map[string]regSnapshot) error {
	b, err := json.MarshalIndent(values, "", "  ")
	if err != nil {
		return err
	}
	return writeFileAtomic(tweaksBackupPath(), b, 0600)
}
func cloneTweaksBackup(src map[string]regSnapshot) map[string]regSnapshot {
	dst := make(map[string]regSnapshot, len(src))
	for k, v := range src {
		dst[k] = v
	}
	return dst
}
func setRegChange(c regChange) error {
	typ := "REG_DWORD"
	if c.Name == "MinAnimate" || c.Name == "MenuShowDelay" || c.Name == "MouseSpeed" || c.Name == "MouseThreshold1" || c.Name == "MouseThreshold2" || c.Name == "DragFullWindows" || strings.EqualFold(filepath.Base(c.Name), "RustClient.exe") {
		typ = "REG_SZ"
	}
	_, err := runHidden("reg.exe", "add", c.Key, "/v", c.Name, "/t", typ, "/d", c.Desired, "/f")
	return err
}
func restoreReg(key, name string, snap regSnapshot) error {
	if !snap.Exists {
		_, err := runHidden("reg.exe", "delete", key, "/v", name, "/f")
		if err != nil {
			// Treat an already-absent value as success, but never hide a read error.
			current, readErr := regValueStrict(key, name)
			if readErr != nil {
				return readErr
			}
			if !current.Exists {
				return nil
			}
		}
		return err
	}
	_, err := runHidden("reg.exe", "add", key, "/v", name, "/t", snap.Type, "/d", snap.Value, "/f")
	return err
}
func applyTweak(id int) error {
	if app.TweaksBackupError != "" {
		return fmt.Errorf("%s", app.TweaksBackupError)
	}
	changes := changesForTweak(id)
	if len(changes) == 0 {
		return fmt.Errorf("для этого твика не найден подходящий компонент")
	}
	if tweakEnabled(id) {
		return nil
	}
	next := cloneTweaksBackup(app.TweaksBackup)
	for _, c := range changes {
		k := changeKey(c)
		if _, ok := next[k]; ok {
			continue
		}
		snapshot, err := regValueStrict(c.Key, c.Name)
		if err != nil {
			return fmt.Errorf("не удалось прочитать %s: %w", c.Name, err)
		}
		if !validRegistrySnapshot(snapshot) {
			return fmt.Errorf("исходное значение %s имеет неподдерживаемый тип", c.Name)
		}
		next[k] = snapshot
	}
	if err := saveTweaksBackupMap(next); err != nil {
		return fmt.Errorf("не удалось сохранить резервную копию: %w", err)
	}
	app.TweaksBackup = next
	app.TweaksBackupError = ""
	for _, c := range changes {
		if err := setRegChange(c); err != nil {
			return fmt.Errorf("ошибка применения %s: %w; резервная копия сохранена", c.Name, err)
		}
	}
	if !tweakEnabled(id) {
		return fmt.Errorf("Windows не подтвердил применение параметра")
	}
	return nil
}

func toggleTweak(id int) {
	if app.TweaksBackupError != "" {
		app.Status = app.TweaksBackupError
		return
	}
	changes := changesForTweak(id)
	if len(changes) == 0 {
		if app.Language == "en" {
			app.Status = "Rust was not detected. Select the Rust folder first."
		} else {
			app.Status = "Rust не найден. Сначала выбери папку Rust."
		}
		return
	}
	if tweakEnabled(id) {
		for _, c := range changes {
			if _, ok := app.TweaksBackup[changeKey(c)]; !ok {
				app.Status = "Параметр уже был включён до VOID; исходное значение неизвестно, поэтому откат заблокирован."
				return
			}
		}
		completed := []regChange{}
		for _, c := range changes {
			if err := restoreReg(c.Key, c.Name, app.TweaksBackup[changeKey(c)]); err != nil {
				for _, done := range completed {
					_ = setRegChange(done)
				}
				app.Status = "Не удалось восстановить " + c.Name + ": " + err.Error()
				return
			}
			completed = append(completed, c)
		}
		next := cloneTweaksBackup(app.TweaksBackup)
		for _, c := range changes {
			delete(next, changeKey(c))
		}
		if err := saveTweaksBackupMap(next); err != nil {
			app.Status = "Параметры восстановлены, но backup не обновлён: " + err.Error()
			return
		}
		app.TweaksBackup = next
		app.Status = "Твик отключён. Исходные значения восстановлены."
		return
	}
	if err := applyTweak(id); err != nil {
		app.Status = "Твик не применён: " + err.Error()
		return
	}
	app.Status = "Твик включён. Исходные значения сохранены для отката."
}

func restoreAllTweaks() {
	if app.TweaksBackupError != "" {
		app.Status = app.TweaksBackupError
		return
	}
	if len(app.TweaksBackup) == 0 {
		app.Status = "Нет сохранённых твиков для отката."
		return
	}
	failed := 0
	for k, snap := range app.TweaksBackup {
		parts := strings.SplitN(k, "|", 2)
		if len(parts) != 2 {
			failed++
			continue
		}
		if err := restoreReg(parts[0], parts[1], snap); err != nil {
			failed++
		}
	}
	if failed > 0 {
		app.Status = fmt.Sprintf("Не удалось восстановить параметров: %d. Backup сохранён для повторной попытки.", failed)
		return
	}
	if err := saveTweaksBackupMap(map[string]regSnapshot{}); err != nil {
		app.Status = "Твики восстановлены, но файл backup не удалось очистить: " + err.Error()
		return
	}
	app.TweaksBackup = map[string]regSnapshot{}
	app.TweaksBackupError = ""
	app.Status = "Все твики VOID восстановлены."
}

func refreshMetrics() {
	var idle, kernel, user fileTime
	r, _, _ := pGetSystemTimes.Call(uintptr(unsafe.Pointer(&idle)), uintptr(unsafe.Pointer(&kernel)), uintptr(unsafe.Pointer(&user)))
	if r != 0 {
		i := ft64(idle)
		k := ft64(kernel)
		u := ft64(user)
		if app.HasCPUSample {
			di := i - app.LastIdle
			dt := (k - app.LastKernel) + (u - app.LastUser)
			if dt > 0 {
				v := 100.0 * float64(dt-di) / float64(dt)
				app.CPUPercent = fmt.Sprintf("%.0f%%", math.Max(0, math.Min(100, v)))
			}
		}
		app.LastIdle = i
		app.LastKernel = k
		app.LastUser = u
		app.HasCPUSample = true
	}
	var m memoryStatusEx
	m.Length = uint32(unsafe.Sizeof(m))
	r, _, _ = pGlobalMemoryStatusEx.Call(uintptr(unsafe.Pointer(&m)))
	if r != 0 {
		app.RAMPercent = fmt.Sprintf("%d%%", m.MemoryLoad)
	}
}
func ft64(ft fileTime) uint64 { return uint64(ft.High)<<32 | uint64(ft.Low) }

func systemCommandPath(name string) string {
	root := os.Getenv("SystemRoot")
	if root == "" {
		root = os.Getenv("WINDIR")
	}
	if root != "" {
		var candidate string
		switch strings.ToLower(name) {
		case "powershell.exe":
			candidate = filepath.Join(root, "System32", "WindowsPowerShell", "v1.0", name)
		case "explorer.exe":
			candidate = filepath.Join(root, name)
		default:
			candidate = filepath.Join(root, "System32", name)
		}
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate
		}
	}
	return name
}

func runHidden(name string, args ...string) (string, error) {
	cmd := exec.Command(systemCommandPath(name), args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	out, err := cmd.CombinedOutput()
	return string(out), err
}
