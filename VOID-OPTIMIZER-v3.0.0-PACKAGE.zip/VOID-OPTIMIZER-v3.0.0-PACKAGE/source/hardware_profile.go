package main

import "strings"

type hardwareInfo struct {
	CPU         string  `json:"CPU"`
	GPU         string  `json:"GPU"`
	RAMGB       float64 `json:"RAMGB"`
	RAMType     string  `json:"RAMType"`
	Disks       string  `json:"Disks"`
	OS          string  `json:"OS"`
	LogicalCPUs int     `json:"LogicalCPUs"`
	GPUMemoryGB float64 `json:"GPUMemoryGB"`
}

// rustHardwareRecommendation is a conservative local recommendation. It only
// chooses client-side graphics settings; it never overclocks hardware or changes
// driver/security settings.
type rustHardwareRecommendation struct {
	Quality      int
	DrawDistance int
	Tier         string
	Reason       string
}

func recommendRustHardware(h hardwareInfo) rustHardwareRecommendation {
	gpu := strings.ToLower(strings.TrimSpace(h.GPU))
	ram, cores, vram := h.RAMGB, h.LogicalCPUs, h.GPUMemoryGB
	hasAny := func(parts ...string) bool {
		for _, part := range parts {
			if strings.Contains(gpu, part) {
				return true
			}
		}
		return false
	}

	// WMI returns every adapter in one string on hybrid laptops. Previously,
	// the mere presence of Intel UHD/Iris caused an RTX laptop to be marked LOW.
	// Count an integrated adapter only when no discrete adapter is also listed.
	discreteGPU := hasAny(
		"nvidia", "geforce", "rtx ", "gtx ", "radeon rx", "amd radeon rx",
		"intel arc", "arc a", "arc b",
	)
	integratedGPU := hasAny(
		"intel uhd", "intel hd", "iris xe", "radeon graphics", "vega 6",
		"vega 7", "vega 8", "radeon 610m", "radeon 660m", "radeon 680m",
		"radeon 740m", "radeon 760m", "radeon 780m", "basic display",
	) && !discreteGPU

	modernDiscrete := hasAny(
		"rtx 20", "rtx 30", "rtx 40", "rtx 50", "gtx 16",
		"rx 5", "rx 6", "rx 7", "rx 9", "intel arc", "arc a", "arc b",
	)
	highEnd := hasAny(
		"rtx 3060 ti", "rtx 3070", "rtx 3080", "rtx 3090",
		"rtx 4060 ti", "rtx 4070", "rtx 4080", "rtx 4090",
		"rtx 5060 ti", "rtx 5070", "rtx 5080", "rtx 5090",
		"rx 6700", "rx 6750", "rx 6800", "rx 6900", "rx 7700",
		"rx 7800", "rx 7900", "rx 9070", "arc b580",
	)

	// Unknown or incomplete hardware stays conservative. Do not infer that an
	// absent WMI VRAM value means zero memory.
	if (ram > 0 && ram < 12) || integratedGPU || (cores > 0 && cores <= 4) || (vram > 0 && vram < 3.5) {
		return rustHardwareRecommendation{
			Quality: 0, DrawDistance: 900, Tier: "LOW",
			Reason: "Небольшой объём RAM, мало потоков CPU или слабая/встроенная GPU — приоритет FPS и стабильности.",
		}
	}
	// AdapterRAM is often capped by WMI at 4 GB. For recognized upper-mid/high
	// GPUs, the model name is more reliable than that reported number.
	if ram >= 24 && cores >= 8 && (vram >= 8 || highEnd) {
		return rustHardwareRecommendation{
			Quality: 3, DrawDistance: 2200, Tier: "HIGH",
			Reason: "Достаточно RAM и потоков CPU, обнаружена производительная дискретная GPU — выбран расширенный профиль без максимальных тяжёлых теней.",
		}
	}
	if ram >= 12 && cores >= 6 && (modernDiscrete || vram >= 4) {
		return rustHardwareRecommendation{
			Quality: 1, DrawDistance: 1500, Tier: "BALANCED",
			Reason: "Дискретная GPU и достаточные ресурсы CPU/RAM — снижены дорогие эффекты при сохранении нормальной дальности.",
		}
	}
	return rustHardwareRecommendation{
		Quality: 0, DrawDistance: 1200, Tier: "SAFE",
		Reason: "Не хватает достоверных данных для тяжёлого профиля — применяются осторожные настройки.",
	}
}

func validRustCustomKey(key string) bool {
	key = strings.ToLower(strings.TrimSpace(key))
	if key == "" || len(key) > 12 {
		return false
	}
	allowed := map[string]bool{
		"q": true, "w": true, "e": true, "r": true, "t": true, "y": true,
		"u": true, "i": true, "o": true, "p": true, "a": true, "s": true,
		"0": true, "1": true, "2": true, "3": true, "4": true, "5": true, "6": true, "7": true, "8": true, "9": true, "space": true,
		"d": true, "f": true, "g": true, "h": true, "j": true, "k": true,
		"l": true, "z": true, "x": true, "c": true, "v": true, "b": true,
		"n": true, "m": true, "mouse1": true, "mouse2": true, "mouse3": true,
		"mouse4": true, "mouse5": true,
		"f1": true, "f2": true, "f3": true, "f4": true, "f5": true, "f6": true,
		"f7": true, "f8": true, "f9": true, "f10": true, "f11": true, "f12": true,
		"leftalt": true, "rightalt": true, "leftshift": true, "rightshift": true,
		"leftctrl": true, "rightctrl": true, "capslock": true, "tab": true,
		"home": true, "end": true, "insert": true, "delete": true,
	}
	return allowed[key]
}
