package main

import (
	"encoding/binary"
	"math"
	"testing"
)

func TestRustPlusPairingValidation(t *testing.T) {
	good := RustPlusPairing{Server: "127.0.0.1", Port: 28017, PlayerID: "76561198000000000", PlayerToken: "12345"}
	if err := good.Validate(); err != nil {
		t.Fatalf("valid pairing rejected: %v", err)
	}
	bad := good
	bad.Port = 28015
	if err := bad.Validate(); err != nil {
		t.Fatalf("a valid app port should pass basic validation: %v", err)
	}
	bad = good
	bad.PlayerID = "12345"
	if err := bad.Validate(); err == nil {
		t.Fatal("invalid SteamID64 accepted")
	}
	bad = good
	bad.PlayerToken = "not-a-number"
	if err := bad.Validate(); err == nil {
		t.Fatal("invalid token accepted")
	}
}

func TestRustPlusGrid(t *testing.T) {
	if got := rustPlusGrid(0, 1, 4000); got != "A1" {
		t.Fatalf("northwest grid: got %s", got)
	}
	if got := rustPlusGrid(0, 0, 4000); got != "A28" {
		t.Fatalf("southwest grid: got %s", got)
	}
	if got := rustPlusGrid(1, 1, 4000); got != "AB1" {
		t.Fatalf("right edge grid: got %s", got)
	}
	if got := rustPlusGrid(0.5, 0.5, 0); got != "?" {
		t.Fatalf("missing map size should not guess a square: got %s", got)
	}
}

func TestRustPlusProtobufTeamInfo(t *testing.T) {
	member := []byte{}
	member = pbVarint(member, 1, 76561198000000000)
	member = pbBytes(member, 2, []byte("Tester"))
	var fx, fy [4]byte
	binary.LittleEndian.PutUint32(fx[:], math.Float32bits(0.25))
	binary.LittleEndian.PutUint32(fy[:], math.Float32bits(0.75))
	member = append(member, byte(3<<3|5))
	member = append(member, fx[:]...)
	member = append(member, byte(4<<3|5))
	member = append(member, fy[:]...)
	member = pbVarint(member, 5, 1)
	member = pbVarint(member, 7, 0)
	member = pbVarint(member, 8, 42)
	team := pbBytes(nil, 2, member)
	response := pbBytes(nil, 9, team)
	got, err := parseRustTeamInfo(response)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Name != "Tester" || !got[0].IsOnline || got[0].IsAlive || got[0].DeathTime != 42 {
		t.Fatalf("unexpected parsed member: %#v", got)
	}
}

func TestRustPlusMarkerText(t *testing.T) {
	m := RustMapMarker{ID: 1, Type: 5, X: 0.3, Y: 0.4}
	if got := rustMarkerChatText(m, "G14"); got != "[VOID] Cargo Ship замечен. Квадрат: G14" {
		t.Fatalf("unexpected marker message: %q", got)
	}
	m.Type = 99
	if got := rustMarkerChatText(m, "G14"); got != "" {
		t.Fatalf("unknown marker should be ignored: %q", got)
	}
}
