@echo off
setlocal
cd /d "%~dp0"
title VOID Rust+ Pairing
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required for the one-time Rust+ pairing helper.
  echo Install the current Node.js LTS release, then run this file again.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)
echo ============================================================
echo VOID Rust+ Pairing helper
echo ============================================================
echo.
echo First, register this PC with Rust Companion.
echo A browser window will open. Enter Steam credentials ONLY on the official
echo Steam sign-in page. Never type your Steam password into this console.
echo.
npx --yes @liamcottle/rustplus.js fcm-register
if errorlevel 1 (
  echo.
  echo Registration failed. Check the message above and try again.
  pause
  exit /b 1
)
echo.
echo Registration completed.
echo Now keep this window open, launch Rust, open Rust+ menu and choose:
echo Pair with Server.
echo The pairing values will appear below.
echo Copy ip, port, playerId and playerToken into VOID RADAR.
echo.
npx --yes @liamcottle/rustplus.js fcm-listen
pause
